var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/base64-arraybuffer/dist/base64-arraybuffer.es5.js":
/*!************************************************************************!*\
  !*** ./node_modules/base64-arraybuffer/dist/base64-arraybuffer.es5.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "decode": () => (/* binding */ decode),
/* harmony export */   "encode": () => (/* binding */ encode)
/* harmony export */ });
var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var lookup = typeof Uint8Array === "undefined" ? [] : new Uint8Array(256);
for (var i = 0; i < chars.length; i++) {
  lookup[chars.charCodeAt(i)] = i;
}
var encode = function(arraybuffer) {
  var bytes = new Uint8Array(arraybuffer), i, len = bytes.length, base64 = "";
  for (i = 0; i < len; i += 3) {
    base64 += chars[bytes[i] >> 2];
    base64 += chars[(bytes[i] & 3) << 4 | bytes[i + 1] >> 4];
    base64 += chars[(bytes[i + 1] & 15) << 2 | bytes[i + 2] >> 6];
    base64 += chars[bytes[i + 2] & 63];
  }
  if (len % 3 === 2) {
    base64 = base64.substring(0, base64.length - 1) + "=";
  } else if (len % 3 === 1) {
    base64 = base64.substring(0, base64.length - 2) + "==";
  }
  return base64;
};
var decode = function(base64) {
  var bufferLength = base64.length * 0.75, len = base64.length, i, p = 0, encoded1, encoded2, encoded3, encoded4;
  if (base64[base64.length - 1] === "=") {
    bufferLength--;
    if (base64[base64.length - 2] === "=") {
      bufferLength--;
    }
  }
  var arraybuffer = new ArrayBuffer(bufferLength), bytes = new Uint8Array(arraybuffer);
  for (i = 0; i < len; i += 4) {
    encoded1 = lookup[base64.charCodeAt(i)];
    encoded2 = lookup[base64.charCodeAt(i + 1)];
    encoded3 = lookup[base64.charCodeAt(i + 2)];
    encoded4 = lookup[base64.charCodeAt(i + 3)];
    bytes[p++] = encoded1 << 2 | encoded2 >> 4;
    bytes[p++] = (encoded2 & 15) << 4 | encoded3 >> 2;
    bytes[p++] = (encoded3 & 3) << 6 | encoded4 & 63;
  }
  return arraybuffer;
};



/***/ }),

/***/ "./node_modules/easy-template-x/dist/es/easy-template-x.js":
/*!*****************************************************************!*\
  !*** ./node_modules/easy-template-x/dist/es/easy-template-x.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Base64": () => (/* binding */ Base64),
/* harmony export */   "Binary": () => (/* binding */ Binary),
/* harmony export */   "ContentPartType": () => (/* binding */ ContentPartType),
/* harmony export */   "DelimiterSearcher": () => (/* binding */ DelimiterSearcher),
/* harmony export */   "Delimiters": () => (/* binding */ Delimiters),
/* harmony export */   "Docx": () => (/* binding */ Docx),
/* harmony export */   "DocxParser": () => (/* binding */ DocxParser),
/* harmony export */   "ImagePlugin": () => (/* binding */ ImagePlugin),
/* harmony export */   "LOOP_CONTENT_TYPE": () => (/* binding */ LOOP_CONTENT_TYPE),
/* harmony export */   "LinkPlugin": () => (/* binding */ LinkPlugin),
/* harmony export */   "LoopPlugin": () => (/* binding */ LoopPlugin),
/* harmony export */   "MalformedFileError": () => (/* binding */ MalformedFileError),
/* harmony export */   "MaxXmlDepthError": () => (/* binding */ MaxXmlDepthError),
/* harmony export */   "MimeType": () => (/* binding */ MimeType),
/* harmony export */   "MimeTypeHelper": () => (/* binding */ MimeTypeHelper),
/* harmony export */   "MissingArgumentError": () => (/* binding */ MissingArgumentError),
/* harmony export */   "MissingCloseDelimiterError": () => (/* binding */ MissingCloseDelimiterError),
/* harmony export */   "MissingStartDelimiterError": () => (/* binding */ MissingStartDelimiterError),
/* harmony export */   "Path": () => (/* binding */ Path),
/* harmony export */   "PluginContent": () => (/* binding */ PluginContent),
/* harmony export */   "RawXmlPlugin": () => (/* binding */ RawXmlPlugin),
/* harmony export */   "Regex": () => (/* binding */ Regex),
/* harmony export */   "ScopeData": () => (/* binding */ ScopeData),
/* harmony export */   "TEXT_CONTENT_TYPE": () => (/* binding */ TEXT_CONTENT_TYPE),
/* harmony export */   "TEXT_NODE_NAME": () => (/* binding */ TEXT_NODE_NAME),
/* harmony export */   "TagDisposition": () => (/* binding */ TagDisposition),
/* harmony export */   "TagParser": () => (/* binding */ TagParser),
/* harmony export */   "TemplateCompiler": () => (/* binding */ TemplateCompiler),
/* harmony export */   "TemplateExtension": () => (/* binding */ TemplateExtension),
/* harmony export */   "TemplateHandler": () => (/* binding */ TemplateHandler),
/* harmony export */   "TemplateHandlerOptions": () => (/* binding */ TemplateHandlerOptions),
/* harmony export */   "TemplatePlugin": () => (/* binding */ TemplatePlugin),
/* harmony export */   "TextPlugin": () => (/* binding */ TextPlugin),
/* harmony export */   "UnclosedTagError": () => (/* binding */ UnclosedTagError),
/* harmony export */   "UnidentifiedFileTypeError": () => (/* binding */ UnidentifiedFileTypeError),
/* harmony export */   "UnknownContentTypeError": () => (/* binding */ UnknownContentTypeError),
/* harmony export */   "UnopenedTagError": () => (/* binding */ UnopenedTagError),
/* harmony export */   "UnsupportedFileTypeError": () => (/* binding */ UnsupportedFileTypeError),
/* harmony export */   "XmlDepthTracker": () => (/* binding */ XmlDepthTracker),
/* harmony export */   "XmlNode": () => (/* binding */ XmlNode),
/* harmony export */   "XmlNodeType": () => (/* binding */ XmlNodeType),
/* harmony export */   "XmlParser": () => (/* binding */ XmlParser),
/* harmony export */   "XmlPart": () => (/* binding */ XmlPart),
/* harmony export */   "Zip": () => (/* binding */ Zip),
/* harmony export */   "ZipObject": () => (/* binding */ ZipObject),
/* harmony export */   "createDefaultPlugins": () => (/* binding */ createDefaultPlugins),
/* harmony export */   "first": () => (/* binding */ first),
/* harmony export */   "inheritsFrom": () => (/* binding */ inheritsFrom),
/* harmony export */   "isNumber": () => (/* binding */ isNumber),
/* harmony export */   "isPromiseLike": () => (/* binding */ isPromiseLike),
/* harmony export */   "last": () => (/* binding */ last),
/* harmony export */   "pushMany": () => (/* binding */ pushMany),
/* harmony export */   "sha1": () => (/* binding */ sha1),
/* harmony export */   "stringValue": () => (/* binding */ stringValue),
/* harmony export */   "toDictionary": () => (/* binding */ toDictionary)
/* harmony export */ });
/* harmony import */ var xmldom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! xmldom */ "./node_modules/xmldom/lib/dom-parser.js");
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash.get */ "./node_modules/lodash.get/index.js");
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_get__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var jszip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jszip */ "./node_modules/jszip/dist/jszip.min.js");
/* harmony import */ var jszip__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jszip__WEBPACK_IMPORTED_MODULE_2__);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};



function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
class MalformedFileError extends Error {
  constructor(expectedFileType) {
    super(`Malformed file detected. Make sure the file is a valid ${expectedFileType} file.`);
    _defineProperty(this, "expectedFileType", void 0);
    this.expectedFileType = expectedFileType;
    Object.setPrototypeOf(this, MalformedFileError.prototype);
  }
}
class MaxXmlDepthError extends Error {
  constructor(maxDepth) {
    super(`XML maximum depth reached (max depth: ${maxDepth}).`);
    _defineProperty(this, "maxDepth", void 0);
    this.maxDepth = maxDepth;
    Object.setPrototypeOf(this, MaxXmlDepthError.prototype);
  }
}
class MissingArgumentError extends Error {
  constructor(argName) {
    super(`Argument '${argName}' is missing.`);
    _defineProperty(this, "argName", void 0);
    this.argName = argName;
    Object.setPrototypeOf(this, MissingArgumentError.prototype);
  }
}
class MissingCloseDelimiterError extends Error {
  constructor(openDelimiterText) {
    super(`Close delimiter is missing from '${openDelimiterText}'.`);
    _defineProperty(this, "openDelimiterText", void 0);
    this.openDelimiterText = openDelimiterText;
    Object.setPrototypeOf(this, MissingCloseDelimiterError.prototype);
  }
}
class MissingStartDelimiterError extends Error {
  constructor(closeDelimiterText) {
    super(`Open delimiter is missing from '${closeDelimiterText}'.`);
    _defineProperty(this, "closeDelimiterText", void 0);
    this.closeDelimiterText = closeDelimiterText;
    Object.setPrototypeOf(this, MissingStartDelimiterError.prototype);
  }
}
class UnclosedTagError extends Error {
  constructor(tagName) {
    super(`Tag '${tagName}' is never closed.`);
    _defineProperty(this, "tagName", void 0);
    this.tagName = tagName;
    Object.setPrototypeOf(this, UnclosedTagError.prototype);
  }
}
class UnidentifiedFileTypeError extends Error {
  constructor() {
    super(`The filetype for this file could not be identified, is this file corrupted?`);
    Object.setPrototypeOf(this, UnidentifiedFileTypeError.prototype);
  }
}
class UnknownContentTypeError extends Error {
  constructor(contentType, tagRawText, path) {
    super(`Content type '${contentType}' does not have a registered plugin to handle it.`);
    _defineProperty(this, "tagRawText", void 0);
    _defineProperty(this, "contentType", void 0);
    _defineProperty(this, "path", void 0);
    this.contentType = contentType;
    this.tagRawText = tagRawText;
    this.path = path;
    Object.setPrototypeOf(this, UnknownContentTypeError.prototype);
  }
}
class UnopenedTagError extends Error {
  constructor(tagName) {
    super(`Tag '${tagName}' is closed but was never opened.`);
    _defineProperty(this, "tagName", void 0);
    this.tagName = tagName;
    Object.setPrototypeOf(this, UnopenedTagError.prototype);
  }
}
class UnsupportedFileTypeError extends Error {
  constructor(fileType) {
    super(`Filetype "${fileType}" is not supported.`);
    _defineProperty(this, "fileType", void 0);
    this.fileType = fileType;
    Object.setPrototypeOf(this, UnsupportedFileTypeError.prototype);
  }
}
function pushMany(destArray, items) {
  Array.prototype.push.apply(destArray, items);
}
function first(array) {
  if (!array.length)
    return void 0;
  return array[0];
}
function last(array) {
  if (!array.length)
    return void 0;
  return array[array.length - 1];
}
function toDictionary(array, keySelector, valueSelector) {
  if (!array.length)
    return {};
  const res = {};
  array.forEach((item, index) => {
    const key = keySelector(item, index);
    const value = valueSelector ? valueSelector(item, index) : item;
    if (res[key])
      throw new Error(`Key '${key}' already exists in the dictionary.`);
    res[key] = value;
  });
  return res;
}
class Base64 {
  static encode(str) {
    if (typeof btoa !== "undefined")
      return btoa(str);
    return new Buffer(str, "binary").toString("base64");
  }
}
function inheritsFrom(derived, base) {
  return derived === base || derived.prototype instanceof base;
}
function isPromiseLike(candidate) {
  return !!candidate && typeof candidate === "object" && typeof candidate.then === "function";
}
const Binary = {
  isBlob(binary) {
    return this.isBlobConstructor(binary.constructor);
  },
  isArrayBuffer(binary) {
    return this.isArrayBufferConstructor(binary.constructor);
  },
  isBuffer(binary) {
    return this.isBufferConstructor(binary.constructor);
  },
  isBlobConstructor(binaryType) {
    return typeof Blob !== "undefined" && inheritsFrom(binaryType, Blob);
  },
  isArrayBufferConstructor(binaryType) {
    return typeof ArrayBuffer !== "undefined" && inheritsFrom(binaryType, ArrayBuffer);
  },
  isBufferConstructor(binaryType) {
    return typeof Buffer !== "undefined" && inheritsFrom(binaryType, Buffer);
  },
  toBase64(binary) {
    if (this.isBlob(binary)) {
      return new Promise((resolve) => {
        const fileReader = new FileReader();
        fileReader.onload = function() {
          const base64 = Base64.encode(this.result);
          resolve(base64);
        };
        fileReader.readAsBinaryString(binary);
      });
    }
    if (this.isBuffer(binary)) {
      return Promise.resolve(binary.toString("base64"));
    }
    if (this.isArrayBuffer(binary)) {
      const binaryStr = new Uint8Array(binary).reduce((str, byte) => str + String.fromCharCode(byte), "");
      const base64 = Base64.encode(binaryStr);
      return Promise.resolve(base64);
    }
    throw new Error(`Binary type '${binary.constructor.name}' is not supported.`);
  }
};
function isNumber(value) {
  return Number.isFinite(value);
}
class Path {
  static getFilename(path) {
    const lastSlashIndex = path.lastIndexOf("/");
    return path.substr(lastSlashIndex + 1);
  }
  static getDirectory(path) {
    const lastSlashIndex = path.lastIndexOf("/");
    return path.substring(0, lastSlashIndex);
  }
  static combine(...parts) {
    return parts.filter((part) => part === null || part === void 0 ? void 0 : part.trim()).join("/");
  }
}
class Regex {
  static escape(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
}
function sha1(msg) {
  msg = utf8Encode(msg);
  const msgLength = msg.length;
  let i, j;
  const wordArray = [];
  for (i = 0; i < msgLength - 3; i += 4) {
    j = msg.charCodeAt(i) << 24 | msg.charCodeAt(i + 1) << 16 | msg.charCodeAt(i + 2) << 8 | msg.charCodeAt(i + 3);
    wordArray.push(j);
  }
  switch (msgLength % 4) {
    case 0:
      i = 2147483648;
      break;
    case 1:
      i = msg.charCodeAt(msgLength - 1) << 24 | 8388608;
      break;
    case 2:
      i = msg.charCodeAt(msgLength - 2) << 24 | msg.charCodeAt(msgLength - 1) << 16 | 32768;
      break;
    case 3:
      i = msg.charCodeAt(msgLength - 3) << 24 | msg.charCodeAt(msgLength - 2) << 16 | msg.charCodeAt(msgLength - 1) << 8 | 128;
      break;
  }
  wordArray.push(i);
  while (wordArray.length % 16 != 14) {
    wordArray.push(0);
  }
  wordArray.push(msgLength >>> 29);
  wordArray.push(msgLength << 3 & 4294967295);
  const w = new Array(80);
  let H0 = 1732584193;
  let H1 = 4023233417;
  let H2 = 2562383102;
  let H3 = 271733878;
  let H4 = 3285377520;
  let A, B, C, D, E;
  let temp;
  for (let blockStart = 0; blockStart < wordArray.length; blockStart += 16) {
    for (i = 0; i < 16; i++) {
      w[i] = wordArray[blockStart + i];
    }
    for (i = 16; i <= 79; i++) {
      w[i] = rotateLeft(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1);
    }
    A = H0;
    B = H1;
    C = H2;
    D = H3;
    E = H4;
    for (i = 0; i <= 19; i++) {
      temp = rotateLeft(A, 5) + (B & C | ~B & D) + E + w[i] + 1518500249 & 4294967295;
      E = D;
      D = C;
      C = rotateLeft(B, 30);
      B = A;
      A = temp;
    }
    for (i = 20; i <= 39; i++) {
      temp = rotateLeft(A, 5) + (B ^ C ^ D) + E + w[i] + 1859775393 & 4294967295;
      E = D;
      D = C;
      C = rotateLeft(B, 30);
      B = A;
      A = temp;
    }
    for (i = 40; i <= 59; i++) {
      temp = rotateLeft(A, 5) + (B & C | B & D | C & D) + E + w[i] + 2400959708 & 4294967295;
      E = D;
      D = C;
      C = rotateLeft(B, 30);
      B = A;
      A = temp;
    }
    for (i = 60; i <= 79; i++) {
      temp = rotateLeft(A, 5) + (B ^ C ^ D) + E + w[i] + 3395469782 & 4294967295;
      E = D;
      D = C;
      C = rotateLeft(B, 30);
      B = A;
      A = temp;
    }
    H0 = H0 + A & 4294967295;
    H1 = H1 + B & 4294967295;
    H2 = H2 + C & 4294967295;
    H3 = H3 + D & 4294967295;
    H4 = H4 + E & 4294967295;
  }
  temp = cvtHex(H0) + cvtHex(H1) + cvtHex(H2) + cvtHex(H3) + cvtHex(H4);
  return temp.toLowerCase();
}
function rotateLeft(n, s) {
  const t4 = n << s | n >>> 32 - s;
  return t4;
}
function cvtHex(val) {
  let str = "";
  for (let i = 7; i >= 0; i--) {
    const v = val >>> i * 4 & 15;
    str += v.toString(16);
  }
  return str;
}
function utf8Encode(str) {
  str = str.replace(/\r\n/g, "\n");
  let utfStr = "";
  for (let n = 0; n < str.length; n++) {
    const c = str.charCodeAt(n);
    if (c < 128) {
      utfStr += String.fromCharCode(c);
    } else if (c > 127 && c < 2048) {
      utfStr += String.fromCharCode(c >> 6 | 192);
      utfStr += String.fromCharCode(c & 63 | 128);
    } else {
      utfStr += String.fromCharCode(c >> 12 | 224);
      utfStr += String.fromCharCode(c >> 6 & 63 | 128);
      utfStr += String.fromCharCode(c & 63 | 128);
    }
  }
  return utfStr;
}
function stringValue(val) {
  if (val === null || val === void 0) {
    return "";
  }
  return val.toString();
}
class XmlDepthTracker {
  constructor(maxDepth) {
    this.maxDepth = maxDepth;
    _defineProperty(this, "depth", 0);
  }
  increment() {
    this.depth++;
    if (this.depth > this.maxDepth) {
      throw new MaxXmlDepthError(this.maxDepth);
    }
  }
  decrement() {
    this.depth--;
  }
}
let XmlNodeType;
(function(XmlNodeType2) {
  XmlNodeType2["Text"] = "Text";
  XmlNodeType2["General"] = "General";
})(XmlNodeType || (XmlNodeType = {}));
const TEXT_NODE_NAME = "#text";
const XmlNode = {
  createTextNode(text) {
    return {
      nodeType: XmlNodeType.Text,
      nodeName: TEXT_NODE_NAME,
      textContent: text
    };
  },
  createGeneralNode(name) {
    return {
      nodeType: XmlNodeType.General,
      nodeName: name
    };
  },
  encodeValue(str) {
    if (str === null || str === void 0)
      throw new MissingArgumentError("str");
    if (typeof str !== "string")
      throw new TypeError(`Expected a string, got '${str.constructor.name}'.`);
    return str.replace(/[<>&'"]/g, (c) => {
      switch (c) {
        case "<":
          return "&lt;";
        case ">":
          return "&gt;";
        case "&":
          return "&amp;";
        case "'":
          return "&apos;";
        case '"':
          return "&quot;";
      }
      return "";
    });
  },
  serialize(node) {
    if (this.isTextNode(node))
      return this.encodeValue(node.textContent || "");
    let attributes = "";
    if (node.attributes) {
      const attributeNames = Object.keys(node.attributes);
      if (attributeNames.length) {
        attributes = " " + attributeNames.map((name) => `${name}="${node.attributes[name]}"`).join(" ");
      }
    }
    const hasChildren = (node.childNodes || []).length > 0;
    const suffix = hasChildren ? "" : "/";
    const openTag = `<${node.nodeName}${attributes}${suffix}>`;
    let xml;
    if (hasChildren) {
      const childrenXml = node.childNodes.map((child) => this.serialize(child)).join("");
      const closeTag = `</${node.nodeName}>`;
      xml = openTag + childrenXml + closeTag;
    } else {
      xml = openTag;
    }
    return xml;
  },
  fromDomNode(domNode) {
    let xmlNode;
    if (domNode.nodeType === domNode.TEXT_NODE) {
      xmlNode = this.createTextNode(domNode.textContent);
    } else {
      xmlNode = this.createGeneralNode(domNode.nodeName);
      if (domNode.nodeType === domNode.ELEMENT_NODE) {
        const attributes = domNode.attributes;
        if (attributes) {
          xmlNode.attributes = {};
          for (let i = 0; i < attributes.length; i++) {
            const curAttribute = attributes.item(i);
            xmlNode.attributes[curAttribute.name] = curAttribute.value;
          }
        }
      }
    }
    if (domNode.childNodes) {
      xmlNode.childNodes = [];
      let prevChild;
      for (let i = 0; i < domNode.childNodes.length; i++) {
        const domChild = domNode.childNodes.item(i);
        const curChild = this.fromDomNode(domChild);
        xmlNode.childNodes.push(curChild);
        curChild.parentNode = xmlNode;
        if (prevChild) {
          prevChild.nextSibling = curChild;
        }
        prevChild = curChild;
      }
    }
    return xmlNode;
  },
  isTextNode(node) {
    if (node.nodeType === XmlNodeType.Text || node.nodeName === TEXT_NODE_NAME) {
      if (!(node.nodeType === XmlNodeType.Text && node.nodeName === TEXT_NODE_NAME)) {
        throw new Error(`Invalid text node. Type: '${node.nodeType}', Name: '${node.nodeName}'.`);
      }
      return true;
    }
    return false;
  },
  cloneNode(node, deep) {
    if (!node)
      throw new MissingArgumentError("node");
    if (!deep) {
      const clone = Object.assign({}, node);
      clone.parentNode = null;
      clone.childNodes = node.childNodes ? [] : null;
      clone.nextSibling = null;
      return clone;
    } else {
      const clone = cloneNodeDeep(node);
      clone.parentNode = null;
      return clone;
    }
  },
  insertBefore(newNode, referenceNode) {
    if (!newNode)
      throw new MissingArgumentError("newNode");
    if (!referenceNode)
      throw new MissingArgumentError("referenceNode");
    if (!referenceNode.parentNode)
      throw new Error(`'${"referenceNode"}' has no parent`);
    const childNodes = referenceNode.parentNode.childNodes;
    const beforeNodeIndex = childNodes.indexOf(referenceNode);
    XmlNode.insertChild(referenceNode.parentNode, newNode, beforeNodeIndex);
  },
  insertAfter(newNode, referenceNode) {
    if (!newNode)
      throw new MissingArgumentError("newNode");
    if (!referenceNode)
      throw new MissingArgumentError("referenceNode");
    if (!referenceNode.parentNode)
      throw new Error(`'${"referenceNode"}' has no parent`);
    const childNodes = referenceNode.parentNode.childNodes;
    const referenceNodeIndex = childNodes.indexOf(referenceNode);
    XmlNode.insertChild(referenceNode.parentNode, newNode, referenceNodeIndex + 1);
  },
  insertChild(parent, child, childIndex) {
    if (!parent)
      throw new MissingArgumentError("parent");
    if (XmlNode.isTextNode(parent))
      throw new Error("Appending children to text nodes is forbidden");
    if (!child)
      throw new MissingArgumentError("child");
    if (!parent.childNodes)
      parent.childNodes = [];
    if (childIndex === parent.childNodes.length) {
      XmlNode.appendChild(parent, child);
      return;
    }
    if (childIndex > parent.childNodes.length)
      throw new RangeError(`Child index ${childIndex} is out of range. Parent has only ${parent.childNodes.length} child nodes.`);
    child.parentNode = parent;
    const childAfter = parent.childNodes[childIndex];
    child.nextSibling = childAfter;
    if (childIndex > 0) {
      const childBefore = parent.childNodes[childIndex - 1];
      childBefore.nextSibling = child;
    }
    parent.childNodes.splice(childIndex, 0, child);
  },
  appendChild(parent, child) {
    if (!parent)
      throw new MissingArgumentError("parent");
    if (XmlNode.isTextNode(parent))
      throw new Error("Appending children to text nodes is forbidden");
    if (!child)
      throw new MissingArgumentError("child");
    if (!parent.childNodes)
      parent.childNodes = [];
    if (parent.childNodes.length) {
      const currentLastChild = parent.childNodes[parent.childNodes.length - 1];
      currentLastChild.nextSibling = child;
    }
    child.nextSibling = null;
    child.parentNode = parent;
    parent.childNodes.push(child);
  },
  remove(node) {
    if (!node)
      throw new MissingArgumentError("node");
    if (!node.parentNode)
      throw new Error("Node has no parent");
    removeChild(node.parentNode, node);
  },
  removeChild,
  lastTextChild(node) {
    if (XmlNode.isTextNode(node)) {
      return node;
    }
    if (node.childNodes) {
      const allTextNodes = node.childNodes.filter((child) => XmlNode.isTextNode(child));
      if (allTextNodes.length) {
        const lastTextNode = last(allTextNodes);
        if (!lastTextNode.textContent)
          lastTextNode.textContent = "";
        return lastTextNode;
      }
    }
    const newTextNode = {
      nodeType: XmlNodeType.Text,
      nodeName: TEXT_NODE_NAME,
      textContent: ""
    };
    XmlNode.appendChild(node, newTextNode);
    return newTextNode;
  },
  removeSiblings(from, to) {
    if (from === to)
      return [];
    const removed = [];
    let lastRemoved;
    from = from.nextSibling;
    while (from !== to) {
      const removeMe = from;
      from = from.nextSibling;
      XmlNode.remove(removeMe);
      removed.push(removeMe);
      if (lastRemoved)
        lastRemoved.nextSibling = removeMe;
      lastRemoved = removeMe;
    }
    return removed;
  },
  splitByChild(parent, child, removeChild2) {
    if (child.parentNode != parent)
      throw new Error(`Node '${"child"}' is not a direct child of '${"parent"}'.`);
    const left = XmlNode.cloneNode(parent, false);
    if (parent.parentNode) {
      XmlNode.insertBefore(left, parent);
    }
    const right = parent;
    let curChild = right.childNodes[0];
    while (curChild != child) {
      XmlNode.remove(curChild);
      XmlNode.appendChild(left, curChild);
      curChild = right.childNodes[0];
    }
    if (removeChild2) {
      XmlNode.removeChild(right, 0);
    }
    return [left, right];
  },
  findParent(node, predicate) {
    while (node) {
      if (predicate(node))
        return node;
      node = node.parentNode;
    }
    return null;
  },
  findParentByName(node, nodeName) {
    return XmlNode.findParent(node, (n) => n.nodeName === nodeName);
  },
  findChildByName(node, childName) {
    if (!node)
      return null;
    return (node.childNodes || []).find((child) => child.nodeName === childName);
  },
  siblingsInRange(firstNode, lastNode) {
    if (!firstNode)
      throw new MissingArgumentError("firstNode");
    if (!lastNode)
      throw new MissingArgumentError("lastNode");
    const range = [];
    let curNode = firstNode;
    while (curNode && curNode !== lastNode) {
      range.push(curNode);
      curNode = curNode.nextSibling;
    }
    if (!curNode)
      throw new Error("Nodes are not siblings.");
    range.push(lastNode);
    return range;
  },
  removeEmptyTextNodes(node) {
    recursiveRemoveEmptyTextNodes(node);
  }
};
function removeChild(parent, childOrIndex) {
  if (!parent)
    throw new MissingArgumentError("parent");
  if (childOrIndex === null || childOrIndex === void 0)
    throw new MissingArgumentError("childOrIndex");
  if (!parent.childNodes || !parent.childNodes.length)
    throw new Error("Parent node has node children");
  let childIndex;
  if (typeof childOrIndex === "number") {
    childIndex = childOrIndex;
  } else {
    childIndex = parent.childNodes.indexOf(childOrIndex);
    if (childIndex === -1)
      throw new Error("Specified child node is not a child of the specified parent");
  }
  if (childIndex >= parent.childNodes.length)
    throw new RangeError(`Child index ${childIndex} is out of range. Parent has only ${parent.childNodes.length} child nodes.`);
  const child = parent.childNodes[childIndex];
  if (childIndex > 0) {
    const beforeChild = parent.childNodes[childIndex - 1];
    beforeChild.nextSibling = child.nextSibling;
  }
  child.parentNode = null;
  child.nextSibling = null;
  return parent.childNodes.splice(childIndex, 1)[0];
}
function cloneNodeDeep(original) {
  const clone = {};
  clone.nodeType = original.nodeType;
  clone.nodeName = original.nodeName;
  if (XmlNode.isTextNode(original)) {
    clone.textContent = original.textContent;
  } else {
    const attributes = original.attributes;
    if (attributes) {
      clone.attributes = Object.assign({}, attributes);
    }
  }
  if (original.childNodes) {
    clone.childNodes = [];
    let prevChildClone;
    for (const child of original.childNodes) {
      const childClone = cloneNodeDeep(child);
      clone.childNodes.push(childClone);
      childClone.parentNode = clone;
      if (prevChildClone) {
        prevChildClone.nextSibling = childClone;
      }
      prevChildClone = childClone;
    }
  }
  return clone;
}
function recursiveRemoveEmptyTextNodes(node) {
  if (!node.childNodes)
    return node;
  const oldChildren = node.childNodes;
  node.childNodes = [];
  for (const child of oldChildren) {
    if (XmlNode.isTextNode(child)) {
      if (child.textContent && child.textContent.match(/\S/)) {
        node.childNodes.push(child);
      }
      continue;
    }
    const strippedChild = recursiveRemoveEmptyTextNodes(child);
    node.childNodes.push(strippedChild);
  }
  return node;
}
class XmlParser {
  parse(str) {
    const doc = this.domParse(str);
    return XmlNode.fromDomNode(doc.documentElement);
  }
  domParse(str) {
    if (str === null || str === void 0)
      throw new MissingArgumentError("str");
    return XmlParser.parser.parseFromString(str, "text/xml");
  }
  serialize(xmlNode) {
    return XmlParser.xmlHeader + XmlNode.serialize(xmlNode);
  }
}
_defineProperty(XmlParser, "xmlHeader", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>');
_defineProperty(XmlParser, "parser", new xmldom__WEBPACK_IMPORTED_MODULE_0__.DOMParser());
class MatchState {
  constructor() {
    _defineProperty(this, "delimiterIndex", 0);
    _defineProperty(this, "openNodes", []);
    _defineProperty(this, "firstMatchIndex", -1);
  }
  reset() {
    this.delimiterIndex = 0;
    this.openNodes = [];
    this.firstMatchIndex = -1;
  }
}
class DelimiterSearcher {
  constructor(docxParser) {
    this.docxParser = docxParser;
    _defineProperty(this, "maxXmlDepth", 20);
    _defineProperty(this, "startDelimiter", "{");
    _defineProperty(this, "endDelimiter", "}");
    if (!docxParser)
      throw new MissingArgumentError("docxParser");
  }
  findDelimiters(node) {
    const delimiters = [];
    const match = new MatchState();
    const depth = new XmlDepthTracker(this.maxXmlDepth);
    let lookForOpenDelimiter = true;
    while (node) {
      if (this.docxParser.isParagraphNode(node)) {
        match.reset();
      }
      if (!this.shouldSearchNode(node)) {
        node = this.findNextNode(node, depth);
        continue;
      }
      match.openNodes.push(node);
      let textIndex = 0;
      while (textIndex < node.textContent.length) {
        const delimiterPattern = lookForOpenDelimiter ? this.startDelimiter : this.endDelimiter;
        const char = node.textContent[textIndex];
        if (char === delimiterPattern[match.delimiterIndex]) {
          if (match.firstMatchIndex === -1) {
            match.firstMatchIndex = textIndex;
          }
          if (match.delimiterIndex === delimiterPattern.length - 1) {
            if (match.openNodes.length > 1) {
              const firstNode = first(match.openNodes);
              const lastNode = last(match.openNodes);
              this.docxParser.joinTextNodesRange(firstNode, lastNode);
              textIndex += firstNode.textContent.length - node.textContent.length;
              node = firstNode;
            }
            const delimiterMark = this.createDelimiterMark(match, lookForOpenDelimiter);
            delimiters.push(delimiterMark);
            lookForOpenDelimiter = !lookForOpenDelimiter;
            match.reset();
            if (textIndex < node.textContent.length - 1) {
              match.openNodes.push(node);
            }
          } else {
            match.delimiterIndex++;
          }
        } else {
          if (match.firstMatchIndex !== -1) {
            node = first(match.openNodes);
            textIndex = match.firstMatchIndex;
          }
          match.reset();
          if (textIndex < node.textContent.length - 1) {
            match.openNodes.push(node);
          }
        }
        textIndex++;
      }
      node = this.findNextNode(node, depth);
    }
    return delimiters;
  }
  shouldSearchNode(node) {
    if (!XmlNode.isTextNode(node))
      return false;
    if (!node.textContent)
      return false;
    if (!node.parentNode)
      return false;
    if (!this.docxParser.isTextNode(node.parentNode))
      return false;
    return true;
  }
  findNextNode(node, depth) {
    if (node.childNodes && node.childNodes.length) {
      depth.increment();
      return node.childNodes[0];
    }
    if (node.nextSibling)
      return node.nextSibling;
    while (node.parentNode) {
      if (node.parentNode.nextSibling) {
        depth.decrement();
        return node.parentNode.nextSibling;
      }
      depth.decrement();
      node = node.parentNode;
    }
    return null;
  }
  createDelimiterMark(match, isOpenDelimiter) {
    return {
      index: match.firstMatchIndex,
      isOpen: isOpenDelimiter,
      xmlTextNode: match.openNodes[0]
    };
  }
}
class ScopeData {
  static defaultResolver(args) {
    let result;
    const lastKey = last(args.strPath);
    const curPath = args.strPath.slice();
    while (result === void 0 && curPath.length) {
      curPath.pop();
      result = lodash_get__WEBPACK_IMPORTED_MODULE_1___default()(args.data, curPath.concat(lastKey));
    }
    return result;
  }
  constructor(data) {
    _defineProperty(this, "scopeDataResolver", void 0);
    _defineProperty(this, "allData", void 0);
    _defineProperty(this, "path", []);
    _defineProperty(this, "strPath", []);
    this.allData = data;
  }
  pathPush(pathPart) {
    this.path.push(pathPart);
    const strItem = isNumber(pathPart) ? pathPart.toString() : pathPart.name;
    this.strPath.push(strItem);
  }
  pathPop() {
    this.strPath.pop();
    return this.path.pop();
  }
  pathString() {
    return this.strPath.join(".");
  }
  getScopeData() {
    const args = {
      path: this.path,
      strPath: this.strPath,
      data: this.allData
    };
    if (this.scopeDataResolver) {
      return this.scopeDataResolver(args);
    }
    return ScopeData.defaultResolver(args);
  }
}
let TagDisposition;
(function(TagDisposition2) {
  TagDisposition2["Open"] = "Open";
  TagDisposition2["Close"] = "Close";
  TagDisposition2["SelfClosed"] = "SelfClosed";
})(TagDisposition || (TagDisposition = {}));
class TagParser {
  constructor(docParser, delimiters) {
    this.docParser = docParser;
    this.delimiters = delimiters;
    _defineProperty(this, "tagRegex", void 0);
    if (!docParser)
      throw new MissingArgumentError("docParser");
    if (!delimiters)
      throw new MissingArgumentError("delimiters");
    this.tagRegex = new RegExp(`^${Regex.escape(delimiters.tagStart)}(.*?)${Regex.escape(delimiters.tagEnd)}`, "m");
  }
  parse(delimiters) {
    const tags = [];
    let openedTag;
    let openedDelimiter;
    for (let i = 0; i < delimiters.length; i++) {
      const delimiter = delimiters[i];
      if (!openedTag && !delimiter.isOpen) {
        const closeTagText = delimiter.xmlTextNode.textContent;
        throw new MissingStartDelimiterError(closeTagText);
      }
      if (openedTag && delimiter.isOpen) {
        const openTagText = openedDelimiter.xmlTextNode.textContent;
        throw new MissingCloseDelimiterError(openTagText);
      }
      if (!openedTag && delimiter.isOpen) {
        openedTag = {};
        openedDelimiter = delimiter;
      }
      if (openedTag && !delimiter.isOpen) {
        this.normalizeTagNodes(openedDelimiter, delimiter, i, delimiters);
        openedTag.xmlTextNode = openedDelimiter.xmlTextNode;
        this.processTag(openedTag);
        tags.push(openedTag);
        openedTag = null;
        openedDelimiter = null;
      }
    }
    return tags;
  }
  normalizeTagNodes(openDelimiter, closeDelimiter, closeDelimiterIndex, allDelimiters) {
    let startTextNode = openDelimiter.xmlTextNode;
    let endTextNode = closeDelimiter.xmlTextNode;
    const sameNode = startTextNode === endTextNode;
    if (openDelimiter.index > 0) {
      this.docParser.splitTextNode(startTextNode, openDelimiter.index, true);
      if (sameNode) {
        closeDelimiter.index -= openDelimiter.index;
      }
    }
    if (closeDelimiter.index < endTextNode.textContent.length - 1) {
      endTextNode = this.docParser.splitTextNode(endTextNode, closeDelimiter.index + this.delimiters.tagEnd.length, true);
      if (sameNode) {
        startTextNode = endTextNode;
      }
    }
    if (!sameNode) {
      this.docParser.joinTextNodesRange(startTextNode, endTextNode);
      endTextNode = startTextNode;
    }
    for (let i = closeDelimiterIndex + 1; i < allDelimiters.length; i++) {
      let updated = false;
      const curDelimiter = allDelimiters[i];
      if (curDelimiter.xmlTextNode === openDelimiter.xmlTextNode) {
        curDelimiter.index -= openDelimiter.index;
        updated = true;
      }
      if (curDelimiter.xmlTextNode === closeDelimiter.xmlTextNode) {
        curDelimiter.index -= closeDelimiter.index + this.delimiters.tagEnd.length;
        updated = true;
      }
      if (!updated)
        break;
    }
    openDelimiter.xmlTextNode = startTextNode;
    closeDelimiter.xmlTextNode = endTextNode;
  }
  processTag(tag) {
    tag.rawText = tag.xmlTextNode.textContent;
    const tagParts = this.tagRegex.exec(tag.rawText);
    const tagContent = (tagParts[1] || "").trim();
    if (!tagContent || !tagContent.length) {
      tag.disposition = TagDisposition.SelfClosed;
      return;
    }
    if (tagContent.startsWith(this.delimiters.containerTagOpen)) {
      tag.disposition = TagDisposition.Open;
      tag.name = tagContent.slice(this.delimiters.containerTagOpen.length).trim();
    } else if (tagContent.startsWith(this.delimiters.containerTagClose)) {
      tag.disposition = TagDisposition.Close;
      tag.name = tagContent.slice(this.delimiters.containerTagClose.length).trim();
    } else {
      tag.disposition = TagDisposition.SelfClosed;
      tag.name = tagContent;
    }
  }
}
let MimeType;
(function(MimeType2) {
  MimeType2["Png"] = "image/png";
  MimeType2["Jpeg"] = "image/jpeg";
  MimeType2["Gif"] = "image/gif";
  MimeType2["Bmp"] = "image/bmp";
  MimeType2["Svg"] = "image/svg+xml";
})(MimeType || (MimeType = {}));
class MimeTypeHelper {
  static getDefaultExtension(mime) {
    switch (mime) {
      case MimeType.Png:
        return "png";
      case MimeType.Jpeg:
        return "jpg";
      case MimeType.Gif:
        return "gif";
      case MimeType.Bmp:
        return "bmp";
      case MimeType.Svg:
        return "svg";
      default:
        throw new UnsupportedFileTypeError(mime);
    }
  }
  static getOfficeRelType(mime) {
    switch (mime) {
      case MimeType.Png:
      case MimeType.Jpeg:
      case MimeType.Gif:
      case MimeType.Bmp:
      case MimeType.Svg:
        return "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image";
      default:
        throw new UnsupportedFileTypeError(mime);
    }
  }
}
class TemplatePlugin {
  constructor() {
    _defineProperty(this, "contentType", void 0);
    _defineProperty(this, "utilities", void 0);
  }
  setUtilities(utilities) {
    this.utilities = utilities;
  }
  simpleTagReplacements(tag, data, context) {
  }
  containerTagReplacements(tags, data, context) {
  }
}
let nextImageId = 1;
class ImagePlugin extends TemplatePlugin {
  constructor(...args) {
    super(...args);
    _defineProperty(this, "contentType", "image");
  }
  simpleTagReplacements(tag, data, context) {
    return __async(this, null, function* () {
      const wordTextNode = this.utilities.docxParser.containingTextNode(tag.xmlTextNode);
      const content = data.getScopeData();
      if (!content || !content.source) {
        XmlNode.remove(wordTextNode);
        return;
      }
      const mediaFilePath = yield context.docx.mediaFiles.add(content.source, content.format);
      const relType = MimeTypeHelper.getOfficeRelType(content.format);
      const relId = yield context.currentPart.rels.add(mediaFilePath, relType);
      yield context.docx.contentTypes.ensureContentType(content.format);
      const imageId = nextImageId++;
      const imageXml = this.createMarkup(imageId, relId, content.width, content.height);
      XmlNode.insertAfter(imageXml, wordTextNode);
      XmlNode.remove(wordTextNode);
    });
  }
  createMarkup(imageId, relId, width, height) {
    const name = `Picture ${imageId}`;
    const markupText = `
            <w:drawing>
                <wp:inline distT="0" distB="0" distL="0" distR="0">
                    <wp:extent cx="${this.pixelsToEmu(width)}" cy="${this.pixelsToEmu(height)}"/>
                    <wp:effectExtent l="0" t="0" r="0" b="0"/>
                    <wp:docPr id="${imageId}" name="${name}"/>
                    <wp:cNvGraphicFramePr>
                        <a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/>
                    </wp:cNvGraphicFramePr>
                    <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
                        <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
                            ${this.pictureMarkup(name, relId, width, height)}
                        </a:graphicData>
                    </a:graphic>
                </wp:inline>
            </w:drawing>
        `;
    const markupXml = this.utilities.xmlParser.parse(markupText);
    XmlNode.removeEmptyTextNodes(markupXml);
    return markupXml;
  }
  pictureMarkup(name, relId, width, height) {
    return `
            <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
                <pic:nvPicPr>
                    <pic:cNvPr id="0" name="${name}"/>
                    <pic:cNvPicPr>
                        <a:picLocks noChangeAspect="1" noChangeArrowheads="1"/>
                    </pic:cNvPicPr>
                </pic:nvPicPr>
                <pic:blipFill>
                    <a:blip r:embed="${relId}">
                        <a:extLst>
                            <a:ext uri="{28A0092B-C50C-407E-A947-70E740481C1C}">
                                <a14:useLocalDpi xmlns:a14="http://schemas.microsoft.com/office/drawing/2010/main" val="0"/>
                            </a:ext>
                        </a:extLst>
                    </a:blip>
                    <a:srcRect/>
                    <a:stretch>
                        <a:fillRect/>
                    </a:stretch>
                </pic:blipFill>
                <pic:spPr bwMode="auto">
                    <a:xfrm>
                        <a:off x="0" y="0"/>
                        <a:ext cx="${this.pixelsToEmu(width)}" cy="${this.pixelsToEmu(height)}"/>
                    </a:xfrm>
                    <a:prstGeom prst="rect">
                        <a:avLst/>
                    </a:prstGeom>
                    <a:noFill/>
                    <a:ln>
                        <a:noFill/>
                    </a:ln>
                </pic:spPr>
            </pic:pic>
        `;
  }
  pixelsToEmu(pixels) {
    return Math.round(pixels * 9525);
  }
}
let ContentPartType;
(function(ContentPartType2) {
  ContentPartType2["MainDocument"] = "MainDocument";
  ContentPartType2["DefaultHeader"] = "DefaultHeader";
  ContentPartType2["FirstHeader"] = "FirstHeader";
  ContentPartType2["EvenPagesHeader"] = "EvenPagesHeader";
  ContentPartType2["DefaultFooter"] = "DefaultFooter";
  ContentPartType2["FirstFooter"] = "FirstFooter";
  ContentPartType2["EvenPagesFooter"] = "EvenPagesFooter";
})(ContentPartType || (ContentPartType = {}));
class ContentTypesFile {
  constructor(zip, xmlParser) {
    this.zip = zip;
    this.xmlParser = xmlParser;
    _defineProperty(this, "addedNew", false);
    _defineProperty(this, "root", void 0);
    _defineProperty(this, "contentTypes", void 0);
  }
  ensureContentType(mime) {
    return __async(this, null, function* () {
      yield this.parseContentTypesFile();
      if (this.contentTypes[mime])
        return;
      const extension = MimeTypeHelper.getDefaultExtension(mime);
      const typeNode = XmlNode.createGeneralNode("Default");
      typeNode.attributes = {
        "Extension": extension,
        "ContentType": mime
      };
      this.root.childNodes.push(typeNode);
      this.addedNew = true;
      this.contentTypes[mime] = true;
    });
  }
  count() {
    return __async(this, null, function* () {
      yield this.parseContentTypesFile();
      return this.root.childNodes.filter((node) => !XmlNode.isTextNode(node)).length;
    });
  }
  save() {
    return __async(this, null, function* () {
      if (!this.addedNew)
        return;
      const xmlContent = this.xmlParser.serialize(this.root);
      this.zip.setFile(ContentTypesFile.contentTypesFilePath, xmlContent);
    });
  }
  parseContentTypesFile() {
    return __async(this, null, function* () {
      if (this.root)
        return;
      const contentTypesXml = yield this.zip.getFile(ContentTypesFile.contentTypesFilePath).getContentText();
      this.root = this.xmlParser.parse(contentTypesXml);
      this.contentTypes = {};
      for (const node of this.root.childNodes) {
        if (node.nodeName !== "Default")
          continue;
        const genNode = node;
        const contentTypeAttribute = genNode.attributes["ContentType"];
        if (!contentTypeAttribute)
          continue;
        this.contentTypes[contentTypeAttribute] = true;
      }
    });
  }
}
_defineProperty(ContentTypesFile, "contentTypesFilePath", "[Content_Types].xml");
class MediaFiles {
  constructor(zip) {
    this.zip = zip;
    _defineProperty(this, "hashes", void 0);
    _defineProperty(this, "files", /* @__PURE__ */ new Map());
    _defineProperty(this, "nextFileId", 0);
  }
  add(mediaFile, mime) {
    return __async(this, null, function* () {
      if (this.files.has(mediaFile))
        return this.files.get(mediaFile);
      yield this.hashMediaFiles();
      const base64 = yield Binary.toBase64(mediaFile);
      const hash = sha1(base64);
      let path = Object.keys(this.hashes).find((p) => this.hashes[p] === hash);
      if (path)
        return path;
      const extension = MimeTypeHelper.getDefaultExtension(mime);
      do {
        this.nextFileId++;
        path = `${MediaFiles.mediaDir}/media${this.nextFileId}.${extension}`;
      } while (this.hashes[path]);
      yield this.zip.setFile(path, mediaFile);
      this.hashes[path] = hash;
      this.files.set(mediaFile, path);
      return path;
    });
  }
  count() {
    return __async(this, null, function* () {
      yield this.hashMediaFiles();
      return Object.keys(this.hashes).length;
    });
  }
  hashMediaFiles() {
    return __async(this, null, function* () {
      if (this.hashes)
        return;
      this.hashes = {};
      for (const path of this.zip.listFiles()) {
        if (!path.startsWith(MediaFiles.mediaDir))
          continue;
        const filename = Path.getFilename(path);
        if (!filename)
          continue;
        const fileData = yield this.zip.getFile(path).getContentBase64();
        const fileHash = sha1(fileData);
        this.hashes[filename] = fileHash;
      }
    });
  }
}
_defineProperty(MediaFiles, "mediaDir", "word/media");
class Relationship {
  static fromXml(xml) {
    var _xml$attributes, _xml$attributes2, _xml$attributes3, _xml$attributes4;
    return new Relationship({
      id: (_xml$attributes = xml.attributes) === null || _xml$attributes === void 0 ? void 0 : _xml$attributes["Id"],
      type: (_xml$attributes2 = xml.attributes) === null || _xml$attributes2 === void 0 ? void 0 : _xml$attributes2["Type"],
      target: (_xml$attributes3 = xml.attributes) === null || _xml$attributes3 === void 0 ? void 0 : _xml$attributes3["Target"],
      targetMode: (_xml$attributes4 = xml.attributes) === null || _xml$attributes4 === void 0 ? void 0 : _xml$attributes4["TargetMode"]
    });
  }
  constructor(initial) {
    _defineProperty(this, "id", void 0);
    _defineProperty(this, "type", void 0);
    _defineProperty(this, "target", void 0);
    _defineProperty(this, "targetMode", void 0);
    Object.assign(this, initial);
  }
  toXml() {
    const node = XmlNode.createGeneralNode("Relationship");
    node.attributes = {};
    for (const propKey of Object.keys(this)) {
      const value = this[propKey];
      if (value && typeof value === "string") {
        const attrName = propKey[0].toUpperCase() + propKey.substr(1);
        node.attributes[attrName] = value;
      }
    }
    return node;
  }
}
class Rels {
  constructor(partPath, zip, xmlParser) {
    this.zip = zip;
    this.xmlParser = xmlParser;
    _defineProperty(this, "rels", void 0);
    _defineProperty(this, "relTargets", void 0);
    _defineProperty(this, "nextRelId", 0);
    _defineProperty(this, "partDir", void 0);
    _defineProperty(this, "relsFilePath", void 0);
    this.partDir = partPath && Path.getDirectory(partPath);
    const partFilename = partPath && Path.getFilename(partPath);
    this.relsFilePath = Path.combine(this.partDir, "_rels", `${partFilename !== null && partFilename !== void 0 ? partFilename : ""}.rels`);
  }
  add(relTarget, relType, relTargetMode) {
    return __async(this, null, function* () {
      if (this.partDir && relTarget.startsWith(this.partDir)) {
        relTarget = relTarget.substr(this.partDir.length + 1);
      }
      yield this.parseRelsFile();
      const relTargetKey = this.getRelTargetKey(relType, relTarget);
      let relId = this.relTargets[relTargetKey];
      if (relId)
        return relId;
      relId = this.getNextRelId();
      const rel = new Relationship({
        id: relId,
        type: relType,
        target: relTarget,
        targetMode: relTargetMode
      });
      this.rels[relId] = rel;
      this.relTargets[relTargetKey] = relId;
      return relId;
    });
  }
  list() {
    return __async(this, null, function* () {
      yield this.parseRelsFile();
      return Object.values(this.rels);
    });
  }
  save() {
    return __async(this, null, function* () {
      if (!this.rels)
        return;
      const root = this.createRootNode();
      root.childNodes = Object.values(this.rels).map((rel) => rel.toXml());
      const xmlContent = this.xmlParser.serialize(root);
      this.zip.setFile(this.relsFilePath, xmlContent);
    });
  }
  getNextRelId() {
    let relId;
    do {
      this.nextRelId++;
      relId = "rId" + this.nextRelId;
    } while (this.rels[relId]);
    return relId;
  }
  parseRelsFile() {
    return __async(this, null, function* () {
      if (this.rels)
        return;
      let root;
      const relsFile = this.zip.getFile(this.relsFilePath);
      if (relsFile) {
        const xml = yield relsFile.getContentText();
        root = this.xmlParser.parse(xml);
      } else {
        root = this.createRootNode();
      }
      this.rels = {};
      this.relTargets = {};
      for (const relNode of root.childNodes) {
        const attributes = relNode.attributes;
        if (!attributes)
          continue;
        const idAttr = attributes["Id"];
        if (!idAttr)
          continue;
        const rel = Relationship.fromXml(relNode);
        this.rels[idAttr] = rel;
        const typeAttr = attributes["Type"];
        const targetAttr = attributes["Target"];
        if (typeAttr && targetAttr) {
          const relTargetKey = this.getRelTargetKey(typeAttr, targetAttr);
          this.relTargets[relTargetKey] = idAttr;
        }
      }
    });
  }
  getRelTargetKey(type, target) {
    return `${type} - ${target}`;
  }
  createRootNode() {
    const root = XmlNode.createGeneralNode("Relationships");
    root.attributes = {
      "xmlns": "http://schemas.openxmlformats.org/package/2006/relationships"
    };
    root.childNodes = [];
    return root;
  }
}
class XmlPart {
  constructor(path, zip, xmlParser) {
    this.path = path;
    this.zip = zip;
    this.xmlParser = xmlParser;
    _defineProperty(this, "rels", void 0);
    _defineProperty(this, "root", void 0);
    this.rels = new Rels(this.path, zip, xmlParser);
  }
  xmlRoot() {
    return __async(this, null, function* () {
      if (!this.root) {
        const xml = yield this.zip.getFile(this.path).getContentText();
        this.root = this.xmlParser.parse(xml);
      }
      return this.root;
    });
  }
  getText() {
    return __async(this, null, function* () {
      const xmlDocument = yield this.xmlRoot();
      const xml = this.xmlParser.serialize(xmlDocument);
      const domDocument = this.xmlParser.domParse(xml);
      return domDocument.documentElement.textContent;
    });
  }
  saveChanges() {
    return __async(this, null, function* () {
      if (this.root) {
        const xmlRoot = yield this.xmlRoot();
        const xmlContent = this.xmlParser.serialize(xmlRoot);
        this.zip.setFile(this.path, xmlContent);
      }
      yield this.rels.save();
    });
  }
}
class Docx {
  static open(zip, xmlParser) {
    return __async(this, null, function* () {
      const mainDocumentPath = yield Docx.getMainDocumentPath(zip, xmlParser);
      if (!mainDocumentPath)
        throw new MalformedFileError("docx");
      return new Docx(mainDocumentPath, zip, xmlParser);
    });
  }
  static getMainDocumentPath(zip, xmlParser) {
    return __async(this, null, function* () {
      var _relations$find;
      const rootPart = "";
      const rootRels = new Rels(rootPart, zip, xmlParser);
      const relations = yield rootRels.list();
      return (_relations$find = relations.find((rel) => rel.type == Docx.mainDocumentRelType)) === null || _relations$find === void 0 ? void 0 : _relations$find.target;
    });
  }
  get rawZipFile() {
    return this.zip;
  }
  constructor(mainDocumentPath, zip, xmlParser) {
    this.zip = zip;
    this.xmlParser = xmlParser;
    _defineProperty(this, "mainDocument", void 0);
    _defineProperty(this, "mediaFiles", void 0);
    _defineProperty(this, "contentTypes", void 0);
    _defineProperty(this, "_parts", {});
    this.mainDocument = new XmlPart(mainDocumentPath, zip, xmlParser);
    this.mediaFiles = new MediaFiles(zip);
    this.contentTypes = new ContentTypesFile(zip, xmlParser);
  }
  getContentPart(type) {
    return __async(this, null, function* () {
      switch (type) {
        case ContentPartType.MainDocument:
          return this.mainDocument;
        default:
          return yield this.getHeaderOrFooter(type);
      }
    });
  }
  getContentParts() {
    return __async(this, null, function* () {
      const partTypes = [ContentPartType.MainDocument, ContentPartType.DefaultHeader, ContentPartType.FirstHeader, ContentPartType.EvenPagesHeader, ContentPartType.DefaultFooter, ContentPartType.FirstFooter, ContentPartType.EvenPagesFooter];
      const parts = yield Promise.all(partTypes.map((p) => this.getContentPart(p)));
      return parts.filter((p) => !!p);
    });
  }
  export(outputType) {
    return __async(this, null, function* () {
      yield this.saveChanges();
      return yield this.zip.export(outputType);
    });
  }
  getHeaderOrFooter(type) {
    return __async(this, null, function* () {
      var _sectionProps$childNo, _attributes;
      const nodeName = this.headerFooterNodeName(type);
      const nodeTypeAttribute = this.headerFooterType(type);
      const docRoot = yield this.mainDocument.xmlRoot();
      const body = docRoot.childNodes[0];
      const sectionProps = last(body.childNodes.filter((node) => node.nodeType === XmlNodeType.General));
      if (sectionProps.nodeName != "w:sectPr")
        return null;
      const reference = (_sectionProps$childNo = sectionProps.childNodes) === null || _sectionProps$childNo === void 0 ? void 0 : _sectionProps$childNo.find((node) => {
        var _node$attributes;
        return node.nodeType === XmlNodeType.General && node.nodeName === nodeName && ((_node$attributes = node.attributes) === null || _node$attributes === void 0 ? void 0 : _node$attributes["w:type"]) === nodeTypeAttribute;
      });
      const relId = reference === null || reference === void 0 ? void 0 : (_attributes = reference.attributes) === null || _attributes === void 0 ? void 0 : _attributes["r:id"];
      if (!relId)
        return null;
      const rels = yield this.mainDocument.rels.list();
      const relTarget = rels.find((r) => r.id === relId).target;
      if (!this._parts[relTarget]) {
        const part = new XmlPart("word/" + relTarget, this.zip, this.xmlParser);
        this._parts[relTarget] = part;
      }
      return this._parts[relTarget];
    });
  }
  headerFooterNodeName(contentPartType) {
    switch (contentPartType) {
      case ContentPartType.DefaultHeader:
      case ContentPartType.FirstHeader:
      case ContentPartType.EvenPagesHeader:
        return "w:headerReference";
      case ContentPartType.DefaultFooter:
      case ContentPartType.FirstFooter:
      case ContentPartType.EvenPagesFooter:
        return "w:footerReference";
      default:
        throw new Error(`Invalid content part type: '${contentPartType}'.`);
    }
  }
  headerFooterType(contentPartType) {
    switch (contentPartType) {
      case ContentPartType.DefaultHeader:
      case ContentPartType.DefaultFooter:
        return "default";
      case ContentPartType.FirstHeader:
      case ContentPartType.FirstFooter:
        return "first";
      case ContentPartType.EvenPagesHeader:
      case ContentPartType.EvenPagesFooter:
        return "even";
      default:
        throw new Error(`Invalid content part type: '${contentPartType}'.`);
    }
  }
  saveChanges() {
    return __async(this, null, function* () {
      const parts = [this.mainDocument, ...Object.values(this._parts)];
      for (const part of parts) {
        yield part.saveChanges();
      }
      yield this.contentTypes.save();
    });
  }
}
_defineProperty(Docx, "mainDocumentRelType", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument");
class DocxParser {
  constructor(xmlParser) {
    this.xmlParser = xmlParser;
  }
  load(zip) {
    return Docx.open(zip, this.xmlParser);
  }
  splitTextNode(textNode, splitIndex, addBefore) {
    let firstXmlTextNode;
    let secondXmlTextNode;
    const wordTextNode = this.containingTextNode(textNode);
    const newWordTextNode = XmlNode.cloneNode(wordTextNode, true);
    this.setSpacePreserveAttribute(wordTextNode);
    this.setSpacePreserveAttribute(newWordTextNode);
    if (addBefore) {
      XmlNode.insertBefore(newWordTextNode, wordTextNode);
      firstXmlTextNode = XmlNode.lastTextChild(newWordTextNode);
      secondXmlTextNode = textNode;
    } else {
      const curIndex = wordTextNode.parentNode.childNodes.indexOf(wordTextNode);
      XmlNode.insertChild(wordTextNode.parentNode, newWordTextNode, curIndex + 1);
      firstXmlTextNode = textNode;
      secondXmlTextNode = XmlNode.lastTextChild(newWordTextNode);
    }
    const firstText = firstXmlTextNode.textContent;
    const secondText = secondXmlTextNode.textContent;
    firstXmlTextNode.textContent = firstText.substring(0, splitIndex);
    secondXmlTextNode.textContent = secondText.substring(splitIndex);
    return addBefore ? firstXmlTextNode : secondXmlTextNode;
  }
  splitParagraphByTextNode(paragraph, textNode, removeTextNode) {
    const containingParagraph = this.containingParagraphNode(textNode);
    if (containingParagraph != paragraph)
      throw new Error(`Node '${"textNode"}' is not a descendant of '${"paragraph"}'.`);
    const runNode = this.containingRunNode(textNode);
    const wordTextNode = this.containingTextNode(textNode);
    const leftRun = XmlNode.cloneNode(runNode, false);
    const rightRun = runNode;
    XmlNode.insertBefore(leftRun, rightRun);
    const runProps = rightRun.childNodes.find((node) => node.nodeName === DocxParser.RUN_PROPERTIES_NODE);
    if (runProps) {
      const leftRunProps = XmlNode.cloneNode(runProps, true);
      XmlNode.appendChild(leftRun, leftRunProps);
    }
    const firstRunChildIndex = runProps ? 1 : 0;
    let curChild = rightRun.childNodes[firstRunChildIndex];
    while (curChild != wordTextNode) {
      XmlNode.remove(curChild);
      XmlNode.appendChild(leftRun, curChild);
      curChild = rightRun.childNodes[firstRunChildIndex];
    }
    if (removeTextNode) {
      XmlNode.removeChild(rightRun, firstRunChildIndex);
    }
    const leftPara = XmlNode.cloneNode(containingParagraph, false);
    const rightPara = containingParagraph;
    XmlNode.insertBefore(leftPara, rightPara);
    const paragraphProps = rightPara.childNodes.find((node) => node.nodeName === DocxParser.PARAGRAPH_PROPERTIES_NODE);
    if (paragraphProps) {
      const leftParagraphProps = XmlNode.cloneNode(paragraphProps, true);
      XmlNode.appendChild(leftPara, leftParagraphProps);
    }
    const firstParaChildIndex = paragraphProps ? 1 : 0;
    curChild = rightPara.childNodes[firstParaChildIndex];
    while (curChild != rightRun) {
      XmlNode.remove(curChild);
      XmlNode.appendChild(leftPara, curChild);
      curChild = rightPara.childNodes[firstParaChildIndex];
    }
    if (this.isEmptyRun(leftRun))
      XmlNode.remove(leftRun);
    if (this.isEmptyRun(rightRun))
      XmlNode.remove(rightRun);
    return [leftPara, rightPara];
  }
  joinTextNodesRange(from, to) {
    const firstRunNode = this.containingRunNode(from);
    const secondRunNode = this.containingRunNode(to);
    const paragraphNode = firstRunNode.parentNode;
    if (secondRunNode.parentNode !== paragraphNode)
      throw new Error("Can not join text nodes from separate paragraphs.");
    const firstWordTextNode = this.containingTextNode(from);
    const secondWordTextNode = this.containingTextNode(to);
    const totalText = [];
    let curRunNode = firstRunNode;
    while (curRunNode) {
      let curWordTextNode;
      if (curRunNode === firstRunNode) {
        curWordTextNode = firstWordTextNode;
      } else {
        curWordTextNode = this.firstTextNodeChild(curRunNode);
      }
      while (curWordTextNode) {
        if (curWordTextNode.nodeName !== DocxParser.TEXT_NODE)
          continue;
        const curXmlTextNode = XmlNode.lastTextChild(curWordTextNode);
        totalText.push(curXmlTextNode.textContent);
        const textToRemove = curWordTextNode;
        if (curWordTextNode === secondWordTextNode) {
          curWordTextNode = null;
        } else {
          curWordTextNode = curWordTextNode.nextSibling;
        }
        if (textToRemove !== firstWordTextNode) {
          XmlNode.remove(textToRemove);
        }
      }
      const runToRemove = curRunNode;
      if (curRunNode === secondRunNode) {
        curRunNode = null;
      } else {
        curRunNode = curRunNode.nextSibling;
      }
      if (!runToRemove.childNodes || !runToRemove.childNodes.length) {
        XmlNode.remove(runToRemove);
      }
    }
    const firstXmlTextNode = XmlNode.lastTextChild(firstWordTextNode);
    firstXmlTextNode.textContent = totalText.join("");
  }
  joinParagraphs(first2, second) {
    if (first2 === second)
      return;
    let childIndex = 0;
    while (second.childNodes && childIndex < second.childNodes.length) {
      const curChild = second.childNodes[childIndex];
      if (curChild.nodeName === DocxParser.RUN_NODE) {
        XmlNode.removeChild(second, childIndex);
        XmlNode.appendChild(first2, curChild);
      } else {
        childIndex++;
      }
    }
  }
  setSpacePreserveAttribute(node) {
    if (!node.attributes) {
      node.attributes = {};
    }
    if (!node.attributes["xml:space"]) {
      node.attributes["xml:space"] = "preserve";
    }
  }
  isTextNode(node) {
    return node.nodeName === DocxParser.TEXT_NODE;
  }
  isRunNode(node) {
    return node.nodeName === DocxParser.RUN_NODE;
  }
  isRunPropertiesNode(node) {
    return node.nodeName === DocxParser.RUN_PROPERTIES_NODE;
  }
  isTableCellNode(node) {
    return node.nodeName === DocxParser.TABLE_CELL_NODE;
  }
  isParagraphNode(node) {
    return node.nodeName === DocxParser.PARAGRAPH_NODE;
  }
  isListParagraph(paragraphNode) {
    const paragraphProperties = this.paragraphPropertiesNode(paragraphNode);
    const listNumberProperties = XmlNode.findChildByName(paragraphProperties, DocxParser.NUMBER_PROPERTIES_NODE);
    return !!listNumberProperties;
  }
  paragraphPropertiesNode(paragraphNode) {
    if (!this.isParagraphNode(paragraphNode))
      throw new Error(`Expected paragraph node but received a '${paragraphNode.nodeName}' node.`);
    return XmlNode.findChildByName(paragraphNode, DocxParser.PARAGRAPH_PROPERTIES_NODE);
  }
  firstTextNodeChild(node) {
    if (!node)
      return null;
    if (node.nodeName !== DocxParser.RUN_NODE)
      return null;
    if (!node.childNodes)
      return null;
    for (const child of node.childNodes) {
      if (child.nodeName === DocxParser.TEXT_NODE)
        return child;
    }
    return null;
  }
  containingTextNode(node) {
    if (!node)
      return null;
    if (!XmlNode.isTextNode(node))
      throw new Error(`'Invalid argument ${"node"}. Expected a XmlTextNode.`);
    return XmlNode.findParentByName(node, DocxParser.TEXT_NODE);
  }
  containingRunNode(node) {
    return XmlNode.findParentByName(node, DocxParser.RUN_NODE);
  }
  containingParagraphNode(node) {
    return XmlNode.findParentByName(node, DocxParser.PARAGRAPH_NODE);
  }
  containingTableRowNode(node) {
    return XmlNode.findParentByName(node, DocxParser.TABLE_ROW_NODE);
  }
  isEmptyTextNode(node) {
    var _node$childNodes;
    if (!this.isTextNode(node))
      throw new Error(`Text node expected but '${node.nodeName}' received.`);
    if (!((_node$childNodes = node.childNodes) !== null && _node$childNodes !== void 0 && _node$childNodes.length))
      return true;
    const xmlTextNode = node.childNodes[0];
    if (!XmlNode.isTextNode(xmlTextNode))
      throw new Error("Invalid XML structure. 'w:t' node should contain a single text node only.");
    if (!xmlTextNode.textContent)
      return true;
    return false;
  }
  isEmptyRun(node) {
    if (!this.isRunNode(node))
      throw new Error(`Run node expected but '${node.nodeName}' received.`);
    for (const child of (_node$childNodes2 = node.childNodes) !== null && _node$childNodes2 !== void 0 ? _node$childNodes2 : []) {
      var _node$childNodes2;
      if (this.isRunPropertiesNode(child))
        continue;
      if (this.isTextNode(child) && this.isEmptyTextNode(child))
        continue;
      return false;
    }
    return true;
  }
}
_defineProperty(DocxParser, "PARAGRAPH_NODE", "w:p");
_defineProperty(DocxParser, "PARAGRAPH_PROPERTIES_NODE", "w:pPr");
_defineProperty(DocxParser, "RUN_NODE", "w:r");
_defineProperty(DocxParser, "RUN_PROPERTIES_NODE", "w:rPr");
_defineProperty(DocxParser, "TEXT_NODE", "w:t");
_defineProperty(DocxParser, "TABLE_ROW_NODE", "w:tr");
_defineProperty(DocxParser, "TABLE_CELL_NODE", "w:tc");
_defineProperty(DocxParser, "NUMBER_PROPERTIES_NODE", "w:numPr");
class LinkPlugin extends TemplatePlugin {
  constructor(...args) {
    super(...args);
    _defineProperty(this, "contentType", "link");
  }
  simpleTagReplacements(tag, data, context) {
    return __async(this, null, function* () {
      const wordTextNode = this.utilities.docxParser.containingTextNode(tag.xmlTextNode);
      const content = data.getScopeData();
      if (!content || !content.target) {
        XmlNode.remove(wordTextNode);
        return;
      }
      const relId = yield context.currentPart.rels.add(content.target, LinkPlugin.linkRelType, "External");
      const wordRunNode = this.utilities.docxParser.containingRunNode(wordTextNode);
      const linkMarkup = this.generateMarkup(content, relId, wordRunNode);
      this.insertHyperlinkNode(linkMarkup, wordRunNode, wordTextNode);
    });
  }
  generateMarkup(content, relId, wordRunNode) {
    const markupText = `
            <w:hyperlink r:id="${relId}" w:history="1">
                <w:r>
                    <w:t>${content.text || content.target}</w:t>
                </w:r>
            </w:hyperlink>
        `;
    const markupXml = this.utilities.xmlParser.parse(markupText);
    XmlNode.removeEmptyTextNodes(markupXml);
    const runProps = wordRunNode.childNodes.find((node) => node.nodeName === DocxParser.RUN_PROPERTIES_NODE);
    if (runProps) {
      const linkRunProps = XmlNode.cloneNode(runProps, true);
      markupXml.childNodes[0].childNodes.unshift(linkRunProps);
    }
    return markupXml;
  }
  insertHyperlinkNode(linkMarkup, tagRunNode, tagTextNode) {
    let textNodesInRun = tagRunNode.childNodes.filter((node) => node.nodeName === DocxParser.TEXT_NODE);
    if (textNodesInRun.length > 1) {
      const [runBeforeTag] = XmlNode.splitByChild(tagRunNode, tagTextNode, true);
      textNodesInRun = runBeforeTag.childNodes.filter((node) => node.nodeName === DocxParser.TEXT_NODE);
      XmlNode.insertAfter(linkMarkup, runBeforeTag);
      if (textNodesInRun.length === 0) {
        XmlNode.remove(runBeforeTag);
      }
    } else {
      XmlNode.insertAfter(linkMarkup, tagRunNode);
      XmlNode.remove(tagRunNode);
    }
  }
}
_defineProperty(LinkPlugin, "linkRelType", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink");
class LoopListStrategy {
  constructor() {
    _defineProperty(this, "utilities", void 0);
  }
  setUtilities(utilities) {
    this.utilities = utilities;
  }
  isApplicable(openTag, closeTag) {
    const containingParagraph = this.utilities.docxParser.containingParagraphNode(openTag.xmlTextNode);
    return this.utilities.docxParser.isListParagraph(containingParagraph);
  }
  splitBefore(openTag, closeTag) {
    const firstParagraph = this.utilities.docxParser.containingParagraphNode(openTag.xmlTextNode);
    const lastParagraph = this.utilities.docxParser.containingParagraphNode(closeTag.xmlTextNode);
    const paragraphsToRepeat = XmlNode.siblingsInRange(firstParagraph, lastParagraph);
    XmlNode.remove(openTag.xmlTextNode);
    XmlNode.remove(closeTag.xmlTextNode);
    return {
      firstNode: firstParagraph,
      nodesToRepeat: paragraphsToRepeat,
      lastNode: lastParagraph
    };
  }
  mergeBack(paragraphGroups, firstParagraph, lastParagraphs) {
    for (const curParagraphsGroup of paragraphGroups) {
      for (const paragraph of curParagraphsGroup) {
        XmlNode.insertBefore(paragraph, lastParagraphs);
      }
    }
    XmlNode.remove(firstParagraph);
    if (firstParagraph !== lastParagraphs) {
      XmlNode.remove(lastParagraphs);
    }
  }
}
class LoopParagraphStrategy {
  constructor() {
    _defineProperty(this, "utilities", void 0);
  }
  setUtilities(utilities) {
    this.utilities = utilities;
  }
  isApplicable(openTag, closeTag) {
    return true;
  }
  splitBefore(openTag, closeTag) {
    let firstParagraph = this.utilities.docxParser.containingParagraphNode(openTag.xmlTextNode);
    let lastParagraph = this.utilities.docxParser.containingParagraphNode(closeTag.xmlTextNode);
    const areSame = firstParagraph === lastParagraph;
    let splitResult = this.utilities.docxParser.splitParagraphByTextNode(firstParagraph, openTag.xmlTextNode, true);
    firstParagraph = splitResult[0];
    let afterFirstParagraph = splitResult[1];
    if (areSame)
      lastParagraph = afterFirstParagraph;
    splitResult = this.utilities.docxParser.splitParagraphByTextNode(lastParagraph, closeTag.xmlTextNode, true);
    const beforeLastParagraph = splitResult[0];
    lastParagraph = splitResult[1];
    if (areSame)
      afterFirstParagraph = beforeLastParagraph;
    XmlNode.remove(afterFirstParagraph);
    if (!areSame)
      XmlNode.remove(beforeLastParagraph);
    let middleParagraphs;
    if (areSame) {
      middleParagraphs = [afterFirstParagraph];
    } else {
      const inBetween = XmlNode.removeSiblings(firstParagraph, lastParagraph);
      middleParagraphs = [afterFirstParagraph].concat(inBetween).concat(beforeLastParagraph);
    }
    return {
      firstNode: firstParagraph,
      nodesToRepeat: middleParagraphs,
      lastNode: lastParagraph
    };
  }
  mergeBack(middleParagraphs, firstParagraph, lastParagraph) {
    let mergeTo = firstParagraph;
    for (const curParagraphsGroup of middleParagraphs) {
      this.utilities.docxParser.joinParagraphs(mergeTo, curParagraphsGroup[0]);
      for (let i = 1; i < curParagraphsGroup.length; i++) {
        XmlNode.insertBefore(curParagraphsGroup[i], lastParagraph);
        mergeTo = curParagraphsGroup[i];
      }
    }
    this.utilities.docxParser.joinParagraphs(mergeTo, lastParagraph);
    XmlNode.remove(lastParagraph);
  }
}
class LoopTableStrategy {
  constructor() {
    _defineProperty(this, "utilities", void 0);
  }
  setUtilities(utilities) {
    this.utilities = utilities;
  }
  isApplicable(openTag, closeTag) {
    const containingParagraph = this.utilities.docxParser.containingParagraphNode(openTag.xmlTextNode);
    if (!containingParagraph.parentNode)
      return false;
    return this.utilities.docxParser.isTableCellNode(containingParagraph.parentNode);
  }
  splitBefore(openTag, closeTag) {
    const firstRow = this.utilities.docxParser.containingTableRowNode(openTag.xmlTextNode);
    const lastRow = this.utilities.docxParser.containingTableRowNode(closeTag.xmlTextNode);
    const rowsToRepeat = XmlNode.siblingsInRange(firstRow, lastRow);
    XmlNode.remove(openTag.xmlTextNode);
    XmlNode.remove(closeTag.xmlTextNode);
    return {
      firstNode: firstRow,
      nodesToRepeat: rowsToRepeat,
      lastNode: lastRow
    };
  }
  mergeBack(rowGroups, firstRow, lastRow) {
    for (const curRowsGroup of rowGroups) {
      for (const row of curRowsGroup) {
        XmlNode.insertBefore(row, lastRow);
      }
    }
    XmlNode.remove(firstRow);
    if (firstRow !== lastRow) {
      XmlNode.remove(lastRow);
    }
  }
}
const LOOP_CONTENT_TYPE = "loop";
class LoopPlugin extends TemplatePlugin {
  constructor(...args) {
    super(...args);
    _defineProperty(this, "contentType", LOOP_CONTENT_TYPE);
    _defineProperty(this, "loopStrategies", [
      new LoopTableStrategy(),
      new LoopListStrategy(),
      new LoopParagraphStrategy()
    ]);
  }
  setUtilities(utilities) {
    this.utilities = utilities;
    this.loopStrategies.forEach((strategy) => strategy.setUtilities(utilities));
  }
  containerTagReplacements(tags, data, context) {
    return __async(this, null, function* () {
      let value = data.getScopeData();
      const isCondition = !Array.isArray(value);
      if (isCondition) {
        if (!!value) {
          value = [{}];
        } else {
          value = [];
        }
      }
      const openTag = tags[0];
      const closeTag = last(tags);
      const loopStrategy = this.loopStrategies.find((strategy) => strategy.isApplicable(openTag, closeTag));
      if (!loopStrategy)
        throw new Error(`No loop strategy found for tag '${openTag.rawText}'.`);
      const {
        firstNode,
        nodesToRepeat,
        lastNode
      } = loopStrategy.splitBefore(openTag, closeTag);
      const repeatedNodes = this.repeat(nodesToRepeat, value.length);
      const compiledNodes = yield this.compile(isCondition, repeatedNodes, data, context);
      loopStrategy.mergeBack(compiledNodes, firstNode, lastNode);
    });
  }
  repeat(nodes, times) {
    if (!nodes.length || !times)
      return [];
    const allResults = [];
    for (let i = 0; i < times; i++) {
      const curResult = nodes.map((node) => XmlNode.cloneNode(node, true));
      allResults.push(curResult);
    }
    return allResults;
  }
  compile(isCondition, nodeGroups, data, context) {
    return __async(this, null, function* () {
      const compiledNodeGroups = [];
      for (let i = 0; i < nodeGroups.length; i++) {
        const curNodes = nodeGroups[i];
        const dummyRootNode = XmlNode.createGeneralNode("dummyRootNode");
        curNodes.forEach((node) => XmlNode.appendChild(dummyRootNode, node));
        const conditionTag = this.updatePathBefore(isCondition, data, i);
        yield this.utilities.compiler.compile(dummyRootNode, data, context);
        this.updatePathAfter(isCondition, data, conditionTag);
        const curResult = [];
        while (dummyRootNode.childNodes && dummyRootNode.childNodes.length) {
          const child = XmlNode.removeChild(dummyRootNode, 0);
          curResult.push(child);
        }
        compiledNodeGroups.push(curResult);
      }
      return compiledNodeGroups;
    });
  }
  updatePathBefore(isCondition, data, groupIndex) {
    if (isCondition) {
      if (groupIndex > 0) {
        throw new Error(`Internal error: Unexpected group index ${groupIndex} for boolean condition at path "${data.pathString()}".`);
      }
      return data.pathPop();
    }
    data.pathPush(groupIndex);
    return null;
  }
  updatePathAfter(isCondition, data, conditionTag) {
    if (isCondition) {
      data.pathPush(conditionTag);
    } else {
      data.pathPop();
    }
  }
}
class RawXmlPlugin extends TemplatePlugin {
  constructor(...args) {
    super(...args);
    _defineProperty(this, "contentType", "rawXml");
  }
  simpleTagReplacements(tag, data) {
    const value = data.getScopeData();
    const replaceNode = value !== null && value !== void 0 && value.replaceParagraph ? this.utilities.docxParser.containingParagraphNode(tag.xmlTextNode) : this.utilities.docxParser.containingTextNode(tag.xmlTextNode);
    if (typeof (value === null || value === void 0 ? void 0 : value.xml) === "string") {
      const newNode = this.utilities.xmlParser.parse(value.xml);
      XmlNode.insertBefore(newNode, replaceNode);
    }
    XmlNode.remove(replaceNode);
  }
}
const TEXT_CONTENT_TYPE = "text";
class TextPlugin extends TemplatePlugin {
  constructor(...args) {
    super(...args);
    _defineProperty(this, "contentType", TEXT_CONTENT_TYPE);
  }
  simpleTagReplacements(tag, data) {
    const value = data.getScopeData();
    const lines = stringValue(value).split("\n");
    if (lines.length < 2) {
      this.replaceSingleLine(tag.xmlTextNode, lines.length ? lines[0] : "");
    } else {
      this.replaceMultiLine(tag.xmlTextNode, lines);
    }
  }
  replaceSingleLine(textNode, text) {
    textNode.textContent = text;
    const wordTextNode = this.utilities.docxParser.containingTextNode(textNode);
    this.utilities.docxParser.setSpacePreserveAttribute(wordTextNode);
  }
  replaceMultiLine(textNode, lines) {
    const runNode = this.utilities.docxParser.containingRunNode(textNode);
    textNode.textContent = lines[0];
    for (let i = 1; i < lines.length; i++) {
      const lineBreak = this.getLineBreak();
      XmlNode.appendChild(runNode, lineBreak);
      const lineNode = this.createWordTextNode(lines[i]);
      XmlNode.appendChild(runNode, lineNode);
    }
  }
  getLineBreak() {
    return XmlNode.createGeneralNode("w:br");
  }
  createWordTextNode(text) {
    const wordTextNode = XmlNode.createGeneralNode(DocxParser.TEXT_NODE);
    wordTextNode.attributes = {};
    this.utilities.docxParser.setSpacePreserveAttribute(wordTextNode);
    wordTextNode.childNodes = [XmlNode.createTextNode(text)];
    return wordTextNode;
  }
}
function createDefaultPlugins() {
  return [new LoopPlugin(), new RawXmlPlugin(), new ImagePlugin(), new LinkPlugin(), new TextPlugin()];
}
const PluginContent = {
  isPluginContent(content) {
    return !!content && typeof content._type === "string";
  }
};
class TemplateCompiler {
  constructor(delimiterSearcher, tagParser, plugins, options) {
    this.delimiterSearcher = delimiterSearcher;
    this.tagParser = tagParser;
    this.options = options;
    _defineProperty(this, "pluginsLookup", void 0);
    this.pluginsLookup = toDictionary(plugins, (p) => p.contentType);
  }
  compile(node, data, context) {
    return __async(this, null, function* () {
      const tags = this.parseTags(node);
      yield this.doTagReplacements(tags, data, context);
    });
  }
  parseTags(node) {
    const delimiters = this.delimiterSearcher.findDelimiters(node);
    const tags = this.tagParser.parse(delimiters);
    return tags;
  }
  doTagReplacements(tags, data, context) {
    return __async(this, null, function* () {
      for (let tagIndex = 0; tagIndex < tags.length; tagIndex++) {
        const tag = tags[tagIndex];
        data.pathPush(tag);
        const contentType = this.detectContentType(tag, data);
        const plugin = this.pluginsLookup[contentType];
        if (!plugin) {
          throw new UnknownContentTypeError(contentType, tag.rawText, data.pathString());
        }
        if (tag.disposition === TagDisposition.SelfClosed) {
          yield this.simpleTagReplacements(plugin, tag, data, context);
        } else if (tag.disposition === TagDisposition.Open) {
          const closingTagIndex = this.findCloseTagIndex(tagIndex, tag, tags);
          const scopeTags = tags.slice(tagIndex, closingTagIndex + 1);
          tagIndex = closingTagIndex;
          const job = plugin.containerTagReplacements(scopeTags, data, context);
          if (isPromiseLike(job)) {
            yield job;
          }
        }
        data.pathPop();
      }
    });
  }
  detectContentType(tag, data) {
    const scopeData = data.getScopeData();
    if (PluginContent.isPluginContent(scopeData))
      return scopeData._type;
    if (tag.disposition === TagDisposition.Open || tag.disposition === TagDisposition.Close)
      return this.options.containerContentType;
    return this.options.defaultContentType;
  }
  simpleTagReplacements(plugin, tag, data, context) {
    return __async(this, null, function* () {
      if (this.options.skipEmptyTags && stringValue(data.getScopeData()) === "") {
        return;
      }
      const job = plugin.simpleTagReplacements(tag, data, context);
      if (isPromiseLike(job)) {
        yield job;
      }
    });
  }
  findCloseTagIndex(fromIndex, openTag, tags) {
    let openTags = 0;
    let i = fromIndex;
    for (; i < tags.length; i++) {
      const tag = tags[i];
      if (tag.disposition === TagDisposition.Open) {
        openTags++;
        continue;
      }
      if (tag.disposition == TagDisposition.Close) {
        openTags--;
        if (openTags === 0) {
          return i;
        }
        if (openTags < 0) {
          throw new UnopenedTagError(tag.name);
        }
        continue;
      }
    }
    if (i === tags.length) {
      throw new UnclosedTagError(openTag.name);
    }
    return i;
  }
}
class TemplateExtension {
  constructor() {
    _defineProperty(this, "utilities", void 0);
  }
  setUtilities(utilities) {
    this.utilities = utilities;
  }
}
class JsZipHelper {
  static toJsZipOutputType(binaryOrType) {
    if (!binaryOrType)
      throw new MissingArgumentError("binaryOrType");
    let binaryType;
    if (typeof binaryOrType === "function") {
      binaryType = binaryOrType;
    } else {
      binaryType = binaryOrType.constructor;
    }
    if (Binary.isBlobConstructor(binaryType))
      return "blob";
    if (Binary.isArrayBufferConstructor(binaryType))
      return "arraybuffer";
    if (Binary.isBufferConstructor(binaryType))
      return "nodebuffer";
    throw new Error(`Binary type '${binaryType.name}' is not supported.`);
  }
}
class ZipObject {
  get name() {
    return this.zipObject.name;
  }
  set name(value) {
    this.zipObject.name = value;
  }
  get isDirectory() {
    return this.zipObject.dir;
  }
  constructor(zipObject) {
    this.zipObject = zipObject;
  }
  getContentText() {
    return this.zipObject.async("text");
  }
  getContentBase64() {
    return this.zipObject.async("binarystring");
  }
  getContentBinary(outputType) {
    const zipOutputType = JsZipHelper.toJsZipOutputType(outputType);
    return this.zipObject.async(zipOutputType);
  }
}
class Zip {
  static load(file) {
    return __async(this, null, function* () {
      const zip = yield jszip__WEBPACK_IMPORTED_MODULE_2__.loadAsync(file);
      return new Zip(zip);
    });
  }
  constructor(zip) {
    this.zip = zip;
  }
  getFile(path) {
    const internalZipObject = this.zip.files[path];
    if (!internalZipObject)
      return null;
    return new ZipObject(internalZipObject);
  }
  setFile(path, content) {
    this.zip.file(path, content);
  }
  isFileExist(path) {
    return !!this.zip.files[path];
  }
  listFiles() {
    return Object.keys(this.zip.files);
  }
  export(outputType) {
    return __async(this, null, function* () {
      const zipOutputType = JsZipHelper.toJsZipOutputType(outputType);
      const output = yield this.zip.generateAsync({
        type: zipOutputType,
        compression: "DEFLATE",
        compressionOptions: {
          level: 6
        }
      });
      return output;
    });
  }
}
class Delimiters {
  constructor(initial) {
    _defineProperty(this, "tagStart", "{");
    _defineProperty(this, "tagEnd", "}");
    _defineProperty(this, "containerTagOpen", "#");
    _defineProperty(this, "containerTagClose", "/");
    Object.assign(this, initial);
    this.encodeAndValidate();
    if (this.containerTagOpen === this.containerTagClose)
      throw new Error(`${"containerTagOpen"} can not be equal to ${"containerTagClose"}`);
  }
  encodeAndValidate() {
    const keys = ["tagStart", "tagEnd", "containerTagOpen", "containerTagClose"];
    for (const key of keys) {
      const value = this[key];
      if (!value)
        throw new Error(`${key} can not be empty.`);
      if (value !== value.trim())
        throw new Error(`${key} can not contain leading or trailing whitespace.`);
    }
  }
}
class TemplateHandlerOptions {
  constructor(initial) {
    _defineProperty(this, "plugins", createDefaultPlugins());
    _defineProperty(this, "skipEmptyTags", false);
    _defineProperty(this, "defaultContentType", TEXT_CONTENT_TYPE);
    _defineProperty(this, "containerContentType", LOOP_CONTENT_TYPE);
    _defineProperty(this, "delimiters", new Delimiters());
    _defineProperty(this, "maxXmlDepth", 20);
    _defineProperty(this, "extensions", {});
    _defineProperty(this, "scopeDataResolver", void 0);
    Object.assign(this, initial);
    if (initial) {
      this.delimiters = new Delimiters(initial.delimiters);
    }
    if (!this.plugins.length) {
      throw new Error("Plugins list can not be empty");
    }
  }
}
class TemplateHandler {
  constructor(options) {
    var _this$options$extensi, _this$options$extensi2, _this$options$extensi3, _this$options$extensi4;
    _defineProperty(this, "version", "3.0.2");
    _defineProperty(this, "xmlParser", new XmlParser());
    _defineProperty(this, "docxParser", void 0);
    _defineProperty(this, "compiler", void 0);
    _defineProperty(this, "options", void 0);
    this.options = new TemplateHandlerOptions(options);
    this.docxParser = new DocxParser(this.xmlParser);
    const delimiterSearcher = new DelimiterSearcher(this.docxParser);
    delimiterSearcher.startDelimiter = this.options.delimiters.tagStart;
    delimiterSearcher.endDelimiter = this.options.delimiters.tagEnd;
    delimiterSearcher.maxXmlDepth = this.options.maxXmlDepth;
    const tagParser = new TagParser(this.docxParser, this.options.delimiters);
    this.compiler = new TemplateCompiler(delimiterSearcher, tagParser, this.options.plugins, {
      skipEmptyTags: this.options.skipEmptyTags,
      defaultContentType: this.options.defaultContentType,
      containerContentType: this.options.containerContentType
    });
    this.options.plugins.forEach((plugin) => {
      plugin.setUtilities({
        xmlParser: this.xmlParser,
        docxParser: this.docxParser,
        compiler: this.compiler
      });
    });
    const extensionUtilities = {
      xmlParser: this.xmlParser,
      docxParser: this.docxParser,
      tagParser,
      compiler: this.compiler
    };
    (_this$options$extensi = this.options.extensions) === null || _this$options$extensi === void 0 ? void 0 : (_this$options$extensi2 = _this$options$extensi.beforeCompilation) === null || _this$options$extensi2 === void 0 ? void 0 : _this$options$extensi2.forEach((extension) => {
      extension.setUtilities(extensionUtilities);
    });
    (_this$options$extensi3 = this.options.extensions) === null || _this$options$extensi3 === void 0 ? void 0 : (_this$options$extensi4 = _this$options$extensi3.afterCompilation) === null || _this$options$extensi4 === void 0 ? void 0 : _this$options$extensi4.forEach((extension) => {
      extension.setUtilities(extensionUtilities);
    });
  }
  process(templateFile, data) {
    return __async(this, null, function* () {
      const docx = yield this.loadDocx(templateFile);
      const scopeData = new ScopeData(data);
      scopeData.scopeDataResolver = this.options.scopeDataResolver;
      const context = {
        docx,
        currentPart: null
      };
      const contentParts = yield docx.getContentParts();
      for (const part of contentParts) {
        var _this$options$extensi5, _this$options$extensi6;
        context.currentPart = part;
        yield this.callExtensions((_this$options$extensi5 = this.options.extensions) === null || _this$options$extensi5 === void 0 ? void 0 : _this$options$extensi5.beforeCompilation, scopeData, context);
        const xmlRoot = yield part.xmlRoot();
        yield this.compiler.compile(xmlRoot, scopeData, context);
        yield this.callExtensions((_this$options$extensi6 = this.options.extensions) === null || _this$options$extensi6 === void 0 ? void 0 : _this$options$extensi6.afterCompilation, scopeData, context);
      }
      return docx.export(templateFile.constructor);
    });
  }
  parseTags(_0) {
    return __async(this, arguments, function* (templateFile, contentPart = ContentPartType.MainDocument) {
      const docx = yield this.loadDocx(templateFile);
      const part = yield docx.getContentPart(contentPart);
      const xmlRoot = yield part.xmlRoot();
      return this.compiler.parseTags(xmlRoot);
    });
  }
  getText(_0) {
    return __async(this, arguments, function* (docxFile, contentPart = ContentPartType.MainDocument) {
      const docx = yield this.loadDocx(docxFile);
      const part = yield docx.getContentPart(contentPart);
      const text = yield part.getText();
      return text;
    });
  }
  getXml(_0) {
    return __async(this, arguments, function* (docxFile, contentPart = ContentPartType.MainDocument) {
      const docx = yield this.loadDocx(docxFile);
      const part = yield docx.getContentPart(contentPart);
      const xmlRoot = yield part.xmlRoot();
      return xmlRoot;
    });
  }
  callExtensions(extensions, scopeData, context) {
    return __async(this, null, function* () {
      if (!extensions)
        return;
      for (const extension of extensions) {
        yield extension.execute(scopeData, context);
      }
    });
  }
  loadDocx(file) {
    return __async(this, null, function* () {
      let zip;
      try {
        zip = yield Zip.load(file);
      } catch (_unused) {
        throw new MalformedFileError("docx");
      }
      const docx = yield this.docxParser.load(zip);
      return docx;
    });
  }
}



/***/ }),

/***/ "./node_modules/jszip/dist/jszip.min.js":
/*!**********************************************!*\
  !*** ./node_modules/jszip/dist/jszip.min.js ***!
  \**********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/*!

JSZip v3.10.0 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/
!function(e) {
  if (true)
    module.exports = e();
  else {}
}(function() {
  return function s(a, o, h) {
    function u(r, e2) {
      if (!o[r]) {
        if (!a[r]) {
          var t = undefined;
          if (!e2 && t)
            return require(r, true);
          if (l)
            return l(r, true);
          var n = new Error("Cannot find module '" + r + "'");
          throw n.code = "MODULE_NOT_FOUND", n;
        }
        var i = o[r] = { exports: {} };
        a[r][0].call(i.exports, function(e3) {
          var t2 = a[r][1][e3];
          return u(t2 || e3);
        }, i, i.exports, s, a, o, h);
      }
      return o[r].exports;
    }
    for (var l = undefined, e = 0; e < h.length; e++)
      u(h[e]);
    return u;
  }({ 1: [function(e, t, r) {
    "use strict";
    var d = e("./utils"), c = e("./support"), p = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    r.encode = function(e2) {
      for (var t2, r2, n, i, s, a, o, h = [], u = 0, l = e2.length, f = l, c2 = "string" !== d.getTypeOf(e2); u < e2.length; )
        f = l - u, n = c2 ? (t2 = e2[u++], r2 = u < l ? e2[u++] : 0, u < l ? e2[u++] : 0) : (t2 = e2.charCodeAt(u++), r2 = u < l ? e2.charCodeAt(u++) : 0, u < l ? e2.charCodeAt(u++) : 0), i = t2 >> 2, s = (3 & t2) << 4 | r2 >> 4, a = 1 < f ? (15 & r2) << 2 | n >> 6 : 64, o = 2 < f ? 63 & n : 64, h.push(p.charAt(i) + p.charAt(s) + p.charAt(a) + p.charAt(o));
      return h.join("");
    }, r.decode = function(e2) {
      var t2, r2, n, i, s, a, o = 0, h = 0, u = "data:";
      if (e2.substr(0, u.length) === u)
        throw new Error("Invalid base64 input, it looks like a data url.");
      var l, f = 3 * (e2 = e2.replace(/[^A-Za-z0-9\+\/\=]/g, "")).length / 4;
      if (e2.charAt(e2.length - 1) === p.charAt(64) && f--, e2.charAt(e2.length - 2) === p.charAt(64) && f--, f % 1 != 0)
        throw new Error("Invalid base64 input, bad content length.");
      for (l = c.uint8array ? new Uint8Array(0 | f) : new Array(0 | f); o < e2.length; )
        t2 = p.indexOf(e2.charAt(o++)) << 2 | (i = p.indexOf(e2.charAt(o++))) >> 4, r2 = (15 & i) << 4 | (s = p.indexOf(e2.charAt(o++))) >> 2, n = (3 & s) << 6 | (a = p.indexOf(e2.charAt(o++))), l[h++] = t2, 64 !== s && (l[h++] = r2), 64 !== a && (l[h++] = n);
      return l;
    };
  }, { "./support": 30, "./utils": 32 }], 2: [function(e, t, r) {
    "use strict";
    var n = e("./external"), i = e("./stream/DataWorker"), s = e("./stream/Crc32Probe"), a = e("./stream/DataLengthProbe");
    function o(e2, t2, r2, n2, i2) {
      this.compressedSize = e2, this.uncompressedSize = t2, this.crc32 = r2, this.compression = n2, this.compressedContent = i2;
    }
    o.prototype = { getContentWorker: function() {
      var e2 = new i(n.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")), t2 = this;
      return e2.on("end", function() {
        if (this.streamInfo.data_length !== t2.uncompressedSize)
          throw new Error("Bug : uncompressed data size mismatch");
      }), e2;
    }, getCompressedWorker: function() {
      return new i(n.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize", this.compressedSize).withStreamInfo("uncompressedSize", this.uncompressedSize).withStreamInfo("crc32", this.crc32).withStreamInfo("compression", this.compression);
    } }, o.createWorkerFrom = function(e2, t2, r2) {
      return e2.pipe(new s()).pipe(new a("uncompressedSize")).pipe(t2.compressWorker(r2)).pipe(new a("compressedSize")).withStreamInfo("compression", t2);
    }, t.exports = o;
  }, { "./external": 6, "./stream/Crc32Probe": 25, "./stream/DataLengthProbe": 26, "./stream/DataWorker": 27 }], 3: [function(e, t, r) {
    "use strict";
    var n = e("./stream/GenericWorker");
    r.STORE = { magic: "\0\0", compressWorker: function(e2) {
      return new n("STORE compression");
    }, uncompressWorker: function() {
      return new n("STORE decompression");
    } }, r.DEFLATE = e("./flate");
  }, { "./flate": 7, "./stream/GenericWorker": 28 }], 4: [function(e, t, r) {
    "use strict";
    var n = e("./utils");
    var o = function() {
      for (var e2, t2 = [], r2 = 0; r2 < 256; r2++) {
        e2 = r2;
        for (var n2 = 0; n2 < 8; n2++)
          e2 = 1 & e2 ? 3988292384 ^ e2 >>> 1 : e2 >>> 1;
        t2[r2] = e2;
      }
      return t2;
    }();
    t.exports = function(e2, t2) {
      return void 0 !== e2 && e2.length ? "string" !== n.getTypeOf(e2) ? function(e3, t3, r2, n2) {
        var i = o, s = n2 + r2;
        e3 ^= -1;
        for (var a = n2; a < s; a++)
          e3 = e3 >>> 8 ^ i[255 & (e3 ^ t3[a])];
        return -1 ^ e3;
      }(0 | t2, e2, e2.length, 0) : function(e3, t3, r2, n2) {
        var i = o, s = n2 + r2;
        e3 ^= -1;
        for (var a = n2; a < s; a++)
          e3 = e3 >>> 8 ^ i[255 & (e3 ^ t3.charCodeAt(a))];
        return -1 ^ e3;
      }(0 | t2, e2, e2.length, 0) : 0;
    };
  }, { "./utils": 32 }], 5: [function(e, t, r) {
    "use strict";
    r.base64 = false, r.binary = false, r.dir = false, r.createFolders = true, r.date = null, r.compression = null, r.compressionOptions = null, r.comment = null, r.unixPermissions = null, r.dosPermissions = null;
  }, {}], 6: [function(e, t, r) {
    "use strict";
    var n = null;
    n = "undefined" != typeof Promise ? Promise : e("lie"), t.exports = { Promise: n };
  }, { lie: 37 }], 7: [function(e, t, r) {
    "use strict";
    var n = "undefined" != typeof Uint8Array && "undefined" != typeof Uint16Array && "undefined" != typeof Uint32Array, i = e("pako"), s = e("./utils"), a = e("./stream/GenericWorker"), o = n ? "uint8array" : "array";
    function h(e2, t2) {
      a.call(this, "FlateWorker/" + e2), this._pako = null, this._pakoAction = e2, this._pakoOptions = t2, this.meta = {};
    }
    r.magic = "\b\0", s.inherits(h, a), h.prototype.processChunk = function(e2) {
      this.meta = e2.meta, null === this._pako && this._createPako(), this._pako.push(s.transformTo(o, e2.data), false);
    }, h.prototype.flush = function() {
      a.prototype.flush.call(this), null === this._pako && this._createPako(), this._pako.push([], true);
    }, h.prototype.cleanUp = function() {
      a.prototype.cleanUp.call(this), this._pako = null;
    }, h.prototype._createPako = function() {
      this._pako = new i[this._pakoAction]({ raw: true, level: this._pakoOptions.level || -1 });
      var t2 = this;
      this._pako.onData = function(e2) {
        t2.push({ data: e2, meta: t2.meta });
      };
    }, r.compressWorker = function(e2) {
      return new h("Deflate", e2);
    }, r.uncompressWorker = function() {
      return new h("Inflate", {});
    };
  }, { "./stream/GenericWorker": 28, "./utils": 32, pako: 38 }], 8: [function(e, t, r) {
    "use strict";
    function A(e2, t2) {
      var r2, n2 = "";
      for (r2 = 0; r2 < t2; r2++)
        n2 += String.fromCharCode(255 & e2), e2 >>>= 8;
      return n2;
    }
    function n(e2, t2, r2, n2, i2, s2) {
      var a, o, h = e2.file, u = e2.compression, l = s2 !== O.utf8encode, f = I.transformTo("string", s2(h.name)), c = I.transformTo("string", O.utf8encode(h.name)), d = h.comment, p = I.transformTo("string", s2(d)), m = I.transformTo("string", O.utf8encode(d)), _ = c.length !== h.name.length, g = m.length !== d.length, b = "", v = "", y = "", w = h.dir, k = h.date, x = { crc32: 0, compressedSize: 0, uncompressedSize: 0 };
      t2 && !r2 || (x.crc32 = e2.crc32, x.compressedSize = e2.compressedSize, x.uncompressedSize = e2.uncompressedSize);
      var S = 0;
      t2 && (S |= 8), l || !_ && !g || (S |= 2048);
      var z = 0, C = 0;
      w && (z |= 16), "UNIX" === i2 ? (C = 798, z |= function(e3, t3) {
        var r3 = e3;
        return e3 || (r3 = t3 ? 16893 : 33204), (65535 & r3) << 16;
      }(h.unixPermissions, w)) : (C = 20, z |= function(e3) {
        return 63 & (e3 || 0);
      }(h.dosPermissions)), a = k.getUTCHours(), a <<= 6, a |= k.getUTCMinutes(), a <<= 5, a |= k.getUTCSeconds() / 2, o = k.getUTCFullYear() - 1980, o <<= 4, o |= k.getUTCMonth() + 1, o <<= 5, o |= k.getUTCDate(), _ && (v = A(1, 1) + A(B(f), 4) + c, b += "up" + A(v.length, 2) + v), g && (y = A(1, 1) + A(B(p), 4) + m, b += "uc" + A(y.length, 2) + y);
      var E = "";
      return E += "\n\0", E += A(S, 2), E += u.magic, E += A(a, 2), E += A(o, 2), E += A(x.crc32, 4), E += A(x.compressedSize, 4), E += A(x.uncompressedSize, 4), E += A(f.length, 2), E += A(b.length, 2), { fileRecord: R.LOCAL_FILE_HEADER + E + f + b, dirRecord: R.CENTRAL_FILE_HEADER + A(C, 2) + E + A(p.length, 2) + "\0\0\0\0" + A(z, 4) + A(n2, 4) + f + b + p };
    }
    var I = e("../utils"), i = e("../stream/GenericWorker"), O = e("../utf8"), B = e("../crc32"), R = e("../signature");
    function s(e2, t2, r2, n2) {
      i.call(this, "ZipFileWorker"), this.bytesWritten = 0, this.zipComment = t2, this.zipPlatform = r2, this.encodeFileName = n2, this.streamFiles = e2, this.accumulate = false, this.contentBuffer = [], this.dirRecords = [], this.currentSourceOffset = 0, this.entriesCount = 0, this.currentFile = null, this._sources = [];
    }
    I.inherits(s, i), s.prototype.push = function(e2) {
      var t2 = e2.meta.percent || 0, r2 = this.entriesCount, n2 = this._sources.length;
      this.accumulate ? this.contentBuffer.push(e2) : (this.bytesWritten += e2.data.length, i.prototype.push.call(this, { data: e2.data, meta: { currentFile: this.currentFile, percent: r2 ? (t2 + 100 * (r2 - n2 - 1)) / r2 : 100 } }));
    }, s.prototype.openedSource = function(e2) {
      this.currentSourceOffset = this.bytesWritten, this.currentFile = e2.file.name;
      var t2 = this.streamFiles && !e2.file.dir;
      if (t2) {
        var r2 = n(e2, t2, false, this.currentSourceOffset, this.zipPlatform, this.encodeFileName);
        this.push({ data: r2.fileRecord, meta: { percent: 0 } });
      } else
        this.accumulate = true;
    }, s.prototype.closedSource = function(e2) {
      this.accumulate = false;
      var t2 = this.streamFiles && !e2.file.dir, r2 = n(e2, t2, true, this.currentSourceOffset, this.zipPlatform, this.encodeFileName);
      if (this.dirRecords.push(r2.dirRecord), t2)
        this.push({ data: function(e3) {
          return R.DATA_DESCRIPTOR + A(e3.crc32, 4) + A(e3.compressedSize, 4) + A(e3.uncompressedSize, 4);
        }(e2), meta: { percent: 100 } });
      else
        for (this.push({ data: r2.fileRecord, meta: { percent: 0 } }); this.contentBuffer.length; )
          this.push(this.contentBuffer.shift());
      this.currentFile = null;
    }, s.prototype.flush = function() {
      for (var e2 = this.bytesWritten, t2 = 0; t2 < this.dirRecords.length; t2++)
        this.push({ data: this.dirRecords[t2], meta: { percent: 100 } });
      var r2 = this.bytesWritten - e2, n2 = function(e3, t3, r3, n3, i2) {
        var s2 = I.transformTo("string", i2(n3));
        return R.CENTRAL_DIRECTORY_END + "\0\0\0\0" + A(e3, 2) + A(e3, 2) + A(t3, 4) + A(r3, 4) + A(s2.length, 2) + s2;
      }(this.dirRecords.length, r2, e2, this.zipComment, this.encodeFileName);
      this.push({ data: n2, meta: { percent: 100 } });
    }, s.prototype.prepareNextSource = function() {
      this.previous = this._sources.shift(), this.openedSource(this.previous.streamInfo), this.isPaused ? this.previous.pause() : this.previous.resume();
    }, s.prototype.registerPrevious = function(e2) {
      this._sources.push(e2);
      var t2 = this;
      return e2.on("data", function(e3) {
        t2.processChunk(e3);
      }), e2.on("end", function() {
        t2.closedSource(t2.previous.streamInfo), t2._sources.length ? t2.prepareNextSource() : t2.end();
      }), e2.on("error", function(e3) {
        t2.error(e3);
      }), this;
    }, s.prototype.resume = function() {
      return !!i.prototype.resume.call(this) && (!this.previous && this._sources.length ? (this.prepareNextSource(), true) : this.previous || this._sources.length || this.generatedError ? void 0 : (this.end(), true));
    }, s.prototype.error = function(e2) {
      var t2 = this._sources;
      if (!i.prototype.error.call(this, e2))
        return false;
      for (var r2 = 0; r2 < t2.length; r2++)
        try {
          t2[r2].error(e2);
        } catch (e3) {
        }
      return true;
    }, s.prototype.lock = function() {
      i.prototype.lock.call(this);
      for (var e2 = this._sources, t2 = 0; t2 < e2.length; t2++)
        e2[t2].lock();
    }, t.exports = s;
  }, { "../crc32": 4, "../signature": 23, "../stream/GenericWorker": 28, "../utf8": 31, "../utils": 32 }], 9: [function(e, t, r) {
    "use strict";
    var u = e("../compressions"), n = e("./ZipFileWorker");
    r.generateWorker = function(e2, a, t2) {
      var o = new n(a.streamFiles, t2, a.platform, a.encodeFileName), h = 0;
      try {
        e2.forEach(function(e3, t3) {
          h++;
          var r2 = function(e4, t4) {
            var r3 = e4 || t4, n3 = u[r3];
            if (!n3)
              throw new Error(r3 + " is not a valid compression method !");
            return n3;
          }(t3.options.compression, a.compression), n2 = t3.options.compressionOptions || a.compressionOptions || {}, i = t3.dir, s = t3.date;
          t3._compressWorker(r2, n2).withStreamInfo("file", { name: e3, dir: i, date: s, comment: t3.comment || "", unixPermissions: t3.unixPermissions, dosPermissions: t3.dosPermissions }).pipe(o);
        }), o.entriesCount = h;
      } catch (e3) {
        o.error(e3);
      }
      return o;
    };
  }, { "../compressions": 3, "./ZipFileWorker": 8 }], 10: [function(e, t, r) {
    "use strict";
    function n() {
      if (!(this instanceof n))
        return new n();
      if (arguments.length)
        throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");
      this.files = /* @__PURE__ */ Object.create(null), this.comment = null, this.root = "", this.clone = function() {
        var e2 = new n();
        for (var t2 in this)
          "function" != typeof this[t2] && (e2[t2] = this[t2]);
        return e2;
      };
    }
    (n.prototype = e("./object")).loadAsync = e("./load"), n.support = e("./support"), n.defaults = e("./defaults"), n.version = "3.10.0", n.loadAsync = function(e2, t2) {
      return new n().loadAsync(e2, t2);
    }, n.external = e("./external"), t.exports = n;
  }, { "./defaults": 5, "./external": 6, "./load": 11, "./object": 15, "./support": 30 }], 11: [function(e, t, r) {
    "use strict";
    var u = e("./utils"), i = e("./external"), n = e("./utf8"), s = e("./zipEntries"), a = e("./stream/Crc32Probe"), l = e("./nodejsUtils");
    function f(n2) {
      return new i.Promise(function(e2, t2) {
        var r2 = n2.decompressed.getContentWorker().pipe(new a());
        r2.on("error", function(e3) {
          t2(e3);
        }).on("end", function() {
          r2.streamInfo.crc32 !== n2.decompressed.crc32 ? t2(new Error("Corrupted zip : CRC32 mismatch")) : e2();
        }).resume();
      });
    }
    t.exports = function(e2, o) {
      var h = this;
      return o = u.extend(o || {}, { base64: false, checkCRC32: false, optimizedBinaryString: false, createFolders: false, decodeFileName: n.utf8decode }), l.isNode && l.isStream(e2) ? i.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")) : u.prepareContent("the loaded zip file", e2, true, o.optimizedBinaryString, o.base64).then(function(e3) {
        var t2 = new s(o);
        return t2.load(e3), t2;
      }).then(function(e3) {
        var t2 = [i.Promise.resolve(e3)], r2 = e3.files;
        if (o.checkCRC32)
          for (var n2 = 0; n2 < r2.length; n2++)
            t2.push(f(r2[n2]));
        return i.Promise.all(t2);
      }).then(function(e3) {
        for (var t2 = e3.shift(), r2 = t2.files, n2 = 0; n2 < r2.length; n2++) {
          var i2 = r2[n2], s2 = i2.fileNameStr, a2 = u.resolve(i2.fileNameStr);
          h.file(a2, i2.decompressed, { binary: true, optimizedBinaryString: true, date: i2.date, dir: i2.dir, comment: i2.fileCommentStr.length ? i2.fileCommentStr : null, unixPermissions: i2.unixPermissions, dosPermissions: i2.dosPermissions, createFolders: o.createFolders }), i2.dir || (h.file(a2).unsafeOriginalName = s2);
        }
        return t2.zipComment.length && (h.comment = t2.zipComment), h;
      });
    };
  }, { "./external": 6, "./nodejsUtils": 14, "./stream/Crc32Probe": 25, "./utf8": 31, "./utils": 32, "./zipEntries": 33 }], 12: [function(e, t, r) {
    "use strict";
    var n = e("../utils"), i = e("../stream/GenericWorker");
    function s(e2, t2) {
      i.call(this, "Nodejs stream input adapter for " + e2), this._upstreamEnded = false, this._bindStream(t2);
    }
    n.inherits(s, i), s.prototype._bindStream = function(e2) {
      var t2 = this;
      (this._stream = e2).pause(), e2.on("data", function(e3) {
        t2.push({ data: e3, meta: { percent: 0 } });
      }).on("error", function(e3) {
        t2.isPaused ? this.generatedError = e3 : t2.error(e3);
      }).on("end", function() {
        t2.isPaused ? t2._upstreamEnded = true : t2.end();
      });
    }, s.prototype.pause = function() {
      return !!i.prototype.pause.call(this) && (this._stream.pause(), true);
    }, s.prototype.resume = function() {
      return !!i.prototype.resume.call(this) && (this._upstreamEnded ? this.end() : this._stream.resume(), true);
    }, t.exports = s;
  }, { "../stream/GenericWorker": 28, "../utils": 32 }], 13: [function(e, t, r) {
    "use strict";
    var i = e("readable-stream").Readable;
    function n(e2, t2, r2) {
      i.call(this, t2), this._helper = e2;
      var n2 = this;
      e2.on("data", function(e3, t3) {
        n2.push(e3) || n2._helper.pause(), r2 && r2(t3);
      }).on("error", function(e3) {
        n2.emit("error", e3);
      }).on("end", function() {
        n2.push(null);
      });
    }
    e("../utils").inherits(n, i), n.prototype._read = function() {
      this._helper.resume();
    }, t.exports = n;
  }, { "../utils": 32, "readable-stream": 16 }], 14: [function(e, t, r) {
    "use strict";
    t.exports = { isNode: "undefined" != typeof Buffer, newBufferFrom: function(e2, t2) {
      if (Buffer.from && Buffer.from !== Uint8Array.from)
        return Buffer.from(e2, t2);
      if ("number" == typeof e2)
        throw new Error('The "data" argument must not be a number');
      return new Buffer(e2, t2);
    }, allocBuffer: function(e2) {
      if (Buffer.alloc)
        return Buffer.alloc(e2);
      var t2 = new Buffer(e2);
      return t2.fill(0), t2;
    }, isBuffer: function(e2) {
      return Buffer.isBuffer(e2);
    }, isStream: function(e2) {
      return e2 && "function" == typeof e2.on && "function" == typeof e2.pause && "function" == typeof e2.resume;
    } };
  }, {}], 15: [function(e, t, r) {
    "use strict";
    function s(e2, t2, r2) {
      var n2, i2 = u.getTypeOf(t2), s2 = u.extend(r2 || {}, f);
      s2.date = s2.date || new Date(), null !== s2.compression && (s2.compression = s2.compression.toUpperCase()), "string" == typeof s2.unixPermissions && (s2.unixPermissions = parseInt(s2.unixPermissions, 8)), s2.unixPermissions && 16384 & s2.unixPermissions && (s2.dir = true), s2.dosPermissions && 16 & s2.dosPermissions && (s2.dir = true), s2.dir && (e2 = g(e2)), s2.createFolders && (n2 = _(e2)) && b.call(this, n2, true);
      var a2 = "string" === i2 && false === s2.binary && false === s2.base64;
      r2 && void 0 !== r2.binary || (s2.binary = !a2), (t2 instanceof c && 0 === t2.uncompressedSize || s2.dir || !t2 || 0 === t2.length) && (s2.base64 = false, s2.binary = true, t2 = "", s2.compression = "STORE", i2 = "string");
      var o2 = null;
      o2 = t2 instanceof c || t2 instanceof l ? t2 : p.isNode && p.isStream(t2) ? new m(e2, t2) : u.prepareContent(e2, t2, s2.binary, s2.optimizedBinaryString, s2.base64);
      var h2 = new d(e2, o2, s2);
      this.files[e2] = h2;
    }
    var i = e("./utf8"), u = e("./utils"), l = e("./stream/GenericWorker"), a = e("./stream/StreamHelper"), f = e("./defaults"), c = e("./compressedObject"), d = e("./zipObject"), o = e("./generate"), p = e("./nodejsUtils"), m = e("./nodejs/NodejsStreamInputAdapter"), _ = function(e2) {
      "/" === e2.slice(-1) && (e2 = e2.substring(0, e2.length - 1));
      var t2 = e2.lastIndexOf("/");
      return 0 < t2 ? e2.substring(0, t2) : "";
    }, g = function(e2) {
      return "/" !== e2.slice(-1) && (e2 += "/"), e2;
    }, b = function(e2, t2) {
      return t2 = void 0 !== t2 ? t2 : f.createFolders, e2 = g(e2), this.files[e2] || s.call(this, e2, null, { dir: true, createFolders: t2 }), this.files[e2];
    };
    function h(e2) {
      return "[object RegExp]" === Object.prototype.toString.call(e2);
    }
    var n = { load: function() {
      throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
    }, forEach: function(e2) {
      var t2, r2, n2;
      for (t2 in this.files)
        n2 = this.files[t2], (r2 = t2.slice(this.root.length, t2.length)) && t2.slice(0, this.root.length) === this.root && e2(r2, n2);
    }, filter: function(r2) {
      var n2 = [];
      return this.forEach(function(e2, t2) {
        r2(e2, t2) && n2.push(t2);
      }), n2;
    }, file: function(e2, t2, r2) {
      if (1 !== arguments.length)
        return e2 = this.root + e2, s.call(this, e2, t2, r2), this;
      if (h(e2)) {
        var n2 = e2;
        return this.filter(function(e3, t3) {
          return !t3.dir && n2.test(e3);
        });
      }
      var i2 = this.files[this.root + e2];
      return i2 && !i2.dir ? i2 : null;
    }, folder: function(r2) {
      if (!r2)
        return this;
      if (h(r2))
        return this.filter(function(e3, t3) {
          return t3.dir && r2.test(e3);
        });
      var e2 = this.root + r2, t2 = b.call(this, e2), n2 = this.clone();
      return n2.root = t2.name, n2;
    }, remove: function(r2) {
      r2 = this.root + r2;
      var e2 = this.files[r2];
      if (e2 || ("/" !== r2.slice(-1) && (r2 += "/"), e2 = this.files[r2]), e2 && !e2.dir)
        delete this.files[r2];
      else
        for (var t2 = this.filter(function(e3, t3) {
          return t3.name.slice(0, r2.length) === r2;
        }), n2 = 0; n2 < t2.length; n2++)
          delete this.files[t2[n2].name];
      return this;
    }, generate: function(e2) {
      throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
    }, generateInternalStream: function(e2) {
      var t2, r2 = {};
      try {
        if ((r2 = u.extend(e2 || {}, { streamFiles: false, compression: "STORE", compressionOptions: null, type: "", platform: "DOS", comment: null, mimeType: "application/zip", encodeFileName: i.utf8encode })).type = r2.type.toLowerCase(), r2.compression = r2.compression.toUpperCase(), "binarystring" === r2.type && (r2.type = "string"), !r2.type)
          throw new Error("No output type specified.");
        u.checkSupport(r2.type), "darwin" !== r2.platform && "freebsd" !== r2.platform && "linux" !== r2.platform && "sunos" !== r2.platform || (r2.platform = "UNIX"), "win32" === r2.platform && (r2.platform = "DOS");
        var n2 = r2.comment || this.comment || "";
        t2 = o.generateWorker(this, r2, n2);
      } catch (e3) {
        (t2 = new l("error")).error(e3);
      }
      return new a(t2, r2.type || "string", r2.mimeType);
    }, generateAsync: function(e2, t2) {
      return this.generateInternalStream(e2).accumulate(t2);
    }, generateNodeStream: function(e2, t2) {
      return (e2 = e2 || {}).type || (e2.type = "nodebuffer"), this.generateInternalStream(e2).toNodejsStream(t2);
    } };
    t.exports = n;
  }, { "./compressedObject": 2, "./defaults": 5, "./generate": 9, "./nodejs/NodejsStreamInputAdapter": 12, "./nodejsUtils": 14, "./stream/GenericWorker": 28, "./stream/StreamHelper": 29, "./utf8": 31, "./utils": 32, "./zipObject": 35 }], 16: [function(e, t, r) {
    t.exports = e("stream");
  }, { stream: void 0 }], 17: [function(e, t, r) {
    "use strict";
    var n = e("./DataReader");
    function i(e2) {
      n.call(this, e2);
      for (var t2 = 0; t2 < this.data.length; t2++)
        e2[t2] = 255 & e2[t2];
    }
    e("../utils").inherits(i, n), i.prototype.byteAt = function(e2) {
      return this.data[this.zero + e2];
    }, i.prototype.lastIndexOfSignature = function(e2) {
      for (var t2 = e2.charCodeAt(0), r2 = e2.charCodeAt(1), n2 = e2.charCodeAt(2), i2 = e2.charCodeAt(3), s = this.length - 4; 0 <= s; --s)
        if (this.data[s] === t2 && this.data[s + 1] === r2 && this.data[s + 2] === n2 && this.data[s + 3] === i2)
          return s - this.zero;
      return -1;
    }, i.prototype.readAndCheckSignature = function(e2) {
      var t2 = e2.charCodeAt(0), r2 = e2.charCodeAt(1), n2 = e2.charCodeAt(2), i2 = e2.charCodeAt(3), s = this.readData(4);
      return t2 === s[0] && r2 === s[1] && n2 === s[2] && i2 === s[3];
    }, i.prototype.readData = function(e2) {
      if (this.checkOffset(e2), 0 === e2)
        return [];
      var t2 = this.data.slice(this.zero + this.index, this.zero + this.index + e2);
      return this.index += e2, t2;
    }, t.exports = i;
  }, { "../utils": 32, "./DataReader": 18 }], 18: [function(e, t, r) {
    "use strict";
    var n = e("../utils");
    function i(e2) {
      this.data = e2, this.length = e2.length, this.index = 0, this.zero = 0;
    }
    i.prototype = { checkOffset: function(e2) {
      this.checkIndex(this.index + e2);
    }, checkIndex: function(e2) {
      if (this.length < this.zero + e2 || e2 < 0)
        throw new Error("End of data reached (data length = " + this.length + ", asked index = " + e2 + "). Corrupted zip ?");
    }, setIndex: function(e2) {
      this.checkIndex(e2), this.index = e2;
    }, skip: function(e2) {
      this.setIndex(this.index + e2);
    }, byteAt: function(e2) {
    }, readInt: function(e2) {
      var t2, r2 = 0;
      for (this.checkOffset(e2), t2 = this.index + e2 - 1; t2 >= this.index; t2--)
        r2 = (r2 << 8) + this.byteAt(t2);
      return this.index += e2, r2;
    }, readString: function(e2) {
      return n.transformTo("string", this.readData(e2));
    }, readData: function(e2) {
    }, lastIndexOfSignature: function(e2) {
    }, readAndCheckSignature: function(e2) {
    }, readDate: function() {
      var e2 = this.readInt(4);
      return new Date(Date.UTC(1980 + (e2 >> 25 & 127), (e2 >> 21 & 15) - 1, e2 >> 16 & 31, e2 >> 11 & 31, e2 >> 5 & 63, (31 & e2) << 1));
    } }, t.exports = i;
  }, { "../utils": 32 }], 19: [function(e, t, r) {
    "use strict";
    var n = e("./Uint8ArrayReader");
    function i(e2) {
      n.call(this, e2);
    }
    e("../utils").inherits(i, n), i.prototype.readData = function(e2) {
      this.checkOffset(e2);
      var t2 = this.data.slice(this.zero + this.index, this.zero + this.index + e2);
      return this.index += e2, t2;
    }, t.exports = i;
  }, { "../utils": 32, "./Uint8ArrayReader": 21 }], 20: [function(e, t, r) {
    "use strict";
    var n = e("./DataReader");
    function i(e2) {
      n.call(this, e2);
    }
    e("../utils").inherits(i, n), i.prototype.byteAt = function(e2) {
      return this.data.charCodeAt(this.zero + e2);
    }, i.prototype.lastIndexOfSignature = function(e2) {
      return this.data.lastIndexOf(e2) - this.zero;
    }, i.prototype.readAndCheckSignature = function(e2) {
      return e2 === this.readData(4);
    }, i.prototype.readData = function(e2) {
      this.checkOffset(e2);
      var t2 = this.data.slice(this.zero + this.index, this.zero + this.index + e2);
      return this.index += e2, t2;
    }, t.exports = i;
  }, { "../utils": 32, "./DataReader": 18 }], 21: [function(e, t, r) {
    "use strict";
    var n = e("./ArrayReader");
    function i(e2) {
      n.call(this, e2);
    }
    e("../utils").inherits(i, n), i.prototype.readData = function(e2) {
      if (this.checkOffset(e2), 0 === e2)
        return new Uint8Array(0);
      var t2 = this.data.subarray(this.zero + this.index, this.zero + this.index + e2);
      return this.index += e2, t2;
    }, t.exports = i;
  }, { "../utils": 32, "./ArrayReader": 17 }], 22: [function(e, t, r) {
    "use strict";
    var n = e("../utils"), i = e("../support"), s = e("./ArrayReader"), a = e("./StringReader"), o = e("./NodeBufferReader"), h = e("./Uint8ArrayReader");
    t.exports = function(e2) {
      var t2 = n.getTypeOf(e2);
      return n.checkSupport(t2), "string" !== t2 || i.uint8array ? "nodebuffer" === t2 ? new o(e2) : i.uint8array ? new h(n.transformTo("uint8array", e2)) : new s(n.transformTo("array", e2)) : new a(e2);
    };
  }, { "../support": 30, "../utils": 32, "./ArrayReader": 17, "./NodeBufferReader": 19, "./StringReader": 20, "./Uint8ArrayReader": 21 }], 23: [function(e, t, r) {
    "use strict";
    r.LOCAL_FILE_HEADER = "PK", r.CENTRAL_FILE_HEADER = "PK", r.CENTRAL_DIRECTORY_END = "PK", r.ZIP64_CENTRAL_DIRECTORY_LOCATOR = "PK\x07", r.ZIP64_CENTRAL_DIRECTORY_END = "PK", r.DATA_DESCRIPTOR = "PK\x07\b";
  }, {}], 24: [function(e, t, r) {
    "use strict";
    var n = e("./GenericWorker"), i = e("../utils");
    function s(e2) {
      n.call(this, "ConvertWorker to " + e2), this.destType = e2;
    }
    i.inherits(s, n), s.prototype.processChunk = function(e2) {
      this.push({ data: i.transformTo(this.destType, e2.data), meta: e2.meta });
    }, t.exports = s;
  }, { "../utils": 32, "./GenericWorker": 28 }], 25: [function(e, t, r) {
    "use strict";
    var n = e("./GenericWorker"), i = e("../crc32");
    function s() {
      n.call(this, "Crc32Probe"), this.withStreamInfo("crc32", 0);
    }
    e("../utils").inherits(s, n), s.prototype.processChunk = function(e2) {
      this.streamInfo.crc32 = i(e2.data, this.streamInfo.crc32 || 0), this.push(e2);
    }, t.exports = s;
  }, { "../crc32": 4, "../utils": 32, "./GenericWorker": 28 }], 26: [function(e, t, r) {
    "use strict";
    var n = e("../utils"), i = e("./GenericWorker");
    function s(e2) {
      i.call(this, "DataLengthProbe for " + e2), this.propName = e2, this.withStreamInfo(e2, 0);
    }
    n.inherits(s, i), s.prototype.processChunk = function(e2) {
      if (e2) {
        var t2 = this.streamInfo[this.propName] || 0;
        this.streamInfo[this.propName] = t2 + e2.data.length;
      }
      i.prototype.processChunk.call(this, e2);
    }, t.exports = s;
  }, { "../utils": 32, "./GenericWorker": 28 }], 27: [function(e, t, r) {
    "use strict";
    var n = e("../utils"), i = e("./GenericWorker");
    function s(e2) {
      i.call(this, "DataWorker");
      var t2 = this;
      this.dataIsReady = false, this.index = 0, this.max = 0, this.data = null, this.type = "", this._tickScheduled = false, e2.then(function(e3) {
        t2.dataIsReady = true, t2.data = e3, t2.max = e3 && e3.length || 0, t2.type = n.getTypeOf(e3), t2.isPaused || t2._tickAndRepeat();
      }, function(e3) {
        t2.error(e3);
      });
    }
    n.inherits(s, i), s.prototype.cleanUp = function() {
      i.prototype.cleanUp.call(this), this.data = null;
    }, s.prototype.resume = function() {
      return !!i.prototype.resume.call(this) && (!this._tickScheduled && this.dataIsReady && (this._tickScheduled = true, n.delay(this._tickAndRepeat, [], this)), true);
    }, s.prototype._tickAndRepeat = function() {
      this._tickScheduled = false, this.isPaused || this.isFinished || (this._tick(), this.isFinished || (n.delay(this._tickAndRepeat, [], this), this._tickScheduled = true));
    }, s.prototype._tick = function() {
      if (this.isPaused || this.isFinished)
        return false;
      var e2 = null, t2 = Math.min(this.max, this.index + 16384);
      if (this.index >= this.max)
        return this.end();
      switch (this.type) {
        case "string":
          e2 = this.data.substring(this.index, t2);
          break;
        case "uint8array":
          e2 = this.data.subarray(this.index, t2);
          break;
        case "array":
        case "nodebuffer":
          e2 = this.data.slice(this.index, t2);
      }
      return this.index = t2, this.push({ data: e2, meta: { percent: this.max ? this.index / this.max * 100 : 0 } });
    }, t.exports = s;
  }, { "../utils": 32, "./GenericWorker": 28 }], 28: [function(e, t, r) {
    "use strict";
    function n(e2) {
      this.name = e2 || "default", this.streamInfo = {}, this.generatedError = null, this.extraStreamInfo = {}, this.isPaused = true, this.isFinished = false, this.isLocked = false, this._listeners = { data: [], end: [], error: [] }, this.previous = null;
    }
    n.prototype = { push: function(e2) {
      this.emit("data", e2);
    }, end: function() {
      if (this.isFinished)
        return false;
      this.flush();
      try {
        this.emit("end"), this.cleanUp(), this.isFinished = true;
      } catch (e2) {
        this.emit("error", e2);
      }
      return true;
    }, error: function(e2) {
      return !this.isFinished && (this.isPaused ? this.generatedError = e2 : (this.isFinished = true, this.emit("error", e2), this.previous && this.previous.error(e2), this.cleanUp()), true);
    }, on: function(e2, t2) {
      return this._listeners[e2].push(t2), this;
    }, cleanUp: function() {
      this.streamInfo = this.generatedError = this.extraStreamInfo = null, this._listeners = [];
    }, emit: function(e2, t2) {
      if (this._listeners[e2])
        for (var r2 = 0; r2 < this._listeners[e2].length; r2++)
          this._listeners[e2][r2].call(this, t2);
    }, pipe: function(e2) {
      return e2.registerPrevious(this);
    }, registerPrevious: function(e2) {
      if (this.isLocked)
        throw new Error("The stream '" + this + "' has already been used.");
      this.streamInfo = e2.streamInfo, this.mergeStreamInfo(), this.previous = e2;
      var t2 = this;
      return e2.on("data", function(e3) {
        t2.processChunk(e3);
      }), e2.on("end", function() {
        t2.end();
      }), e2.on("error", function(e3) {
        t2.error(e3);
      }), this;
    }, pause: function() {
      return !this.isPaused && !this.isFinished && (this.isPaused = true, this.previous && this.previous.pause(), true);
    }, resume: function() {
      if (!this.isPaused || this.isFinished)
        return false;
      var e2 = this.isPaused = false;
      return this.generatedError && (this.error(this.generatedError), e2 = true), this.previous && this.previous.resume(), !e2;
    }, flush: function() {
    }, processChunk: function(e2) {
      this.push(e2);
    }, withStreamInfo: function(e2, t2) {
      return this.extraStreamInfo[e2] = t2, this.mergeStreamInfo(), this;
    }, mergeStreamInfo: function() {
      for (var e2 in this.extraStreamInfo)
        this.extraStreamInfo.hasOwnProperty(e2) && (this.streamInfo[e2] = this.extraStreamInfo[e2]);
    }, lock: function() {
      if (this.isLocked)
        throw new Error("The stream '" + this + "' has already been used.");
      this.isLocked = true, this.previous && this.previous.lock();
    }, toString: function() {
      var e2 = "Worker " + this.name;
      return this.previous ? this.previous + " -> " + e2 : e2;
    } }, t.exports = n;
  }, {}], 29: [function(e, t, r) {
    "use strict";
    var h = e("../utils"), i = e("./ConvertWorker"), s = e("./GenericWorker"), u = e("../base64"), n = e("../support"), a = e("../external"), o = null;
    if (n.nodestream)
      try {
        o = e("../nodejs/NodejsStreamOutputAdapter");
      } catch (e2) {
      }
    function l(e2, o2) {
      return new a.Promise(function(t2, r2) {
        var n2 = [], i2 = e2._internalType, s2 = e2._outputType, a2 = e2._mimeType;
        e2.on("data", function(e3, t3) {
          n2.push(e3), o2 && o2(t3);
        }).on("error", function(e3) {
          n2 = [], r2(e3);
        }).on("end", function() {
          try {
            var e3 = function(e4, t3, r3) {
              switch (e4) {
                case "blob":
                  return h.newBlob(h.transformTo("arraybuffer", t3), r3);
                case "base64":
                  return u.encode(t3);
                default:
                  return h.transformTo(e4, t3);
              }
            }(s2, function(e4, t3) {
              var r3, n3 = 0, i3 = null, s3 = 0;
              for (r3 = 0; r3 < t3.length; r3++)
                s3 += t3[r3].length;
              switch (e4) {
                case "string":
                  return t3.join("");
                case "array":
                  return Array.prototype.concat.apply([], t3);
                case "uint8array":
                  for (i3 = new Uint8Array(s3), r3 = 0; r3 < t3.length; r3++)
                    i3.set(t3[r3], n3), n3 += t3[r3].length;
                  return i3;
                case "nodebuffer":
                  return Buffer.concat(t3);
                default:
                  throw new Error("concat : unsupported type '" + e4 + "'");
              }
            }(i2, n2), a2);
            t2(e3);
          } catch (e4) {
            r2(e4);
          }
          n2 = [];
        }).resume();
      });
    }
    function f(e2, t2, r2) {
      var n2 = t2;
      switch (t2) {
        case "blob":
        case "arraybuffer":
          n2 = "uint8array";
          break;
        case "base64":
          n2 = "string";
      }
      try {
        this._internalType = n2, this._outputType = t2, this._mimeType = r2, h.checkSupport(n2), this._worker = e2.pipe(new i(n2)), e2.lock();
      } catch (e3) {
        this._worker = new s("error"), this._worker.error(e3);
      }
    }
    f.prototype = { accumulate: function(e2) {
      return l(this, e2);
    }, on: function(e2, t2) {
      var r2 = this;
      return "data" === e2 ? this._worker.on(e2, function(e3) {
        t2.call(r2, e3.data, e3.meta);
      }) : this._worker.on(e2, function() {
        h.delay(t2, arguments, r2);
      }), this;
    }, resume: function() {
      return h.delay(this._worker.resume, [], this._worker), this;
    }, pause: function() {
      return this._worker.pause(), this;
    }, toNodejsStream: function(e2) {
      if (h.checkSupport("nodestream"), "nodebuffer" !== this._outputType)
        throw new Error(this._outputType + " is not supported by this method");
      return new o(this, { objectMode: "nodebuffer" !== this._outputType }, e2);
    } }, t.exports = f;
  }, { "../base64": 1, "../external": 6, "../nodejs/NodejsStreamOutputAdapter": 13, "../support": 30, "../utils": 32, "./ConvertWorker": 24, "./GenericWorker": 28 }], 30: [function(e, t, r) {
    "use strict";
    if (r.base64 = true, r.array = true, r.string = true, r.arraybuffer = "undefined" != typeof ArrayBuffer && "undefined" != typeof Uint8Array, r.nodebuffer = "undefined" != typeof Buffer, r.uint8array = "undefined" != typeof Uint8Array, "undefined" == typeof ArrayBuffer)
      r.blob = false;
    else {
      var n = new ArrayBuffer(0);
      try {
        r.blob = 0 === new Blob([n], { type: "application/zip" }).size;
      } catch (e2) {
        try {
          var i = new (self.BlobBuilder || self.WebKitBlobBuilder || self.MozBlobBuilder || self.MSBlobBuilder)();
          i.append(n), r.blob = 0 === i.getBlob("application/zip").size;
        } catch (e3) {
          r.blob = false;
        }
      }
    }
    try {
      r.nodestream = !!e("readable-stream").Readable;
    } catch (e2) {
      r.nodestream = false;
    }
  }, { "readable-stream": 16 }], 31: [function(e, t, s) {
    "use strict";
    for (var o = e("./utils"), h = e("./support"), r = e("./nodejsUtils"), n = e("./stream/GenericWorker"), u = new Array(256), i = 0; i < 256; i++)
      u[i] = 252 <= i ? 6 : 248 <= i ? 5 : 240 <= i ? 4 : 224 <= i ? 3 : 192 <= i ? 2 : 1;
    u[254] = u[254] = 1;
    function a() {
      n.call(this, "utf-8 decode"), this.leftOver = null;
    }
    function l() {
      n.call(this, "utf-8 encode");
    }
    s.utf8encode = function(e2) {
      return h.nodebuffer ? r.newBufferFrom(e2, "utf-8") : function(e3) {
        var t2, r2, n2, i2, s2, a2 = e3.length, o2 = 0;
        for (i2 = 0; i2 < a2; i2++)
          55296 == (64512 & (r2 = e3.charCodeAt(i2))) && i2 + 1 < a2 && 56320 == (64512 & (n2 = e3.charCodeAt(i2 + 1))) && (r2 = 65536 + (r2 - 55296 << 10) + (n2 - 56320), i2++), o2 += r2 < 128 ? 1 : r2 < 2048 ? 2 : r2 < 65536 ? 3 : 4;
        for (t2 = h.uint8array ? new Uint8Array(o2) : new Array(o2), i2 = s2 = 0; s2 < o2; i2++)
          55296 == (64512 & (r2 = e3.charCodeAt(i2))) && i2 + 1 < a2 && 56320 == (64512 & (n2 = e3.charCodeAt(i2 + 1))) && (r2 = 65536 + (r2 - 55296 << 10) + (n2 - 56320), i2++), r2 < 128 ? t2[s2++] = r2 : (r2 < 2048 ? t2[s2++] = 192 | r2 >>> 6 : (r2 < 65536 ? t2[s2++] = 224 | r2 >>> 12 : (t2[s2++] = 240 | r2 >>> 18, t2[s2++] = 128 | r2 >>> 12 & 63), t2[s2++] = 128 | r2 >>> 6 & 63), t2[s2++] = 128 | 63 & r2);
        return t2;
      }(e2);
    }, s.utf8decode = function(e2) {
      return h.nodebuffer ? o.transformTo("nodebuffer", e2).toString("utf-8") : function(e3) {
        var t2, r2, n2, i2, s2 = e3.length, a2 = new Array(2 * s2);
        for (t2 = r2 = 0; t2 < s2; )
          if ((n2 = e3[t2++]) < 128)
            a2[r2++] = n2;
          else if (4 < (i2 = u[n2]))
            a2[r2++] = 65533, t2 += i2 - 1;
          else {
            for (n2 &= 2 === i2 ? 31 : 3 === i2 ? 15 : 7; 1 < i2 && t2 < s2; )
              n2 = n2 << 6 | 63 & e3[t2++], i2--;
            1 < i2 ? a2[r2++] = 65533 : n2 < 65536 ? a2[r2++] = n2 : (n2 -= 65536, a2[r2++] = 55296 | n2 >> 10 & 1023, a2[r2++] = 56320 | 1023 & n2);
          }
        return a2.length !== r2 && (a2.subarray ? a2 = a2.subarray(0, r2) : a2.length = r2), o.applyFromCharCode(a2);
      }(e2 = o.transformTo(h.uint8array ? "uint8array" : "array", e2));
    }, o.inherits(a, n), a.prototype.processChunk = function(e2) {
      var t2 = o.transformTo(h.uint8array ? "uint8array" : "array", e2.data);
      if (this.leftOver && this.leftOver.length) {
        if (h.uint8array) {
          var r2 = t2;
          (t2 = new Uint8Array(r2.length + this.leftOver.length)).set(this.leftOver, 0), t2.set(r2, this.leftOver.length);
        } else
          t2 = this.leftOver.concat(t2);
        this.leftOver = null;
      }
      var n2 = function(e3, t3) {
        var r3;
        for ((t3 = t3 || e3.length) > e3.length && (t3 = e3.length), r3 = t3 - 1; 0 <= r3 && 128 == (192 & e3[r3]); )
          r3--;
        return r3 < 0 ? t3 : 0 === r3 ? t3 : r3 + u[e3[r3]] > t3 ? r3 : t3;
      }(t2), i2 = t2;
      n2 !== t2.length && (h.uint8array ? (i2 = t2.subarray(0, n2), this.leftOver = t2.subarray(n2, t2.length)) : (i2 = t2.slice(0, n2), this.leftOver = t2.slice(n2, t2.length))), this.push({ data: s.utf8decode(i2), meta: e2.meta });
    }, a.prototype.flush = function() {
      this.leftOver && this.leftOver.length && (this.push({ data: s.utf8decode(this.leftOver), meta: {} }), this.leftOver = null);
    }, s.Utf8DecodeWorker = a, o.inherits(l, n), l.prototype.processChunk = function(e2) {
      this.push({ data: s.utf8encode(e2.data), meta: e2.meta });
    }, s.Utf8EncodeWorker = l;
  }, { "./nodejsUtils": 14, "./stream/GenericWorker": 28, "./support": 30, "./utils": 32 }], 32: [function(e, t, a) {
    "use strict";
    var o = e("./support"), h = e("./base64"), r = e("./nodejsUtils"), u = e("./external");
    function n(e2) {
      return e2;
    }
    function l(e2, t2) {
      for (var r2 = 0; r2 < e2.length; ++r2)
        t2[r2] = 255 & e2.charCodeAt(r2);
      return t2;
    }
    e("setimmediate"), a.newBlob = function(t2, r2) {
      a.checkSupport("blob");
      try {
        return new Blob([t2], { type: r2 });
      } catch (e2) {
        try {
          var n2 = new (self.BlobBuilder || self.WebKitBlobBuilder || self.MozBlobBuilder || self.MSBlobBuilder)();
          return n2.append(t2), n2.getBlob(r2);
        } catch (e3) {
          throw new Error("Bug : can't construct the Blob.");
        }
      }
    };
    var i = { stringifyByChunk: function(e2, t2, r2) {
      var n2 = [], i2 = 0, s2 = e2.length;
      if (s2 <= r2)
        return String.fromCharCode.apply(null, e2);
      for (; i2 < s2; )
        "array" === t2 || "nodebuffer" === t2 ? n2.push(String.fromCharCode.apply(null, e2.slice(i2, Math.min(i2 + r2, s2)))) : n2.push(String.fromCharCode.apply(null, e2.subarray(i2, Math.min(i2 + r2, s2)))), i2 += r2;
      return n2.join("");
    }, stringifyByChar: function(e2) {
      for (var t2 = "", r2 = 0; r2 < e2.length; r2++)
        t2 += String.fromCharCode(e2[r2]);
      return t2;
    }, applyCanBeUsed: { uint8array: function() {
      try {
        return o.uint8array && 1 === String.fromCharCode.apply(null, new Uint8Array(1)).length;
      } catch (e2) {
        return false;
      }
    }(), nodebuffer: function() {
      try {
        return o.nodebuffer && 1 === String.fromCharCode.apply(null, r.allocBuffer(1)).length;
      } catch (e2) {
        return false;
      }
    }() } };
    function s(e2) {
      var t2 = 65536, r2 = a.getTypeOf(e2), n2 = true;
      if ("uint8array" === r2 ? n2 = i.applyCanBeUsed.uint8array : "nodebuffer" === r2 && (n2 = i.applyCanBeUsed.nodebuffer), n2)
        for (; 1 < t2; )
          try {
            return i.stringifyByChunk(e2, r2, t2);
          } catch (e3) {
            t2 = Math.floor(t2 / 2);
          }
      return i.stringifyByChar(e2);
    }
    function f(e2, t2) {
      for (var r2 = 0; r2 < e2.length; r2++)
        t2[r2] = e2[r2];
      return t2;
    }
    a.applyFromCharCode = s;
    var c = {};
    c.string = { string: n, array: function(e2) {
      return l(e2, new Array(e2.length));
    }, arraybuffer: function(e2) {
      return c.string.uint8array(e2).buffer;
    }, uint8array: function(e2) {
      return l(e2, new Uint8Array(e2.length));
    }, nodebuffer: function(e2) {
      return l(e2, r.allocBuffer(e2.length));
    } }, c.array = { string: s, array: n, arraybuffer: function(e2) {
      return new Uint8Array(e2).buffer;
    }, uint8array: function(e2) {
      return new Uint8Array(e2);
    }, nodebuffer: function(e2) {
      return r.newBufferFrom(e2);
    } }, c.arraybuffer = { string: function(e2) {
      return s(new Uint8Array(e2));
    }, array: function(e2) {
      return f(new Uint8Array(e2), new Array(e2.byteLength));
    }, arraybuffer: n, uint8array: function(e2) {
      return new Uint8Array(e2);
    }, nodebuffer: function(e2) {
      return r.newBufferFrom(new Uint8Array(e2));
    } }, c.uint8array = { string: s, array: function(e2) {
      return f(e2, new Array(e2.length));
    }, arraybuffer: function(e2) {
      return e2.buffer;
    }, uint8array: n, nodebuffer: function(e2) {
      return r.newBufferFrom(e2);
    } }, c.nodebuffer = { string: s, array: function(e2) {
      return f(e2, new Array(e2.length));
    }, arraybuffer: function(e2) {
      return c.nodebuffer.uint8array(e2).buffer;
    }, uint8array: function(e2) {
      return f(e2, new Uint8Array(e2.length));
    }, nodebuffer: n }, a.transformTo = function(e2, t2) {
      if (t2 = t2 || "", !e2)
        return t2;
      a.checkSupport(e2);
      var r2 = a.getTypeOf(t2);
      return c[r2][e2](t2);
    }, a.resolve = function(e2) {
      for (var t2 = e2.split("/"), r2 = [], n2 = 0; n2 < t2.length; n2++) {
        var i2 = t2[n2];
        "." === i2 || "" === i2 && 0 !== n2 && n2 !== t2.length - 1 || (".." === i2 ? r2.pop() : r2.push(i2));
      }
      return r2.join("/");
    }, a.getTypeOf = function(e2) {
      return "string" == typeof e2 ? "string" : "[object Array]" === Object.prototype.toString.call(e2) ? "array" : o.nodebuffer && r.isBuffer(e2) ? "nodebuffer" : o.uint8array && e2 instanceof Uint8Array ? "uint8array" : o.arraybuffer && e2 instanceof ArrayBuffer ? "arraybuffer" : void 0;
    }, a.checkSupport = function(e2) {
      if (!o[e2.toLowerCase()])
        throw new Error(e2 + " is not supported by this platform");
    }, a.MAX_VALUE_16BITS = 65535, a.MAX_VALUE_32BITS = -1, a.pretty = function(e2) {
      var t2, r2, n2 = "";
      for (r2 = 0; r2 < (e2 || "").length; r2++)
        n2 += "\\x" + ((t2 = e2.charCodeAt(r2)) < 16 ? "0" : "") + t2.toString(16).toUpperCase();
      return n2;
    }, a.delay = function(e2, t2, r2) {
      setImmediate(function() {
        e2.apply(r2 || null, t2 || []);
      });
    }, a.inherits = function(e2, t2) {
      function r2() {
      }
      r2.prototype = t2.prototype, e2.prototype = new r2();
    }, a.extend = function() {
      var e2, t2, r2 = {};
      for (e2 = 0; e2 < arguments.length; e2++)
        for (t2 in arguments[e2])
          arguments[e2].hasOwnProperty(t2) && void 0 === r2[t2] && (r2[t2] = arguments[e2][t2]);
      return r2;
    }, a.prepareContent = function(r2, e2, n2, i2, s2) {
      return u.Promise.resolve(e2).then(function(n3) {
        return o.blob && (n3 instanceof Blob || -1 !== ["[object File]", "[object Blob]"].indexOf(Object.prototype.toString.call(n3))) && "undefined" != typeof FileReader ? new u.Promise(function(t2, r3) {
          var e3 = new FileReader();
          e3.onload = function(e4) {
            t2(e4.target.result);
          }, e3.onerror = function(e4) {
            r3(e4.target.error);
          }, e3.readAsArrayBuffer(n3);
        }) : n3;
      }).then(function(e3) {
        var t2 = a.getTypeOf(e3);
        return t2 ? ("arraybuffer" === t2 ? e3 = a.transformTo("uint8array", e3) : "string" === t2 && (s2 ? e3 = h.decode(e3) : n2 && true !== i2 && (e3 = function(e4) {
          return l(e4, o.uint8array ? new Uint8Array(e4.length) : new Array(e4.length));
        }(e3))), e3) : u.Promise.reject(new Error("Can't read the data of '" + r2 + "'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"));
      });
    };
  }, { "./base64": 1, "./external": 6, "./nodejsUtils": 14, "./support": 30, setimmediate: 54 }], 33: [function(e, t, r) {
    "use strict";
    var n = e("./reader/readerFor"), i = e("./utils"), s = e("./signature"), a = e("./zipEntry"), o = (e("./utf8"), e("./support"));
    function h(e2) {
      this.files = [], this.loadOptions = e2;
    }
    h.prototype = { checkSignature: function(e2) {
      if (!this.reader.readAndCheckSignature(e2)) {
        this.reader.index -= 4;
        var t2 = this.reader.readString(4);
        throw new Error("Corrupted zip or bug: unexpected signature (" + i.pretty(t2) + ", expected " + i.pretty(e2) + ")");
      }
    }, isSignature: function(e2, t2) {
      var r2 = this.reader.index;
      this.reader.setIndex(e2);
      var n2 = this.reader.readString(4) === t2;
      return this.reader.setIndex(r2), n2;
    }, readBlockEndOfCentral: function() {
      this.diskNumber = this.reader.readInt(2), this.diskWithCentralDirStart = this.reader.readInt(2), this.centralDirRecordsOnThisDisk = this.reader.readInt(2), this.centralDirRecords = this.reader.readInt(2), this.centralDirSize = this.reader.readInt(4), this.centralDirOffset = this.reader.readInt(4), this.zipCommentLength = this.reader.readInt(2);
      var e2 = this.reader.readData(this.zipCommentLength), t2 = o.uint8array ? "uint8array" : "array", r2 = i.transformTo(t2, e2);
      this.zipComment = this.loadOptions.decodeFileName(r2);
    }, readBlockZip64EndOfCentral: function() {
      this.zip64EndOfCentralSize = this.reader.readInt(8), this.reader.skip(4), this.diskNumber = this.reader.readInt(4), this.diskWithCentralDirStart = this.reader.readInt(4), this.centralDirRecordsOnThisDisk = this.reader.readInt(8), this.centralDirRecords = this.reader.readInt(8), this.centralDirSize = this.reader.readInt(8), this.centralDirOffset = this.reader.readInt(8), this.zip64ExtensibleData = {};
      for (var e2, t2, r2, n2 = this.zip64EndOfCentralSize - 44; 0 < n2; )
        e2 = this.reader.readInt(2), t2 = this.reader.readInt(4), r2 = this.reader.readData(t2), this.zip64ExtensibleData[e2] = { id: e2, length: t2, value: r2 };
    }, readBlockZip64EndOfCentralLocator: function() {
      if (this.diskWithZip64CentralDirStart = this.reader.readInt(4), this.relativeOffsetEndOfZip64CentralDir = this.reader.readInt(8), this.disksCount = this.reader.readInt(4), 1 < this.disksCount)
        throw new Error("Multi-volumes zip are not supported");
    }, readLocalFiles: function() {
      var e2, t2;
      for (e2 = 0; e2 < this.files.length; e2++)
        t2 = this.files[e2], this.reader.setIndex(t2.localHeaderOffset), this.checkSignature(s.LOCAL_FILE_HEADER), t2.readLocalPart(this.reader), t2.handleUTF8(), t2.processAttributes();
    }, readCentralDir: function() {
      var e2;
      for (this.reader.setIndex(this.centralDirOffset); this.reader.readAndCheckSignature(s.CENTRAL_FILE_HEADER); )
        (e2 = new a({ zip64: this.zip64 }, this.loadOptions)).readCentralPart(this.reader), this.files.push(e2);
      if (this.centralDirRecords !== this.files.length && 0 !== this.centralDirRecords && 0 === this.files.length)
        throw new Error("Corrupted zip or bug: expected " + this.centralDirRecords + " records in central dir, got " + this.files.length);
    }, readEndOfCentral: function() {
      var e2 = this.reader.lastIndexOfSignature(s.CENTRAL_DIRECTORY_END);
      if (e2 < 0)
        throw !this.isSignature(0, s.LOCAL_FILE_HEADER) ? new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html") : new Error("Corrupted zip: can't find end of central directory");
      this.reader.setIndex(e2);
      var t2 = e2;
      if (this.checkSignature(s.CENTRAL_DIRECTORY_END), this.readBlockEndOfCentral(), this.diskNumber === i.MAX_VALUE_16BITS || this.diskWithCentralDirStart === i.MAX_VALUE_16BITS || this.centralDirRecordsOnThisDisk === i.MAX_VALUE_16BITS || this.centralDirRecords === i.MAX_VALUE_16BITS || this.centralDirSize === i.MAX_VALUE_32BITS || this.centralDirOffset === i.MAX_VALUE_32BITS) {
        if (this.zip64 = true, (e2 = this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR)) < 0)
          throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");
        if (this.reader.setIndex(e2), this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR), this.readBlockZip64EndOfCentralLocator(), !this.isSignature(this.relativeOffsetEndOfZip64CentralDir, s.ZIP64_CENTRAL_DIRECTORY_END) && (this.relativeOffsetEndOfZip64CentralDir = this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_END), this.relativeOffsetEndOfZip64CentralDir < 0))
          throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");
        this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir), this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_END), this.readBlockZip64EndOfCentral();
      }
      var r2 = this.centralDirOffset + this.centralDirSize;
      this.zip64 && (r2 += 20, r2 += 12 + this.zip64EndOfCentralSize);
      var n2 = t2 - r2;
      if (0 < n2)
        this.isSignature(t2, s.CENTRAL_FILE_HEADER) || (this.reader.zero = n2);
      else if (n2 < 0)
        throw new Error("Corrupted zip: missing " + Math.abs(n2) + " bytes.");
    }, prepareReader: function(e2) {
      this.reader = n(e2);
    }, load: function(e2) {
      this.prepareReader(e2), this.readEndOfCentral(), this.readCentralDir(), this.readLocalFiles();
    } }, t.exports = h;
  }, { "./reader/readerFor": 22, "./signature": 23, "./support": 30, "./utf8": 31, "./utils": 32, "./zipEntry": 34 }], 34: [function(e, t, r) {
    "use strict";
    var n = e("./reader/readerFor"), s = e("./utils"), i = e("./compressedObject"), a = e("./crc32"), o = e("./utf8"), h = e("./compressions"), u = e("./support");
    function l(e2, t2) {
      this.options = e2, this.loadOptions = t2;
    }
    l.prototype = { isEncrypted: function() {
      return 1 == (1 & this.bitFlag);
    }, useUTF8: function() {
      return 2048 == (2048 & this.bitFlag);
    }, readLocalPart: function(e2) {
      var t2, r2;
      if (e2.skip(22), this.fileNameLength = e2.readInt(2), r2 = e2.readInt(2), this.fileName = e2.readData(this.fileNameLength), e2.skip(r2), -1 === this.compressedSize || -1 === this.uncompressedSize)
        throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");
      if (null === (t2 = function(e3) {
        for (var t3 in h)
          if (h.hasOwnProperty(t3) && h[t3].magic === e3)
            return h[t3];
        return null;
      }(this.compressionMethod)))
        throw new Error("Corrupted zip : compression " + s.pretty(this.compressionMethod) + " unknown (inner file : " + s.transformTo("string", this.fileName) + ")");
      this.decompressed = new i(this.compressedSize, this.uncompressedSize, this.crc32, t2, e2.readData(this.compressedSize));
    }, readCentralPart: function(e2) {
      this.versionMadeBy = e2.readInt(2), e2.skip(2), this.bitFlag = e2.readInt(2), this.compressionMethod = e2.readString(2), this.date = e2.readDate(), this.crc32 = e2.readInt(4), this.compressedSize = e2.readInt(4), this.uncompressedSize = e2.readInt(4);
      var t2 = e2.readInt(2);
      if (this.extraFieldsLength = e2.readInt(2), this.fileCommentLength = e2.readInt(2), this.diskNumberStart = e2.readInt(2), this.internalFileAttributes = e2.readInt(2), this.externalFileAttributes = e2.readInt(4), this.localHeaderOffset = e2.readInt(4), this.isEncrypted())
        throw new Error("Encrypted zip are not supported");
      e2.skip(t2), this.readExtraFields(e2), this.parseZIP64ExtraField(e2), this.fileComment = e2.readData(this.fileCommentLength);
    }, processAttributes: function() {
      this.unixPermissions = null, this.dosPermissions = null;
      var e2 = this.versionMadeBy >> 8;
      this.dir = !!(16 & this.externalFileAttributes), 0 == e2 && (this.dosPermissions = 63 & this.externalFileAttributes), 3 == e2 && (this.unixPermissions = this.externalFileAttributes >> 16 & 65535), this.dir || "/" !== this.fileNameStr.slice(-1) || (this.dir = true);
    }, parseZIP64ExtraField: function(e2) {
      if (this.extraFields[1]) {
        var t2 = n(this.extraFields[1].value);
        this.uncompressedSize === s.MAX_VALUE_32BITS && (this.uncompressedSize = t2.readInt(8)), this.compressedSize === s.MAX_VALUE_32BITS && (this.compressedSize = t2.readInt(8)), this.localHeaderOffset === s.MAX_VALUE_32BITS && (this.localHeaderOffset = t2.readInt(8)), this.diskNumberStart === s.MAX_VALUE_32BITS && (this.diskNumberStart = t2.readInt(4));
      }
    }, readExtraFields: function(e2) {
      var t2, r2, n2, i2 = e2.index + this.extraFieldsLength;
      for (this.extraFields || (this.extraFields = {}); e2.index + 4 < i2; )
        t2 = e2.readInt(2), r2 = e2.readInt(2), n2 = e2.readData(r2), this.extraFields[t2] = { id: t2, length: r2, value: n2 };
      e2.setIndex(i2);
    }, handleUTF8: function() {
      var e2 = u.uint8array ? "uint8array" : "array";
      if (this.useUTF8())
        this.fileNameStr = o.utf8decode(this.fileName), this.fileCommentStr = o.utf8decode(this.fileComment);
      else {
        var t2 = this.findExtraFieldUnicodePath();
        if (null !== t2)
          this.fileNameStr = t2;
        else {
          var r2 = s.transformTo(e2, this.fileName);
          this.fileNameStr = this.loadOptions.decodeFileName(r2);
        }
        var n2 = this.findExtraFieldUnicodeComment();
        if (null !== n2)
          this.fileCommentStr = n2;
        else {
          var i2 = s.transformTo(e2, this.fileComment);
          this.fileCommentStr = this.loadOptions.decodeFileName(i2);
        }
      }
    }, findExtraFieldUnicodePath: function() {
      var e2 = this.extraFields[28789];
      if (e2) {
        var t2 = n(e2.value);
        return 1 !== t2.readInt(1) ? null : a(this.fileName) !== t2.readInt(4) ? null : o.utf8decode(t2.readData(e2.length - 5));
      }
      return null;
    }, findExtraFieldUnicodeComment: function() {
      var e2 = this.extraFields[25461];
      if (e2) {
        var t2 = n(e2.value);
        return 1 !== t2.readInt(1) ? null : a(this.fileComment) !== t2.readInt(4) ? null : o.utf8decode(t2.readData(e2.length - 5));
      }
      return null;
    } }, t.exports = l;
  }, { "./compressedObject": 2, "./compressions": 3, "./crc32": 4, "./reader/readerFor": 22, "./support": 30, "./utf8": 31, "./utils": 32 }], 35: [function(e, t, r) {
    "use strict";
    function n(e2, t2, r2) {
      this.name = e2, this.dir = r2.dir, this.date = r2.date, this.comment = r2.comment, this.unixPermissions = r2.unixPermissions, this.dosPermissions = r2.dosPermissions, this._data = t2, this._dataBinary = r2.binary, this.options = { compression: r2.compression, compressionOptions: r2.compressionOptions };
    }
    var s = e("./stream/StreamHelper"), i = e("./stream/DataWorker"), a = e("./utf8"), o = e("./compressedObject"), h = e("./stream/GenericWorker");
    n.prototype = { internalStream: function(e2) {
      var t2 = null, r2 = "string";
      try {
        if (!e2)
          throw new Error("No output type specified.");
        var n2 = "string" === (r2 = e2.toLowerCase()) || "text" === r2;
        "binarystring" !== r2 && "text" !== r2 || (r2 = "string"), t2 = this._decompressWorker();
        var i2 = !this._dataBinary;
        i2 && !n2 && (t2 = t2.pipe(new a.Utf8EncodeWorker())), !i2 && n2 && (t2 = t2.pipe(new a.Utf8DecodeWorker()));
      } catch (e3) {
        (t2 = new h("error")).error(e3);
      }
      return new s(t2, r2, "");
    }, async: function(e2, t2) {
      return this.internalStream(e2).accumulate(t2);
    }, nodeStream: function(e2, t2) {
      return this.internalStream(e2 || "nodebuffer").toNodejsStream(t2);
    }, _compressWorker: function(e2, t2) {
      if (this._data instanceof o && this._data.compression.magic === e2.magic)
        return this._data.getCompressedWorker();
      var r2 = this._decompressWorker();
      return this._dataBinary || (r2 = r2.pipe(new a.Utf8EncodeWorker())), o.createWorkerFrom(r2, e2, t2);
    }, _decompressWorker: function() {
      return this._data instanceof o ? this._data.getContentWorker() : this._data instanceof h ? this._data : new i(this._data);
    } };
    for (var u = ["asText", "asBinary", "asNodeBuffer", "asUint8Array", "asArrayBuffer"], l = function() {
      throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.");
    }, f = 0; f < u.length; f++)
      n.prototype[u[f]] = l;
    t.exports = n;
  }, { "./compressedObject": 2, "./stream/DataWorker": 27, "./stream/GenericWorker": 28, "./stream/StreamHelper": 29, "./utf8": 31 }], 36: [function(e, l, t) {
    (function(t2) {
      "use strict";
      var r, n, e2 = t2.MutationObserver || t2.WebKitMutationObserver;
      if (e2) {
        var i = 0, s = new e2(u), a = t2.document.createTextNode("");
        s.observe(a, { characterData: true }), r = function() {
          a.data = i = ++i % 2;
        };
      } else if (t2.setImmediate || void 0 === t2.MessageChannel)
        r = "document" in t2 && "onreadystatechange" in t2.document.createElement("script") ? function() {
          var e3 = t2.document.createElement("script");
          e3.onreadystatechange = function() {
            u(), e3.onreadystatechange = null, e3.parentNode.removeChild(e3), e3 = null;
          }, t2.document.documentElement.appendChild(e3);
        } : function() {
          setTimeout(u, 0);
        };
      else {
        var o = new t2.MessageChannel();
        o.port1.onmessage = u, r = function() {
          o.port2.postMessage(0);
        };
      }
      var h = [];
      function u() {
        var e3, t3;
        n = true;
        for (var r2 = h.length; r2; ) {
          for (t3 = h, h = [], e3 = -1; ++e3 < r2; )
            t3[e3]();
          r2 = h.length;
        }
        n = false;
      }
      l.exports = function(e3) {
        1 !== h.push(e3) || n || r();
      };
    }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
  }, {}], 37: [function(e, t, r) {
    "use strict";
    var i = e("immediate");
    function u() {
    }
    var l = {}, s = ["REJECTED"], a = ["FULFILLED"], n = ["PENDING"];
    function o(e2) {
      if ("function" != typeof e2)
        throw new TypeError("resolver must be a function");
      this.state = n, this.queue = [], this.outcome = void 0, e2 !== u && d(this, e2);
    }
    function h(e2, t2, r2) {
      this.promise = e2, "function" == typeof t2 && (this.onFulfilled = t2, this.callFulfilled = this.otherCallFulfilled), "function" == typeof r2 && (this.onRejected = r2, this.callRejected = this.otherCallRejected);
    }
    function f(t2, r2, n2) {
      i(function() {
        var e2;
        try {
          e2 = r2(n2);
        } catch (e3) {
          return l.reject(t2, e3);
        }
        e2 === t2 ? l.reject(t2, new TypeError("Cannot resolve promise with itself")) : l.resolve(t2, e2);
      });
    }
    function c(e2) {
      var t2 = e2 && e2.then;
      if (e2 && ("object" == typeof e2 || "function" == typeof e2) && "function" == typeof t2)
        return function() {
          t2.apply(e2, arguments);
        };
    }
    function d(t2, e2) {
      var r2 = false;
      function n2(e3) {
        r2 || (r2 = true, l.reject(t2, e3));
      }
      function i2(e3) {
        r2 || (r2 = true, l.resolve(t2, e3));
      }
      var s2 = p(function() {
        e2(i2, n2);
      });
      "error" === s2.status && n2(s2.value);
    }
    function p(e2, t2) {
      var r2 = {};
      try {
        r2.value = e2(t2), r2.status = "success";
      } catch (e3) {
        r2.status = "error", r2.value = e3;
      }
      return r2;
    }
    (t.exports = o).prototype.finally = function(t2) {
      if ("function" != typeof t2)
        return this;
      var r2 = this.constructor;
      return this.then(function(e2) {
        return r2.resolve(t2()).then(function() {
          return e2;
        });
      }, function(e2) {
        return r2.resolve(t2()).then(function() {
          throw e2;
        });
      });
    }, o.prototype.catch = function(e2) {
      return this.then(null, e2);
    }, o.prototype.then = function(e2, t2) {
      if ("function" != typeof e2 && this.state === a || "function" != typeof t2 && this.state === s)
        return this;
      var r2 = new this.constructor(u);
      this.state !== n ? f(r2, this.state === a ? e2 : t2, this.outcome) : this.queue.push(new h(r2, e2, t2));
      return r2;
    }, h.prototype.callFulfilled = function(e2) {
      l.resolve(this.promise, e2);
    }, h.prototype.otherCallFulfilled = function(e2) {
      f(this.promise, this.onFulfilled, e2);
    }, h.prototype.callRejected = function(e2) {
      l.reject(this.promise, e2);
    }, h.prototype.otherCallRejected = function(e2) {
      f(this.promise, this.onRejected, e2);
    }, l.resolve = function(e2, t2) {
      var r2 = p(c, t2);
      if ("error" === r2.status)
        return l.reject(e2, r2.value);
      var n2 = r2.value;
      if (n2)
        d(e2, n2);
      else {
        e2.state = a, e2.outcome = t2;
        for (var i2 = -1, s2 = e2.queue.length; ++i2 < s2; )
          e2.queue[i2].callFulfilled(t2);
      }
      return e2;
    }, l.reject = function(e2, t2) {
      e2.state = s, e2.outcome = t2;
      for (var r2 = -1, n2 = e2.queue.length; ++r2 < n2; )
        e2.queue[r2].callRejected(t2);
      return e2;
    }, o.resolve = function(e2) {
      if (e2 instanceof this)
        return e2;
      return l.resolve(new this(u), e2);
    }, o.reject = function(e2) {
      var t2 = new this(u);
      return l.reject(t2, e2);
    }, o.all = function(e2) {
      var r2 = this;
      if ("[object Array]" !== Object.prototype.toString.call(e2))
        return this.reject(new TypeError("must be an array"));
      var n2 = e2.length, i2 = false;
      if (!n2)
        return this.resolve([]);
      var s2 = new Array(n2), a2 = 0, t2 = -1, o2 = new this(u);
      for (; ++t2 < n2; )
        h2(e2[t2], t2);
      return o2;
      function h2(e3, t3) {
        r2.resolve(e3).then(function(e4) {
          s2[t3] = e4, ++a2 !== n2 || i2 || (i2 = true, l.resolve(o2, s2));
        }, function(e4) {
          i2 || (i2 = true, l.reject(o2, e4));
        });
      }
    }, o.race = function(e2) {
      var t2 = this;
      if ("[object Array]" !== Object.prototype.toString.call(e2))
        return this.reject(new TypeError("must be an array"));
      var r2 = e2.length, n2 = false;
      if (!r2)
        return this.resolve([]);
      var i2 = -1, s2 = new this(u);
      for (; ++i2 < r2; )
        a2 = e2[i2], t2.resolve(a2).then(function(e3) {
          n2 || (n2 = true, l.resolve(s2, e3));
        }, function(e3) {
          n2 || (n2 = true, l.reject(s2, e3));
        });
      var a2;
      return s2;
    };
  }, { immediate: 36 }], 38: [function(e, t, r) {
    "use strict";
    var n = {};
    (0, e("./lib/utils/common").assign)(n, e("./lib/deflate"), e("./lib/inflate"), e("./lib/zlib/constants")), t.exports = n;
  }, { "./lib/deflate": 39, "./lib/inflate": 40, "./lib/utils/common": 41, "./lib/zlib/constants": 44 }], 39: [function(e, t, r) {
    "use strict";
    var a = e("./zlib/deflate"), o = e("./utils/common"), h = e("./utils/strings"), i = e("./zlib/messages"), s = e("./zlib/zstream"), u = Object.prototype.toString, l = 0, f = -1, c = 0, d = 8;
    function p(e2) {
      if (!(this instanceof p))
        return new p(e2);
      this.options = o.assign({ level: f, method: d, chunkSize: 16384, windowBits: 15, memLevel: 8, strategy: c, to: "" }, e2 || {});
      var t2 = this.options;
      t2.raw && 0 < t2.windowBits ? t2.windowBits = -t2.windowBits : t2.gzip && 0 < t2.windowBits && t2.windowBits < 16 && (t2.windowBits += 16), this.err = 0, this.msg = "", this.ended = false, this.chunks = [], this.strm = new s(), this.strm.avail_out = 0;
      var r2 = a.deflateInit2(this.strm, t2.level, t2.method, t2.windowBits, t2.memLevel, t2.strategy);
      if (r2 !== l)
        throw new Error(i[r2]);
      if (t2.header && a.deflateSetHeader(this.strm, t2.header), t2.dictionary) {
        var n2;
        if (n2 = "string" == typeof t2.dictionary ? h.string2buf(t2.dictionary) : "[object ArrayBuffer]" === u.call(t2.dictionary) ? new Uint8Array(t2.dictionary) : t2.dictionary, (r2 = a.deflateSetDictionary(this.strm, n2)) !== l)
          throw new Error(i[r2]);
        this._dict_set = true;
      }
    }
    function n(e2, t2) {
      var r2 = new p(t2);
      if (r2.push(e2, true), r2.err)
        throw r2.msg || i[r2.err];
      return r2.result;
    }
    p.prototype.push = function(e2, t2) {
      var r2, n2, i2 = this.strm, s2 = this.options.chunkSize;
      if (this.ended)
        return false;
      n2 = t2 === ~~t2 ? t2 : true === t2 ? 4 : 0, "string" == typeof e2 ? i2.input = h.string2buf(e2) : "[object ArrayBuffer]" === u.call(e2) ? i2.input = new Uint8Array(e2) : i2.input = e2, i2.next_in = 0, i2.avail_in = i2.input.length;
      do {
        if (0 === i2.avail_out && (i2.output = new o.Buf8(s2), i2.next_out = 0, i2.avail_out = s2), 1 !== (r2 = a.deflate(i2, n2)) && r2 !== l)
          return this.onEnd(r2), !(this.ended = true);
        0 !== i2.avail_out && (0 !== i2.avail_in || 4 !== n2 && 2 !== n2) || ("string" === this.options.to ? this.onData(h.buf2binstring(o.shrinkBuf(i2.output, i2.next_out))) : this.onData(o.shrinkBuf(i2.output, i2.next_out)));
      } while ((0 < i2.avail_in || 0 === i2.avail_out) && 1 !== r2);
      return 4 === n2 ? (r2 = a.deflateEnd(this.strm), this.onEnd(r2), this.ended = true, r2 === l) : 2 !== n2 || (this.onEnd(l), !(i2.avail_out = 0));
    }, p.prototype.onData = function(e2) {
      this.chunks.push(e2);
    }, p.prototype.onEnd = function(e2) {
      e2 === l && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = o.flattenChunks(this.chunks)), this.chunks = [], this.err = e2, this.msg = this.strm.msg;
    }, r.Deflate = p, r.deflate = n, r.deflateRaw = function(e2, t2) {
      return (t2 = t2 || {}).raw = true, n(e2, t2);
    }, r.gzip = function(e2, t2) {
      return (t2 = t2 || {}).gzip = true, n(e2, t2);
    };
  }, { "./utils/common": 41, "./utils/strings": 42, "./zlib/deflate": 46, "./zlib/messages": 51, "./zlib/zstream": 53 }], 40: [function(e, t, r) {
    "use strict";
    var c = e("./zlib/inflate"), d = e("./utils/common"), p = e("./utils/strings"), m = e("./zlib/constants"), n = e("./zlib/messages"), i = e("./zlib/zstream"), s = e("./zlib/gzheader"), _ = Object.prototype.toString;
    function a(e2) {
      if (!(this instanceof a))
        return new a(e2);
      this.options = d.assign({ chunkSize: 16384, windowBits: 0, to: "" }, e2 || {});
      var t2 = this.options;
      t2.raw && 0 <= t2.windowBits && t2.windowBits < 16 && (t2.windowBits = -t2.windowBits, 0 === t2.windowBits && (t2.windowBits = -15)), !(0 <= t2.windowBits && t2.windowBits < 16) || e2 && e2.windowBits || (t2.windowBits += 32), 15 < t2.windowBits && t2.windowBits < 48 && 0 == (15 & t2.windowBits) && (t2.windowBits |= 15), this.err = 0, this.msg = "", this.ended = false, this.chunks = [], this.strm = new i(), this.strm.avail_out = 0;
      var r2 = c.inflateInit2(this.strm, t2.windowBits);
      if (r2 !== m.Z_OK)
        throw new Error(n[r2]);
      this.header = new s(), c.inflateGetHeader(this.strm, this.header);
    }
    function o(e2, t2) {
      var r2 = new a(t2);
      if (r2.push(e2, true), r2.err)
        throw r2.msg || n[r2.err];
      return r2.result;
    }
    a.prototype.push = function(e2, t2) {
      var r2, n2, i2, s2, a2, o2, h = this.strm, u = this.options.chunkSize, l = this.options.dictionary, f = false;
      if (this.ended)
        return false;
      n2 = t2 === ~~t2 ? t2 : true === t2 ? m.Z_FINISH : m.Z_NO_FLUSH, "string" == typeof e2 ? h.input = p.binstring2buf(e2) : "[object ArrayBuffer]" === _.call(e2) ? h.input = new Uint8Array(e2) : h.input = e2, h.next_in = 0, h.avail_in = h.input.length;
      do {
        if (0 === h.avail_out && (h.output = new d.Buf8(u), h.next_out = 0, h.avail_out = u), (r2 = c.inflate(h, m.Z_NO_FLUSH)) === m.Z_NEED_DICT && l && (o2 = "string" == typeof l ? p.string2buf(l) : "[object ArrayBuffer]" === _.call(l) ? new Uint8Array(l) : l, r2 = c.inflateSetDictionary(this.strm, o2)), r2 === m.Z_BUF_ERROR && true === f && (r2 = m.Z_OK, f = false), r2 !== m.Z_STREAM_END && r2 !== m.Z_OK)
          return this.onEnd(r2), !(this.ended = true);
        h.next_out && (0 !== h.avail_out && r2 !== m.Z_STREAM_END && (0 !== h.avail_in || n2 !== m.Z_FINISH && n2 !== m.Z_SYNC_FLUSH) || ("string" === this.options.to ? (i2 = p.utf8border(h.output, h.next_out), s2 = h.next_out - i2, a2 = p.buf2string(h.output, i2), h.next_out = s2, h.avail_out = u - s2, s2 && d.arraySet(h.output, h.output, i2, s2, 0), this.onData(a2)) : this.onData(d.shrinkBuf(h.output, h.next_out)))), 0 === h.avail_in && 0 === h.avail_out && (f = true);
      } while ((0 < h.avail_in || 0 === h.avail_out) && r2 !== m.Z_STREAM_END);
      return r2 === m.Z_STREAM_END && (n2 = m.Z_FINISH), n2 === m.Z_FINISH ? (r2 = c.inflateEnd(this.strm), this.onEnd(r2), this.ended = true, r2 === m.Z_OK) : n2 !== m.Z_SYNC_FLUSH || (this.onEnd(m.Z_OK), !(h.avail_out = 0));
    }, a.prototype.onData = function(e2) {
      this.chunks.push(e2);
    }, a.prototype.onEnd = function(e2) {
      e2 === m.Z_OK && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = d.flattenChunks(this.chunks)), this.chunks = [], this.err = e2, this.msg = this.strm.msg;
    }, r.Inflate = a, r.inflate = o, r.inflateRaw = function(e2, t2) {
      return (t2 = t2 || {}).raw = true, o(e2, t2);
    }, r.ungzip = o;
  }, { "./utils/common": 41, "./utils/strings": 42, "./zlib/constants": 44, "./zlib/gzheader": 47, "./zlib/inflate": 49, "./zlib/messages": 51, "./zlib/zstream": 53 }], 41: [function(e, t, r) {
    "use strict";
    var n = "undefined" != typeof Uint8Array && "undefined" != typeof Uint16Array && "undefined" != typeof Int32Array;
    r.assign = function(e2) {
      for (var t2 = Array.prototype.slice.call(arguments, 1); t2.length; ) {
        var r2 = t2.shift();
        if (r2) {
          if ("object" != typeof r2)
            throw new TypeError(r2 + "must be non-object");
          for (var n2 in r2)
            r2.hasOwnProperty(n2) && (e2[n2] = r2[n2]);
        }
      }
      return e2;
    }, r.shrinkBuf = function(e2, t2) {
      return e2.length === t2 ? e2 : e2.subarray ? e2.subarray(0, t2) : (e2.length = t2, e2);
    };
    var i = { arraySet: function(e2, t2, r2, n2, i2) {
      if (t2.subarray && e2.subarray)
        e2.set(t2.subarray(r2, r2 + n2), i2);
      else
        for (var s2 = 0; s2 < n2; s2++)
          e2[i2 + s2] = t2[r2 + s2];
    }, flattenChunks: function(e2) {
      var t2, r2, n2, i2, s2, a;
      for (t2 = n2 = 0, r2 = e2.length; t2 < r2; t2++)
        n2 += e2[t2].length;
      for (a = new Uint8Array(n2), t2 = i2 = 0, r2 = e2.length; t2 < r2; t2++)
        s2 = e2[t2], a.set(s2, i2), i2 += s2.length;
      return a;
    } }, s = { arraySet: function(e2, t2, r2, n2, i2) {
      for (var s2 = 0; s2 < n2; s2++)
        e2[i2 + s2] = t2[r2 + s2];
    }, flattenChunks: function(e2) {
      return [].concat.apply([], e2);
    } };
    r.setTyped = function(e2) {
      e2 ? (r.Buf8 = Uint8Array, r.Buf16 = Uint16Array, r.Buf32 = Int32Array, r.assign(r, i)) : (r.Buf8 = Array, r.Buf16 = Array, r.Buf32 = Array, r.assign(r, s));
    }, r.setTyped(n);
  }, {}], 42: [function(e, t, r) {
    "use strict";
    var h = e("./common"), i = true, s = true;
    try {
      String.fromCharCode.apply(null, [0]);
    } catch (e2) {
      i = false;
    }
    try {
      String.fromCharCode.apply(null, new Uint8Array(1));
    } catch (e2) {
      s = false;
    }
    for (var u = new h.Buf8(256), n = 0; n < 256; n++)
      u[n] = 252 <= n ? 6 : 248 <= n ? 5 : 240 <= n ? 4 : 224 <= n ? 3 : 192 <= n ? 2 : 1;
    function l(e2, t2) {
      if (t2 < 65537 && (e2.subarray && s || !e2.subarray && i))
        return String.fromCharCode.apply(null, h.shrinkBuf(e2, t2));
      for (var r2 = "", n2 = 0; n2 < t2; n2++)
        r2 += String.fromCharCode(e2[n2]);
      return r2;
    }
    u[254] = u[254] = 1, r.string2buf = function(e2) {
      var t2, r2, n2, i2, s2, a = e2.length, o = 0;
      for (i2 = 0; i2 < a; i2++)
        55296 == (64512 & (r2 = e2.charCodeAt(i2))) && i2 + 1 < a && 56320 == (64512 & (n2 = e2.charCodeAt(i2 + 1))) && (r2 = 65536 + (r2 - 55296 << 10) + (n2 - 56320), i2++), o += r2 < 128 ? 1 : r2 < 2048 ? 2 : r2 < 65536 ? 3 : 4;
      for (t2 = new h.Buf8(o), i2 = s2 = 0; s2 < o; i2++)
        55296 == (64512 & (r2 = e2.charCodeAt(i2))) && i2 + 1 < a && 56320 == (64512 & (n2 = e2.charCodeAt(i2 + 1))) && (r2 = 65536 + (r2 - 55296 << 10) + (n2 - 56320), i2++), r2 < 128 ? t2[s2++] = r2 : (r2 < 2048 ? t2[s2++] = 192 | r2 >>> 6 : (r2 < 65536 ? t2[s2++] = 224 | r2 >>> 12 : (t2[s2++] = 240 | r2 >>> 18, t2[s2++] = 128 | r2 >>> 12 & 63), t2[s2++] = 128 | r2 >>> 6 & 63), t2[s2++] = 128 | 63 & r2);
      return t2;
    }, r.buf2binstring = function(e2) {
      return l(e2, e2.length);
    }, r.binstring2buf = function(e2) {
      for (var t2 = new h.Buf8(e2.length), r2 = 0, n2 = t2.length; r2 < n2; r2++)
        t2[r2] = e2.charCodeAt(r2);
      return t2;
    }, r.buf2string = function(e2, t2) {
      var r2, n2, i2, s2, a = t2 || e2.length, o = new Array(2 * a);
      for (r2 = n2 = 0; r2 < a; )
        if ((i2 = e2[r2++]) < 128)
          o[n2++] = i2;
        else if (4 < (s2 = u[i2]))
          o[n2++] = 65533, r2 += s2 - 1;
        else {
          for (i2 &= 2 === s2 ? 31 : 3 === s2 ? 15 : 7; 1 < s2 && r2 < a; )
            i2 = i2 << 6 | 63 & e2[r2++], s2--;
          1 < s2 ? o[n2++] = 65533 : i2 < 65536 ? o[n2++] = i2 : (i2 -= 65536, o[n2++] = 55296 | i2 >> 10 & 1023, o[n2++] = 56320 | 1023 & i2);
        }
      return l(o, n2);
    }, r.utf8border = function(e2, t2) {
      var r2;
      for ((t2 = t2 || e2.length) > e2.length && (t2 = e2.length), r2 = t2 - 1; 0 <= r2 && 128 == (192 & e2[r2]); )
        r2--;
      return r2 < 0 ? t2 : 0 === r2 ? t2 : r2 + u[e2[r2]] > t2 ? r2 : t2;
    };
  }, { "./common": 41 }], 43: [function(e, t, r) {
    "use strict";
    t.exports = function(e2, t2, r2, n) {
      for (var i = 65535 & e2 | 0, s = e2 >>> 16 & 65535 | 0, a = 0; 0 !== r2; ) {
        for (r2 -= a = 2e3 < r2 ? 2e3 : r2; s = s + (i = i + t2[n++] | 0) | 0, --a; )
          ;
        i %= 65521, s %= 65521;
      }
      return i | s << 16 | 0;
    };
  }, {}], 44: [function(e, t, r) {
    "use strict";
    t.exports = { Z_NO_FLUSH: 0, Z_PARTIAL_FLUSH: 1, Z_SYNC_FLUSH: 2, Z_FULL_FLUSH: 3, Z_FINISH: 4, Z_BLOCK: 5, Z_TREES: 6, Z_OK: 0, Z_STREAM_END: 1, Z_NEED_DICT: 2, Z_ERRNO: -1, Z_STREAM_ERROR: -2, Z_DATA_ERROR: -3, Z_BUF_ERROR: -5, Z_NO_COMPRESSION: 0, Z_BEST_SPEED: 1, Z_BEST_COMPRESSION: 9, Z_DEFAULT_COMPRESSION: -1, Z_FILTERED: 1, Z_HUFFMAN_ONLY: 2, Z_RLE: 3, Z_FIXED: 4, Z_DEFAULT_STRATEGY: 0, Z_BINARY: 0, Z_TEXT: 1, Z_UNKNOWN: 2, Z_DEFLATED: 8 };
  }, {}], 45: [function(e, t, r) {
    "use strict";
    var o = function() {
      for (var e2, t2 = [], r2 = 0; r2 < 256; r2++) {
        e2 = r2;
        for (var n = 0; n < 8; n++)
          e2 = 1 & e2 ? 3988292384 ^ e2 >>> 1 : e2 >>> 1;
        t2[r2] = e2;
      }
      return t2;
    }();
    t.exports = function(e2, t2, r2, n) {
      var i = o, s = n + r2;
      e2 ^= -1;
      for (var a = n; a < s; a++)
        e2 = e2 >>> 8 ^ i[255 & (e2 ^ t2[a])];
      return -1 ^ e2;
    };
  }, {}], 46: [function(e, t, r) {
    "use strict";
    var h, c = e("../utils/common"), u = e("./trees"), d = e("./adler32"), p = e("./crc32"), n = e("./messages"), l = 0, f = 4, m = 0, _ = -2, g = -1, b = 4, i = 2, v = 8, y = 9, s = 286, a = 30, o = 19, w = 2 * s + 1, k = 15, x = 3, S = 258, z = S + x + 1, C = 42, E = 113, A = 1, I = 2, O = 3, B = 4;
    function R(e2, t2) {
      return e2.msg = n[t2], t2;
    }
    function T(e2) {
      return (e2 << 1) - (4 < e2 ? 9 : 0);
    }
    function D(e2) {
      for (var t2 = e2.length; 0 <= --t2; )
        e2[t2] = 0;
    }
    function F(e2) {
      var t2 = e2.state, r2 = t2.pending;
      r2 > e2.avail_out && (r2 = e2.avail_out), 0 !== r2 && (c.arraySet(e2.output, t2.pending_buf, t2.pending_out, r2, e2.next_out), e2.next_out += r2, t2.pending_out += r2, e2.total_out += r2, e2.avail_out -= r2, t2.pending -= r2, 0 === t2.pending && (t2.pending_out = 0));
    }
    function N(e2, t2) {
      u._tr_flush_block(e2, 0 <= e2.block_start ? e2.block_start : -1, e2.strstart - e2.block_start, t2), e2.block_start = e2.strstart, F(e2.strm);
    }
    function U(e2, t2) {
      e2.pending_buf[e2.pending++] = t2;
    }
    function P(e2, t2) {
      e2.pending_buf[e2.pending++] = t2 >>> 8 & 255, e2.pending_buf[e2.pending++] = 255 & t2;
    }
    function L(e2, t2) {
      var r2, n2, i2 = e2.max_chain_length, s2 = e2.strstart, a2 = e2.prev_length, o2 = e2.nice_match, h2 = e2.strstart > e2.w_size - z ? e2.strstart - (e2.w_size - z) : 0, u2 = e2.window, l2 = e2.w_mask, f2 = e2.prev, c2 = e2.strstart + S, d2 = u2[s2 + a2 - 1], p2 = u2[s2 + a2];
      e2.prev_length >= e2.good_match && (i2 >>= 2), o2 > e2.lookahead && (o2 = e2.lookahead);
      do {
        if (u2[(r2 = t2) + a2] === p2 && u2[r2 + a2 - 1] === d2 && u2[r2] === u2[s2] && u2[++r2] === u2[s2 + 1]) {
          s2 += 2, r2++;
          do {
          } while (u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && u2[++s2] === u2[++r2] && s2 < c2);
          if (n2 = S - (c2 - s2), s2 = c2 - S, a2 < n2) {
            if (e2.match_start = t2, o2 <= (a2 = n2))
              break;
            d2 = u2[s2 + a2 - 1], p2 = u2[s2 + a2];
          }
        }
      } while ((t2 = f2[t2 & l2]) > h2 && 0 != --i2);
      return a2 <= e2.lookahead ? a2 : e2.lookahead;
    }
    function j(e2) {
      var t2, r2, n2, i2, s2, a2, o2, h2, u2, l2, f2 = e2.w_size;
      do {
        if (i2 = e2.window_size - e2.lookahead - e2.strstart, e2.strstart >= f2 + (f2 - z)) {
          for (c.arraySet(e2.window, e2.window, f2, f2, 0), e2.match_start -= f2, e2.strstart -= f2, e2.block_start -= f2, t2 = r2 = e2.hash_size; n2 = e2.head[--t2], e2.head[t2] = f2 <= n2 ? n2 - f2 : 0, --r2; )
            ;
          for (t2 = r2 = f2; n2 = e2.prev[--t2], e2.prev[t2] = f2 <= n2 ? n2 - f2 : 0, --r2; )
            ;
          i2 += f2;
        }
        if (0 === e2.strm.avail_in)
          break;
        if (a2 = e2.strm, o2 = e2.window, h2 = e2.strstart + e2.lookahead, u2 = i2, l2 = void 0, l2 = a2.avail_in, u2 < l2 && (l2 = u2), r2 = 0 === l2 ? 0 : (a2.avail_in -= l2, c.arraySet(o2, a2.input, a2.next_in, l2, h2), 1 === a2.state.wrap ? a2.adler = d(a2.adler, o2, l2, h2) : 2 === a2.state.wrap && (a2.adler = p(a2.adler, o2, l2, h2)), a2.next_in += l2, a2.total_in += l2, l2), e2.lookahead += r2, e2.lookahead + e2.insert >= x)
          for (s2 = e2.strstart - e2.insert, e2.ins_h = e2.window[s2], e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[s2 + 1]) & e2.hash_mask; e2.insert && (e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[s2 + x - 1]) & e2.hash_mask, e2.prev[s2 & e2.w_mask] = e2.head[e2.ins_h], e2.head[e2.ins_h] = s2, s2++, e2.insert--, !(e2.lookahead + e2.insert < x)); )
            ;
      } while (e2.lookahead < z && 0 !== e2.strm.avail_in);
    }
    function Z(e2, t2) {
      for (var r2, n2; ; ) {
        if (e2.lookahead < z) {
          if (j(e2), e2.lookahead < z && t2 === l)
            return A;
          if (0 === e2.lookahead)
            break;
        }
        if (r2 = 0, e2.lookahead >= x && (e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[e2.strstart + x - 1]) & e2.hash_mask, r2 = e2.prev[e2.strstart & e2.w_mask] = e2.head[e2.ins_h], e2.head[e2.ins_h] = e2.strstart), 0 !== r2 && e2.strstart - r2 <= e2.w_size - z && (e2.match_length = L(e2, r2)), e2.match_length >= x)
          if (n2 = u._tr_tally(e2, e2.strstart - e2.match_start, e2.match_length - x), e2.lookahead -= e2.match_length, e2.match_length <= e2.max_lazy_match && e2.lookahead >= x) {
            for (e2.match_length--; e2.strstart++, e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[e2.strstart + x - 1]) & e2.hash_mask, r2 = e2.prev[e2.strstart & e2.w_mask] = e2.head[e2.ins_h], e2.head[e2.ins_h] = e2.strstart, 0 != --e2.match_length; )
              ;
            e2.strstart++;
          } else
            e2.strstart += e2.match_length, e2.match_length = 0, e2.ins_h = e2.window[e2.strstart], e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[e2.strstart + 1]) & e2.hash_mask;
        else
          n2 = u._tr_tally(e2, 0, e2.window[e2.strstart]), e2.lookahead--, e2.strstart++;
        if (n2 && (N(e2, false), 0 === e2.strm.avail_out))
          return A;
      }
      return e2.insert = e2.strstart < x - 1 ? e2.strstart : x - 1, t2 === f ? (N(e2, true), 0 === e2.strm.avail_out ? O : B) : e2.last_lit && (N(e2, false), 0 === e2.strm.avail_out) ? A : I;
    }
    function W(e2, t2) {
      for (var r2, n2, i2; ; ) {
        if (e2.lookahead < z) {
          if (j(e2), e2.lookahead < z && t2 === l)
            return A;
          if (0 === e2.lookahead)
            break;
        }
        if (r2 = 0, e2.lookahead >= x && (e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[e2.strstart + x - 1]) & e2.hash_mask, r2 = e2.prev[e2.strstart & e2.w_mask] = e2.head[e2.ins_h], e2.head[e2.ins_h] = e2.strstart), e2.prev_length = e2.match_length, e2.prev_match = e2.match_start, e2.match_length = x - 1, 0 !== r2 && e2.prev_length < e2.max_lazy_match && e2.strstart - r2 <= e2.w_size - z && (e2.match_length = L(e2, r2), e2.match_length <= 5 && (1 === e2.strategy || e2.match_length === x && 4096 < e2.strstart - e2.match_start) && (e2.match_length = x - 1)), e2.prev_length >= x && e2.match_length <= e2.prev_length) {
          for (i2 = e2.strstart + e2.lookahead - x, n2 = u._tr_tally(e2, e2.strstart - 1 - e2.prev_match, e2.prev_length - x), e2.lookahead -= e2.prev_length - 1, e2.prev_length -= 2; ++e2.strstart <= i2 && (e2.ins_h = (e2.ins_h << e2.hash_shift ^ e2.window[e2.strstart + x - 1]) & e2.hash_mask, r2 = e2.prev[e2.strstart & e2.w_mask] = e2.head[e2.ins_h], e2.head[e2.ins_h] = e2.strstart), 0 != --e2.prev_length; )
            ;
          if (e2.match_available = 0, e2.match_length = x - 1, e2.strstart++, n2 && (N(e2, false), 0 === e2.strm.avail_out))
            return A;
        } else if (e2.match_available) {
          if ((n2 = u._tr_tally(e2, 0, e2.window[e2.strstart - 1])) && N(e2, false), e2.strstart++, e2.lookahead--, 0 === e2.strm.avail_out)
            return A;
        } else
          e2.match_available = 1, e2.strstart++, e2.lookahead--;
      }
      return e2.match_available && (n2 = u._tr_tally(e2, 0, e2.window[e2.strstart - 1]), e2.match_available = 0), e2.insert = e2.strstart < x - 1 ? e2.strstart : x - 1, t2 === f ? (N(e2, true), 0 === e2.strm.avail_out ? O : B) : e2.last_lit && (N(e2, false), 0 === e2.strm.avail_out) ? A : I;
    }
    function M(e2, t2, r2, n2, i2) {
      this.good_length = e2, this.max_lazy = t2, this.nice_length = r2, this.max_chain = n2, this.func = i2;
    }
    function H() {
      this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = v, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new c.Buf16(2 * w), this.dyn_dtree = new c.Buf16(2 * (2 * a + 1)), this.bl_tree = new c.Buf16(2 * (2 * o + 1)), D(this.dyn_ltree), D(this.dyn_dtree), D(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = new c.Buf16(k + 1), this.heap = new c.Buf16(2 * s + 1), D(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = new c.Buf16(2 * s + 1), D(this.depth), this.l_buf = 0, this.lit_bufsize = 0, this.last_lit = 0, this.d_buf = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0;
    }
    function G(e2) {
      var t2;
      return e2 && e2.state ? (e2.total_in = e2.total_out = 0, e2.data_type = i, (t2 = e2.state).pending = 0, t2.pending_out = 0, t2.wrap < 0 && (t2.wrap = -t2.wrap), t2.status = t2.wrap ? C : E, e2.adler = 2 === t2.wrap ? 0 : 1, t2.last_flush = l, u._tr_init(t2), m) : R(e2, _);
    }
    function K(e2) {
      var t2 = G(e2);
      return t2 === m && function(e3) {
        e3.window_size = 2 * e3.w_size, D(e3.head), e3.max_lazy_match = h[e3.level].max_lazy, e3.good_match = h[e3.level].good_length, e3.nice_match = h[e3.level].nice_length, e3.max_chain_length = h[e3.level].max_chain, e3.strstart = 0, e3.block_start = 0, e3.lookahead = 0, e3.insert = 0, e3.match_length = e3.prev_length = x - 1, e3.match_available = 0, e3.ins_h = 0;
      }(e2.state), t2;
    }
    function Y(e2, t2, r2, n2, i2, s2) {
      if (!e2)
        return _;
      var a2 = 1;
      if (t2 === g && (t2 = 6), n2 < 0 ? (a2 = 0, n2 = -n2) : 15 < n2 && (a2 = 2, n2 -= 16), i2 < 1 || y < i2 || r2 !== v || n2 < 8 || 15 < n2 || t2 < 0 || 9 < t2 || s2 < 0 || b < s2)
        return R(e2, _);
      8 === n2 && (n2 = 9);
      var o2 = new H();
      return (e2.state = o2).strm = e2, o2.wrap = a2, o2.gzhead = null, o2.w_bits = n2, o2.w_size = 1 << o2.w_bits, o2.w_mask = o2.w_size - 1, o2.hash_bits = i2 + 7, o2.hash_size = 1 << o2.hash_bits, o2.hash_mask = o2.hash_size - 1, o2.hash_shift = ~~((o2.hash_bits + x - 1) / x), o2.window = new c.Buf8(2 * o2.w_size), o2.head = new c.Buf16(o2.hash_size), o2.prev = new c.Buf16(o2.w_size), o2.lit_bufsize = 1 << i2 + 6, o2.pending_buf_size = 4 * o2.lit_bufsize, o2.pending_buf = new c.Buf8(o2.pending_buf_size), o2.d_buf = 1 * o2.lit_bufsize, o2.l_buf = 3 * o2.lit_bufsize, o2.level = t2, o2.strategy = s2, o2.method = r2, K(e2);
    }
    h = [new M(0, 0, 0, 0, function(e2, t2) {
      var r2 = 65535;
      for (r2 > e2.pending_buf_size - 5 && (r2 = e2.pending_buf_size - 5); ; ) {
        if (e2.lookahead <= 1) {
          if (j(e2), 0 === e2.lookahead && t2 === l)
            return A;
          if (0 === e2.lookahead)
            break;
        }
        e2.strstart += e2.lookahead, e2.lookahead = 0;
        var n2 = e2.block_start + r2;
        if ((0 === e2.strstart || e2.strstart >= n2) && (e2.lookahead = e2.strstart - n2, e2.strstart = n2, N(e2, false), 0 === e2.strm.avail_out))
          return A;
        if (e2.strstart - e2.block_start >= e2.w_size - z && (N(e2, false), 0 === e2.strm.avail_out))
          return A;
      }
      return e2.insert = 0, t2 === f ? (N(e2, true), 0 === e2.strm.avail_out ? O : B) : (e2.strstart > e2.block_start && (N(e2, false), e2.strm.avail_out), A);
    }), new M(4, 4, 8, 4, Z), new M(4, 5, 16, 8, Z), new M(4, 6, 32, 32, Z), new M(4, 4, 16, 16, W), new M(8, 16, 32, 32, W), new M(8, 16, 128, 128, W), new M(8, 32, 128, 256, W), new M(32, 128, 258, 1024, W), new M(32, 258, 258, 4096, W)], r.deflateInit = function(e2, t2) {
      return Y(e2, t2, v, 15, 8, 0);
    }, r.deflateInit2 = Y, r.deflateReset = K, r.deflateResetKeep = G, r.deflateSetHeader = function(e2, t2) {
      return e2 && e2.state ? 2 !== e2.state.wrap ? _ : (e2.state.gzhead = t2, m) : _;
    }, r.deflate = function(e2, t2) {
      var r2, n2, i2, s2;
      if (!e2 || !e2.state || 5 < t2 || t2 < 0)
        return e2 ? R(e2, _) : _;
      if (n2 = e2.state, !e2.output || !e2.input && 0 !== e2.avail_in || 666 === n2.status && t2 !== f)
        return R(e2, 0 === e2.avail_out ? -5 : _);
      if (n2.strm = e2, r2 = n2.last_flush, n2.last_flush = t2, n2.status === C)
        if (2 === n2.wrap)
          e2.adler = 0, U(n2, 31), U(n2, 139), U(n2, 8), n2.gzhead ? (U(n2, (n2.gzhead.text ? 1 : 0) + (n2.gzhead.hcrc ? 2 : 0) + (n2.gzhead.extra ? 4 : 0) + (n2.gzhead.name ? 8 : 0) + (n2.gzhead.comment ? 16 : 0)), U(n2, 255 & n2.gzhead.time), U(n2, n2.gzhead.time >> 8 & 255), U(n2, n2.gzhead.time >> 16 & 255), U(n2, n2.gzhead.time >> 24 & 255), U(n2, 9 === n2.level ? 2 : 2 <= n2.strategy || n2.level < 2 ? 4 : 0), U(n2, 255 & n2.gzhead.os), n2.gzhead.extra && n2.gzhead.extra.length && (U(n2, 255 & n2.gzhead.extra.length), U(n2, n2.gzhead.extra.length >> 8 & 255)), n2.gzhead.hcrc && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending, 0)), n2.gzindex = 0, n2.status = 69) : (U(n2, 0), U(n2, 0), U(n2, 0), U(n2, 0), U(n2, 0), U(n2, 9 === n2.level ? 2 : 2 <= n2.strategy || n2.level < 2 ? 4 : 0), U(n2, 3), n2.status = E);
        else {
          var a2 = v + (n2.w_bits - 8 << 4) << 8;
          a2 |= (2 <= n2.strategy || n2.level < 2 ? 0 : n2.level < 6 ? 1 : 6 === n2.level ? 2 : 3) << 6, 0 !== n2.strstart && (a2 |= 32), a2 += 31 - a2 % 31, n2.status = E, P(n2, a2), 0 !== n2.strstart && (P(n2, e2.adler >>> 16), P(n2, 65535 & e2.adler)), e2.adler = 1;
        }
      if (69 === n2.status)
        if (n2.gzhead.extra) {
          for (i2 = n2.pending; n2.gzindex < (65535 & n2.gzhead.extra.length) && (n2.pending !== n2.pending_buf_size || (n2.gzhead.hcrc && n2.pending > i2 && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending - i2, i2)), F(e2), i2 = n2.pending, n2.pending !== n2.pending_buf_size)); )
            U(n2, 255 & n2.gzhead.extra[n2.gzindex]), n2.gzindex++;
          n2.gzhead.hcrc && n2.pending > i2 && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending - i2, i2)), n2.gzindex === n2.gzhead.extra.length && (n2.gzindex = 0, n2.status = 73);
        } else
          n2.status = 73;
      if (73 === n2.status)
        if (n2.gzhead.name) {
          i2 = n2.pending;
          do {
            if (n2.pending === n2.pending_buf_size && (n2.gzhead.hcrc && n2.pending > i2 && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending - i2, i2)), F(e2), i2 = n2.pending, n2.pending === n2.pending_buf_size)) {
              s2 = 1;
              break;
            }
            s2 = n2.gzindex < n2.gzhead.name.length ? 255 & n2.gzhead.name.charCodeAt(n2.gzindex++) : 0, U(n2, s2);
          } while (0 !== s2);
          n2.gzhead.hcrc && n2.pending > i2 && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending - i2, i2)), 0 === s2 && (n2.gzindex = 0, n2.status = 91);
        } else
          n2.status = 91;
      if (91 === n2.status)
        if (n2.gzhead.comment) {
          i2 = n2.pending;
          do {
            if (n2.pending === n2.pending_buf_size && (n2.gzhead.hcrc && n2.pending > i2 && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending - i2, i2)), F(e2), i2 = n2.pending, n2.pending === n2.pending_buf_size)) {
              s2 = 1;
              break;
            }
            s2 = n2.gzindex < n2.gzhead.comment.length ? 255 & n2.gzhead.comment.charCodeAt(n2.gzindex++) : 0, U(n2, s2);
          } while (0 !== s2);
          n2.gzhead.hcrc && n2.pending > i2 && (e2.adler = p(e2.adler, n2.pending_buf, n2.pending - i2, i2)), 0 === s2 && (n2.status = 103);
        } else
          n2.status = 103;
      if (103 === n2.status && (n2.gzhead.hcrc ? (n2.pending + 2 > n2.pending_buf_size && F(e2), n2.pending + 2 <= n2.pending_buf_size && (U(n2, 255 & e2.adler), U(n2, e2.adler >> 8 & 255), e2.adler = 0, n2.status = E)) : n2.status = E), 0 !== n2.pending) {
        if (F(e2), 0 === e2.avail_out)
          return n2.last_flush = -1, m;
      } else if (0 === e2.avail_in && T(t2) <= T(r2) && t2 !== f)
        return R(e2, -5);
      if (666 === n2.status && 0 !== e2.avail_in)
        return R(e2, -5);
      if (0 !== e2.avail_in || 0 !== n2.lookahead || t2 !== l && 666 !== n2.status) {
        var o2 = 2 === n2.strategy ? function(e3, t3) {
          for (var r3; ; ) {
            if (0 === e3.lookahead && (j(e3), 0 === e3.lookahead)) {
              if (t3 === l)
                return A;
              break;
            }
            if (e3.match_length = 0, r3 = u._tr_tally(e3, 0, e3.window[e3.strstart]), e3.lookahead--, e3.strstart++, r3 && (N(e3, false), 0 === e3.strm.avail_out))
              return A;
          }
          return e3.insert = 0, t3 === f ? (N(e3, true), 0 === e3.strm.avail_out ? O : B) : e3.last_lit && (N(e3, false), 0 === e3.strm.avail_out) ? A : I;
        }(n2, t2) : 3 === n2.strategy ? function(e3, t3) {
          for (var r3, n3, i3, s3, a3 = e3.window; ; ) {
            if (e3.lookahead <= S) {
              if (j(e3), e3.lookahead <= S && t3 === l)
                return A;
              if (0 === e3.lookahead)
                break;
            }
            if (e3.match_length = 0, e3.lookahead >= x && 0 < e3.strstart && (n3 = a3[i3 = e3.strstart - 1]) === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3]) {
              s3 = e3.strstart + S;
              do {
              } while (n3 === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3] && n3 === a3[++i3] && i3 < s3);
              e3.match_length = S - (s3 - i3), e3.match_length > e3.lookahead && (e3.match_length = e3.lookahead);
            }
            if (e3.match_length >= x ? (r3 = u._tr_tally(e3, 1, e3.match_length - x), e3.lookahead -= e3.match_length, e3.strstart += e3.match_length, e3.match_length = 0) : (r3 = u._tr_tally(e3, 0, e3.window[e3.strstart]), e3.lookahead--, e3.strstart++), r3 && (N(e3, false), 0 === e3.strm.avail_out))
              return A;
          }
          return e3.insert = 0, t3 === f ? (N(e3, true), 0 === e3.strm.avail_out ? O : B) : e3.last_lit && (N(e3, false), 0 === e3.strm.avail_out) ? A : I;
        }(n2, t2) : h[n2.level].func(n2, t2);
        if (o2 !== O && o2 !== B || (n2.status = 666), o2 === A || o2 === O)
          return 0 === e2.avail_out && (n2.last_flush = -1), m;
        if (o2 === I && (1 === t2 ? u._tr_align(n2) : 5 !== t2 && (u._tr_stored_block(n2, 0, 0, false), 3 === t2 && (D(n2.head), 0 === n2.lookahead && (n2.strstart = 0, n2.block_start = 0, n2.insert = 0))), F(e2), 0 === e2.avail_out))
          return n2.last_flush = -1, m;
      }
      return t2 !== f ? m : n2.wrap <= 0 ? 1 : (2 === n2.wrap ? (U(n2, 255 & e2.adler), U(n2, e2.adler >> 8 & 255), U(n2, e2.adler >> 16 & 255), U(n2, e2.adler >> 24 & 255), U(n2, 255 & e2.total_in), U(n2, e2.total_in >> 8 & 255), U(n2, e2.total_in >> 16 & 255), U(n2, e2.total_in >> 24 & 255)) : (P(n2, e2.adler >>> 16), P(n2, 65535 & e2.adler)), F(e2), 0 < n2.wrap && (n2.wrap = -n2.wrap), 0 !== n2.pending ? m : 1);
    }, r.deflateEnd = function(e2) {
      var t2;
      return e2 && e2.state ? (t2 = e2.state.status) !== C && 69 !== t2 && 73 !== t2 && 91 !== t2 && 103 !== t2 && t2 !== E && 666 !== t2 ? R(e2, _) : (e2.state = null, t2 === E ? R(e2, -3) : m) : _;
    }, r.deflateSetDictionary = function(e2, t2) {
      var r2, n2, i2, s2, a2, o2, h2, u2, l2 = t2.length;
      if (!e2 || !e2.state)
        return _;
      if (2 === (s2 = (r2 = e2.state).wrap) || 1 === s2 && r2.status !== C || r2.lookahead)
        return _;
      for (1 === s2 && (e2.adler = d(e2.adler, t2, l2, 0)), r2.wrap = 0, l2 >= r2.w_size && (0 === s2 && (D(r2.head), r2.strstart = 0, r2.block_start = 0, r2.insert = 0), u2 = new c.Buf8(r2.w_size), c.arraySet(u2, t2, l2 - r2.w_size, r2.w_size, 0), t2 = u2, l2 = r2.w_size), a2 = e2.avail_in, o2 = e2.next_in, h2 = e2.input, e2.avail_in = l2, e2.next_in = 0, e2.input = t2, j(r2); r2.lookahead >= x; ) {
        for (n2 = r2.strstart, i2 = r2.lookahead - (x - 1); r2.ins_h = (r2.ins_h << r2.hash_shift ^ r2.window[n2 + x - 1]) & r2.hash_mask, r2.prev[n2 & r2.w_mask] = r2.head[r2.ins_h], r2.head[r2.ins_h] = n2, n2++, --i2; )
          ;
        r2.strstart = n2, r2.lookahead = x - 1, j(r2);
      }
      return r2.strstart += r2.lookahead, r2.block_start = r2.strstart, r2.insert = r2.lookahead, r2.lookahead = 0, r2.match_length = r2.prev_length = x - 1, r2.match_available = 0, e2.next_in = o2, e2.input = h2, e2.avail_in = a2, r2.wrap = s2, m;
    }, r.deflateInfo = "pako deflate (from Nodeca project)";
  }, { "../utils/common": 41, "./adler32": 43, "./crc32": 45, "./messages": 51, "./trees": 52 }], 47: [function(e, t, r) {
    "use strict";
    t.exports = function() {
      this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, this.name = "", this.comment = "", this.hcrc = 0, this.done = false;
    };
  }, {}], 48: [function(e, t, r) {
    "use strict";
    t.exports = function(e2, t2) {
      var r2, n, i, s, a, o, h, u, l, f, c, d, p, m, _, g, b, v, y, w, k, x, S, z, C;
      r2 = e2.state, n = e2.next_in, z = e2.input, i = n + (e2.avail_in - 5), s = e2.next_out, C = e2.output, a = s - (t2 - e2.avail_out), o = s + (e2.avail_out - 257), h = r2.dmax, u = r2.wsize, l = r2.whave, f = r2.wnext, c = r2.window, d = r2.hold, p = r2.bits, m = r2.lencode, _ = r2.distcode, g = (1 << r2.lenbits) - 1, b = (1 << r2.distbits) - 1;
      e:
        do {
          p < 15 && (d += z[n++] << p, p += 8, d += z[n++] << p, p += 8), v = m[d & g];
          t:
            for (; ; ) {
              if (d >>>= y = v >>> 24, p -= y, 0 === (y = v >>> 16 & 255))
                C[s++] = 65535 & v;
              else {
                if (!(16 & y)) {
                  if (0 == (64 & y)) {
                    v = m[(65535 & v) + (d & (1 << y) - 1)];
                    continue t;
                  }
                  if (32 & y) {
                    r2.mode = 12;
                    break e;
                  }
                  e2.msg = "invalid literal/length code", r2.mode = 30;
                  break e;
                }
                w = 65535 & v, (y &= 15) && (p < y && (d += z[n++] << p, p += 8), w += d & (1 << y) - 1, d >>>= y, p -= y), p < 15 && (d += z[n++] << p, p += 8, d += z[n++] << p, p += 8), v = _[d & b];
                r:
                  for (; ; ) {
                    if (d >>>= y = v >>> 24, p -= y, !(16 & (y = v >>> 16 & 255))) {
                      if (0 == (64 & y)) {
                        v = _[(65535 & v) + (d & (1 << y) - 1)];
                        continue r;
                      }
                      e2.msg = "invalid distance code", r2.mode = 30;
                      break e;
                    }
                    if (k = 65535 & v, p < (y &= 15) && (d += z[n++] << p, (p += 8) < y && (d += z[n++] << p, p += 8)), h < (k += d & (1 << y) - 1)) {
                      e2.msg = "invalid distance too far back", r2.mode = 30;
                      break e;
                    }
                    if (d >>>= y, p -= y, (y = s - a) < k) {
                      if (l < (y = k - y) && r2.sane) {
                        e2.msg = "invalid distance too far back", r2.mode = 30;
                        break e;
                      }
                      if (S = c, (x = 0) === f) {
                        if (x += u - y, y < w) {
                          for (w -= y; C[s++] = c[x++], --y; )
                            ;
                          x = s - k, S = C;
                        }
                      } else if (f < y) {
                        if (x += u + f - y, (y -= f) < w) {
                          for (w -= y; C[s++] = c[x++], --y; )
                            ;
                          if (x = 0, f < w) {
                            for (w -= y = f; C[s++] = c[x++], --y; )
                              ;
                            x = s - k, S = C;
                          }
                        }
                      } else if (x += f - y, y < w) {
                        for (w -= y; C[s++] = c[x++], --y; )
                          ;
                        x = s - k, S = C;
                      }
                      for (; 2 < w; )
                        C[s++] = S[x++], C[s++] = S[x++], C[s++] = S[x++], w -= 3;
                      w && (C[s++] = S[x++], 1 < w && (C[s++] = S[x++]));
                    } else {
                      for (x = s - k; C[s++] = C[x++], C[s++] = C[x++], C[s++] = C[x++], 2 < (w -= 3); )
                        ;
                      w && (C[s++] = C[x++], 1 < w && (C[s++] = C[x++]));
                    }
                    break;
                  }
              }
              break;
            }
        } while (n < i && s < o);
      n -= w = p >> 3, d &= (1 << (p -= w << 3)) - 1, e2.next_in = n, e2.next_out = s, e2.avail_in = n < i ? i - n + 5 : 5 - (n - i), e2.avail_out = s < o ? o - s + 257 : 257 - (s - o), r2.hold = d, r2.bits = p;
    };
  }, {}], 49: [function(e, t, r) {
    "use strict";
    var I = e("../utils/common"), O = e("./adler32"), B = e("./crc32"), R = e("./inffast"), T = e("./inftrees"), D = 1, F = 2, N = 0, U = -2, P = 1, n = 852, i = 592;
    function L(e2) {
      return (e2 >>> 24 & 255) + (e2 >>> 8 & 65280) + ((65280 & e2) << 8) + ((255 & e2) << 24);
    }
    function s() {
      this.mode = 0, this.last = false, this.wrap = 0, this.havedict = false, this.flags = 0, this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, this.ndist = 0, this.have = 0, this.next = null, this.lens = new I.Buf16(320), this.work = new I.Buf16(288), this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0;
    }
    function a(e2) {
      var t2;
      return e2 && e2.state ? (t2 = e2.state, e2.total_in = e2.total_out = t2.total = 0, e2.msg = "", t2.wrap && (e2.adler = 1 & t2.wrap), t2.mode = P, t2.last = 0, t2.havedict = 0, t2.dmax = 32768, t2.head = null, t2.hold = 0, t2.bits = 0, t2.lencode = t2.lendyn = new I.Buf32(n), t2.distcode = t2.distdyn = new I.Buf32(i), t2.sane = 1, t2.back = -1, N) : U;
    }
    function o(e2) {
      var t2;
      return e2 && e2.state ? ((t2 = e2.state).wsize = 0, t2.whave = 0, t2.wnext = 0, a(e2)) : U;
    }
    function h(e2, t2) {
      var r2, n2;
      return e2 && e2.state ? (n2 = e2.state, t2 < 0 ? (r2 = 0, t2 = -t2) : (r2 = 1 + (t2 >> 4), t2 < 48 && (t2 &= 15)), t2 && (t2 < 8 || 15 < t2) ? U : (null !== n2.window && n2.wbits !== t2 && (n2.window = null), n2.wrap = r2, n2.wbits = t2, o(e2))) : U;
    }
    function u(e2, t2) {
      var r2, n2;
      return e2 ? (n2 = new s(), (e2.state = n2).window = null, (r2 = h(e2, t2)) !== N && (e2.state = null), r2) : U;
    }
    var l, f, c = true;
    function j(e2) {
      if (c) {
        var t2;
        for (l = new I.Buf32(512), f = new I.Buf32(32), t2 = 0; t2 < 144; )
          e2.lens[t2++] = 8;
        for (; t2 < 256; )
          e2.lens[t2++] = 9;
        for (; t2 < 280; )
          e2.lens[t2++] = 7;
        for (; t2 < 288; )
          e2.lens[t2++] = 8;
        for (T(D, e2.lens, 0, 288, l, 0, e2.work, { bits: 9 }), t2 = 0; t2 < 32; )
          e2.lens[t2++] = 5;
        T(F, e2.lens, 0, 32, f, 0, e2.work, { bits: 5 }), c = false;
      }
      e2.lencode = l, e2.lenbits = 9, e2.distcode = f, e2.distbits = 5;
    }
    function Z(e2, t2, r2, n2) {
      var i2, s2 = e2.state;
      return null === s2.window && (s2.wsize = 1 << s2.wbits, s2.wnext = 0, s2.whave = 0, s2.window = new I.Buf8(s2.wsize)), n2 >= s2.wsize ? (I.arraySet(s2.window, t2, r2 - s2.wsize, s2.wsize, 0), s2.wnext = 0, s2.whave = s2.wsize) : (n2 < (i2 = s2.wsize - s2.wnext) && (i2 = n2), I.arraySet(s2.window, t2, r2 - n2, i2, s2.wnext), (n2 -= i2) ? (I.arraySet(s2.window, t2, r2 - n2, n2, 0), s2.wnext = n2, s2.whave = s2.wsize) : (s2.wnext += i2, s2.wnext === s2.wsize && (s2.wnext = 0), s2.whave < s2.wsize && (s2.whave += i2))), 0;
    }
    r.inflateReset = o, r.inflateReset2 = h, r.inflateResetKeep = a, r.inflateInit = function(e2) {
      return u(e2, 15);
    }, r.inflateInit2 = u, r.inflate = function(e2, t2) {
      var r2, n2, i2, s2, a2, o2, h2, u2, l2, f2, c2, d, p, m, _, g, b, v, y, w, k, x, S, z, C = 0, E = new I.Buf8(4), A = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
      if (!e2 || !e2.state || !e2.output || !e2.input && 0 !== e2.avail_in)
        return U;
      12 === (r2 = e2.state).mode && (r2.mode = 13), a2 = e2.next_out, i2 = e2.output, h2 = e2.avail_out, s2 = e2.next_in, n2 = e2.input, o2 = e2.avail_in, u2 = r2.hold, l2 = r2.bits, f2 = o2, c2 = h2, x = N;
      e:
        for (; ; )
          switch (r2.mode) {
            case P:
              if (0 === r2.wrap) {
                r2.mode = 13;
                break;
              }
              for (; l2 < 16; ) {
                if (0 === o2)
                  break e;
                o2--, u2 += n2[s2++] << l2, l2 += 8;
              }
              if (2 & r2.wrap && 35615 === u2) {
                E[r2.check = 0] = 255 & u2, E[1] = u2 >>> 8 & 255, r2.check = B(r2.check, E, 2, 0), l2 = u2 = 0, r2.mode = 2;
                break;
              }
              if (r2.flags = 0, r2.head && (r2.head.done = false), !(1 & r2.wrap) || (((255 & u2) << 8) + (u2 >> 8)) % 31) {
                e2.msg = "incorrect header check", r2.mode = 30;
                break;
              }
              if (8 != (15 & u2)) {
                e2.msg = "unknown compression method", r2.mode = 30;
                break;
              }
              if (l2 -= 4, k = 8 + (15 & (u2 >>>= 4)), 0 === r2.wbits)
                r2.wbits = k;
              else if (k > r2.wbits) {
                e2.msg = "invalid window size", r2.mode = 30;
                break;
              }
              r2.dmax = 1 << k, e2.adler = r2.check = 1, r2.mode = 512 & u2 ? 10 : 12, l2 = u2 = 0;
              break;
            case 2:
              for (; l2 < 16; ) {
                if (0 === o2)
                  break e;
                o2--, u2 += n2[s2++] << l2, l2 += 8;
              }
              if (r2.flags = u2, 8 != (255 & r2.flags)) {
                e2.msg = "unknown compression method", r2.mode = 30;
                break;
              }
              if (57344 & r2.flags) {
                e2.msg = "unknown header flags set", r2.mode = 30;
                break;
              }
              r2.head && (r2.head.text = u2 >> 8 & 1), 512 & r2.flags && (E[0] = 255 & u2, E[1] = u2 >>> 8 & 255, r2.check = B(r2.check, E, 2, 0)), l2 = u2 = 0, r2.mode = 3;
            case 3:
              for (; l2 < 32; ) {
                if (0 === o2)
                  break e;
                o2--, u2 += n2[s2++] << l2, l2 += 8;
              }
              r2.head && (r2.head.time = u2), 512 & r2.flags && (E[0] = 255 & u2, E[1] = u2 >>> 8 & 255, E[2] = u2 >>> 16 & 255, E[3] = u2 >>> 24 & 255, r2.check = B(r2.check, E, 4, 0)), l2 = u2 = 0, r2.mode = 4;
            case 4:
              for (; l2 < 16; ) {
                if (0 === o2)
                  break e;
                o2--, u2 += n2[s2++] << l2, l2 += 8;
              }
              r2.head && (r2.head.xflags = 255 & u2, r2.head.os = u2 >> 8), 512 & r2.flags && (E[0] = 255 & u2, E[1] = u2 >>> 8 & 255, r2.check = B(r2.check, E, 2, 0)), l2 = u2 = 0, r2.mode = 5;
            case 5:
              if (1024 & r2.flags) {
                for (; l2 < 16; ) {
                  if (0 === o2)
                    break e;
                  o2--, u2 += n2[s2++] << l2, l2 += 8;
                }
                r2.length = u2, r2.head && (r2.head.extra_len = u2), 512 & r2.flags && (E[0] = 255 & u2, E[1] = u2 >>> 8 & 255, r2.check = B(r2.check, E, 2, 0)), l2 = u2 = 0;
              } else
                r2.head && (r2.head.extra = null);
              r2.mode = 6;
            case 6:
              if (1024 & r2.flags && (o2 < (d = r2.length) && (d = o2), d && (r2.head && (k = r2.head.extra_len - r2.length, r2.head.extra || (r2.head.extra = new Array(r2.head.extra_len)), I.arraySet(r2.head.extra, n2, s2, d, k)), 512 & r2.flags && (r2.check = B(r2.check, n2, d, s2)), o2 -= d, s2 += d, r2.length -= d), r2.length))
                break e;
              r2.length = 0, r2.mode = 7;
            case 7:
              if (2048 & r2.flags) {
                if (0 === o2)
                  break e;
                for (d = 0; k = n2[s2 + d++], r2.head && k && r2.length < 65536 && (r2.head.name += String.fromCharCode(k)), k && d < o2; )
                  ;
                if (512 & r2.flags && (r2.check = B(r2.check, n2, d, s2)), o2 -= d, s2 += d, k)
                  break e;
              } else
                r2.head && (r2.head.name = null);
              r2.length = 0, r2.mode = 8;
            case 8:
              if (4096 & r2.flags) {
                if (0 === o2)
                  break e;
                for (d = 0; k = n2[s2 + d++], r2.head && k && r2.length < 65536 && (r2.head.comment += String.fromCharCode(k)), k && d < o2; )
                  ;
                if (512 & r2.flags && (r2.check = B(r2.check, n2, d, s2)), o2 -= d, s2 += d, k)
                  break e;
              } else
                r2.head && (r2.head.comment = null);
              r2.mode = 9;
            case 9:
              if (512 & r2.flags) {
                for (; l2 < 16; ) {
                  if (0 === o2)
                    break e;
                  o2--, u2 += n2[s2++] << l2, l2 += 8;
                }
                if (u2 !== (65535 & r2.check)) {
                  e2.msg = "header crc mismatch", r2.mode = 30;
                  break;
                }
                l2 = u2 = 0;
              }
              r2.head && (r2.head.hcrc = r2.flags >> 9 & 1, r2.head.done = true), e2.adler = r2.check = 0, r2.mode = 12;
              break;
            case 10:
              for (; l2 < 32; ) {
                if (0 === o2)
                  break e;
                o2--, u2 += n2[s2++] << l2, l2 += 8;
              }
              e2.adler = r2.check = L(u2), l2 = u2 = 0, r2.mode = 11;
            case 11:
              if (0 === r2.havedict)
                return e2.next_out = a2, e2.avail_out = h2, e2.next_in = s2, e2.avail_in = o2, r2.hold = u2, r2.bits = l2, 2;
              e2.adler = r2.check = 1, r2.mode = 12;
            case 12:
              if (5 === t2 || 6 === t2)
                break e;
            case 13:
              if (r2.last) {
                u2 >>>= 7 & l2, l2 -= 7 & l2, r2.mode = 27;
                break;
              }
              for (; l2 < 3; ) {
                if (0 === o2)
                  break e;
                o2--, u2 += n2[s2++] << l2, l2 += 8;
              }
              switch (r2.last = 1 & u2, l2 -= 1, 3 & (u2 >>>= 1)) {
                case 0:
                  r2.mode = 14;
                  break;
                case 1:
                  if (j(r2), r2.mode = 20, 6 !== t2)
                    break;
                  u2 >>>= 2, l2 -= 2;
                  break e;
                case 2:
                  r2.mode = 17;
                  break;
                case 3:
                  e2.msg = "invalid block type", r2.mode = 30;
              }
              u2 >>>= 2, l2 -= 2;
              break;
            case 14:
              for (u2 >>>= 7 & l2, l2 -= 7 & l2; l2 < 32; ) {
                if (0 === o2)
                  break e;
                o2--, u2 += n2[s2++] << l2, l2 += 8;
              }
              if ((65535 & u2) != (u2 >>> 16 ^ 65535)) {
                e2.msg = "invalid stored block lengths", r2.mode = 30;
                break;
              }
              if (r2.length = 65535 & u2, l2 = u2 = 0, r2.mode = 15, 6 === t2)
                break e;
            case 15:
              r2.mode = 16;
            case 16:
              if (d = r2.length) {
                if (o2 < d && (d = o2), h2 < d && (d = h2), 0 === d)
                  break e;
                I.arraySet(i2, n2, s2, d, a2), o2 -= d, s2 += d, h2 -= d, a2 += d, r2.length -= d;
                break;
              }
              r2.mode = 12;
              break;
            case 17:
              for (; l2 < 14; ) {
                if (0 === o2)
                  break e;
                o2--, u2 += n2[s2++] << l2, l2 += 8;
              }
              if (r2.nlen = 257 + (31 & u2), u2 >>>= 5, l2 -= 5, r2.ndist = 1 + (31 & u2), u2 >>>= 5, l2 -= 5, r2.ncode = 4 + (15 & u2), u2 >>>= 4, l2 -= 4, 286 < r2.nlen || 30 < r2.ndist) {
                e2.msg = "too many length or distance symbols", r2.mode = 30;
                break;
              }
              r2.have = 0, r2.mode = 18;
            case 18:
              for (; r2.have < r2.ncode; ) {
                for (; l2 < 3; ) {
                  if (0 === o2)
                    break e;
                  o2--, u2 += n2[s2++] << l2, l2 += 8;
                }
                r2.lens[A[r2.have++]] = 7 & u2, u2 >>>= 3, l2 -= 3;
              }
              for (; r2.have < 19; )
                r2.lens[A[r2.have++]] = 0;
              if (r2.lencode = r2.lendyn, r2.lenbits = 7, S = { bits: r2.lenbits }, x = T(0, r2.lens, 0, 19, r2.lencode, 0, r2.work, S), r2.lenbits = S.bits, x) {
                e2.msg = "invalid code lengths set", r2.mode = 30;
                break;
              }
              r2.have = 0, r2.mode = 19;
            case 19:
              for (; r2.have < r2.nlen + r2.ndist; ) {
                for (; g = (C = r2.lencode[u2 & (1 << r2.lenbits) - 1]) >>> 16 & 255, b = 65535 & C, !((_ = C >>> 24) <= l2); ) {
                  if (0 === o2)
                    break e;
                  o2--, u2 += n2[s2++] << l2, l2 += 8;
                }
                if (b < 16)
                  u2 >>>= _, l2 -= _, r2.lens[r2.have++] = b;
                else {
                  if (16 === b) {
                    for (z = _ + 2; l2 < z; ) {
                      if (0 === o2)
                        break e;
                      o2--, u2 += n2[s2++] << l2, l2 += 8;
                    }
                    if (u2 >>>= _, l2 -= _, 0 === r2.have) {
                      e2.msg = "invalid bit length repeat", r2.mode = 30;
                      break;
                    }
                    k = r2.lens[r2.have - 1], d = 3 + (3 & u2), u2 >>>= 2, l2 -= 2;
                  } else if (17 === b) {
                    for (z = _ + 3; l2 < z; ) {
                      if (0 === o2)
                        break e;
                      o2--, u2 += n2[s2++] << l2, l2 += 8;
                    }
                    l2 -= _, k = 0, d = 3 + (7 & (u2 >>>= _)), u2 >>>= 3, l2 -= 3;
                  } else {
                    for (z = _ + 7; l2 < z; ) {
                      if (0 === o2)
                        break e;
                      o2--, u2 += n2[s2++] << l2, l2 += 8;
                    }
                    l2 -= _, k = 0, d = 11 + (127 & (u2 >>>= _)), u2 >>>= 7, l2 -= 7;
                  }
                  if (r2.have + d > r2.nlen + r2.ndist) {
                    e2.msg = "invalid bit length repeat", r2.mode = 30;
                    break;
                  }
                  for (; d--; )
                    r2.lens[r2.have++] = k;
                }
              }
              if (30 === r2.mode)
                break;
              if (0 === r2.lens[256]) {
                e2.msg = "invalid code -- missing end-of-block", r2.mode = 30;
                break;
              }
              if (r2.lenbits = 9, S = { bits: r2.lenbits }, x = T(D, r2.lens, 0, r2.nlen, r2.lencode, 0, r2.work, S), r2.lenbits = S.bits, x) {
                e2.msg = "invalid literal/lengths set", r2.mode = 30;
                break;
              }
              if (r2.distbits = 6, r2.distcode = r2.distdyn, S = { bits: r2.distbits }, x = T(F, r2.lens, r2.nlen, r2.ndist, r2.distcode, 0, r2.work, S), r2.distbits = S.bits, x) {
                e2.msg = "invalid distances set", r2.mode = 30;
                break;
              }
              if (r2.mode = 20, 6 === t2)
                break e;
            case 20:
              r2.mode = 21;
            case 21:
              if (6 <= o2 && 258 <= h2) {
                e2.next_out = a2, e2.avail_out = h2, e2.next_in = s2, e2.avail_in = o2, r2.hold = u2, r2.bits = l2, R(e2, c2), a2 = e2.next_out, i2 = e2.output, h2 = e2.avail_out, s2 = e2.next_in, n2 = e2.input, o2 = e2.avail_in, u2 = r2.hold, l2 = r2.bits, 12 === r2.mode && (r2.back = -1);
                break;
              }
              for (r2.back = 0; g = (C = r2.lencode[u2 & (1 << r2.lenbits) - 1]) >>> 16 & 255, b = 65535 & C, !((_ = C >>> 24) <= l2); ) {
                if (0 === o2)
                  break e;
                o2--, u2 += n2[s2++] << l2, l2 += 8;
              }
              if (g && 0 == (240 & g)) {
                for (v = _, y = g, w = b; g = (C = r2.lencode[w + ((u2 & (1 << v + y) - 1) >> v)]) >>> 16 & 255, b = 65535 & C, !(v + (_ = C >>> 24) <= l2); ) {
                  if (0 === o2)
                    break e;
                  o2--, u2 += n2[s2++] << l2, l2 += 8;
                }
                u2 >>>= v, l2 -= v, r2.back += v;
              }
              if (u2 >>>= _, l2 -= _, r2.back += _, r2.length = b, 0 === g) {
                r2.mode = 26;
                break;
              }
              if (32 & g) {
                r2.back = -1, r2.mode = 12;
                break;
              }
              if (64 & g) {
                e2.msg = "invalid literal/length code", r2.mode = 30;
                break;
              }
              r2.extra = 15 & g, r2.mode = 22;
            case 22:
              if (r2.extra) {
                for (z = r2.extra; l2 < z; ) {
                  if (0 === o2)
                    break e;
                  o2--, u2 += n2[s2++] << l2, l2 += 8;
                }
                r2.length += u2 & (1 << r2.extra) - 1, u2 >>>= r2.extra, l2 -= r2.extra, r2.back += r2.extra;
              }
              r2.was = r2.length, r2.mode = 23;
            case 23:
              for (; g = (C = r2.distcode[u2 & (1 << r2.distbits) - 1]) >>> 16 & 255, b = 65535 & C, !((_ = C >>> 24) <= l2); ) {
                if (0 === o2)
                  break e;
                o2--, u2 += n2[s2++] << l2, l2 += 8;
              }
              if (0 == (240 & g)) {
                for (v = _, y = g, w = b; g = (C = r2.distcode[w + ((u2 & (1 << v + y) - 1) >> v)]) >>> 16 & 255, b = 65535 & C, !(v + (_ = C >>> 24) <= l2); ) {
                  if (0 === o2)
                    break e;
                  o2--, u2 += n2[s2++] << l2, l2 += 8;
                }
                u2 >>>= v, l2 -= v, r2.back += v;
              }
              if (u2 >>>= _, l2 -= _, r2.back += _, 64 & g) {
                e2.msg = "invalid distance code", r2.mode = 30;
                break;
              }
              r2.offset = b, r2.extra = 15 & g, r2.mode = 24;
            case 24:
              if (r2.extra) {
                for (z = r2.extra; l2 < z; ) {
                  if (0 === o2)
                    break e;
                  o2--, u2 += n2[s2++] << l2, l2 += 8;
                }
                r2.offset += u2 & (1 << r2.extra) - 1, u2 >>>= r2.extra, l2 -= r2.extra, r2.back += r2.extra;
              }
              if (r2.offset > r2.dmax) {
                e2.msg = "invalid distance too far back", r2.mode = 30;
                break;
              }
              r2.mode = 25;
            case 25:
              if (0 === h2)
                break e;
              if (d = c2 - h2, r2.offset > d) {
                if ((d = r2.offset - d) > r2.whave && r2.sane) {
                  e2.msg = "invalid distance too far back", r2.mode = 30;
                  break;
                }
                p = d > r2.wnext ? (d -= r2.wnext, r2.wsize - d) : r2.wnext - d, d > r2.length && (d = r2.length), m = r2.window;
              } else
                m = i2, p = a2 - r2.offset, d = r2.length;
              for (h2 < d && (d = h2), h2 -= d, r2.length -= d; i2[a2++] = m[p++], --d; )
                ;
              0 === r2.length && (r2.mode = 21);
              break;
            case 26:
              if (0 === h2)
                break e;
              i2[a2++] = r2.length, h2--, r2.mode = 21;
              break;
            case 27:
              if (r2.wrap) {
                for (; l2 < 32; ) {
                  if (0 === o2)
                    break e;
                  o2--, u2 |= n2[s2++] << l2, l2 += 8;
                }
                if (c2 -= h2, e2.total_out += c2, r2.total += c2, c2 && (e2.adler = r2.check = r2.flags ? B(r2.check, i2, c2, a2 - c2) : O(r2.check, i2, c2, a2 - c2)), c2 = h2, (r2.flags ? u2 : L(u2)) !== r2.check) {
                  e2.msg = "incorrect data check", r2.mode = 30;
                  break;
                }
                l2 = u2 = 0;
              }
              r2.mode = 28;
            case 28:
              if (r2.wrap && r2.flags) {
                for (; l2 < 32; ) {
                  if (0 === o2)
                    break e;
                  o2--, u2 += n2[s2++] << l2, l2 += 8;
                }
                if (u2 !== (4294967295 & r2.total)) {
                  e2.msg = "incorrect length check", r2.mode = 30;
                  break;
                }
                l2 = u2 = 0;
              }
              r2.mode = 29;
            case 29:
              x = 1;
              break e;
            case 30:
              x = -3;
              break e;
            case 31:
              return -4;
            case 32:
            default:
              return U;
          }
      return e2.next_out = a2, e2.avail_out = h2, e2.next_in = s2, e2.avail_in = o2, r2.hold = u2, r2.bits = l2, (r2.wsize || c2 !== e2.avail_out && r2.mode < 30 && (r2.mode < 27 || 4 !== t2)) && Z(e2, e2.output, e2.next_out, c2 - e2.avail_out) ? (r2.mode = 31, -4) : (f2 -= e2.avail_in, c2 -= e2.avail_out, e2.total_in += f2, e2.total_out += c2, r2.total += c2, r2.wrap && c2 && (e2.adler = r2.check = r2.flags ? B(r2.check, i2, c2, e2.next_out - c2) : O(r2.check, i2, c2, e2.next_out - c2)), e2.data_type = r2.bits + (r2.last ? 64 : 0) + (12 === r2.mode ? 128 : 0) + (20 === r2.mode || 15 === r2.mode ? 256 : 0), (0 == f2 && 0 === c2 || 4 === t2) && x === N && (x = -5), x);
    }, r.inflateEnd = function(e2) {
      if (!e2 || !e2.state)
        return U;
      var t2 = e2.state;
      return t2.window && (t2.window = null), e2.state = null, N;
    }, r.inflateGetHeader = function(e2, t2) {
      var r2;
      return e2 && e2.state ? 0 == (2 & (r2 = e2.state).wrap) ? U : ((r2.head = t2).done = false, N) : U;
    }, r.inflateSetDictionary = function(e2, t2) {
      var r2, n2 = t2.length;
      return e2 && e2.state ? 0 !== (r2 = e2.state).wrap && 11 !== r2.mode ? U : 11 === r2.mode && O(1, t2, n2, 0) !== r2.check ? -3 : Z(e2, t2, n2, n2) ? (r2.mode = 31, -4) : (r2.havedict = 1, N) : U;
    }, r.inflateInfo = "pako inflate (from Nodeca project)";
  }, { "../utils/common": 41, "./adler32": 43, "./crc32": 45, "./inffast": 48, "./inftrees": 50 }], 50: [function(e, t, r) {
    "use strict";
    var D = e("../utils/common"), F = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 0, 0], N = [16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 18, 18, 18, 18, 19, 19, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21, 16, 72, 78], U = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 0, 0], P = [16, 16, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 22, 23, 23, 24, 24, 25, 25, 26, 26, 27, 27, 28, 28, 29, 29, 64, 64];
    t.exports = function(e2, t2, r2, n, i, s, a, o) {
      var h, u, l, f, c, d, p, m, _, g = o.bits, b = 0, v = 0, y = 0, w = 0, k = 0, x = 0, S = 0, z = 0, C = 0, E = 0, A = null, I = 0, O = new D.Buf16(16), B = new D.Buf16(16), R = null, T = 0;
      for (b = 0; b <= 15; b++)
        O[b] = 0;
      for (v = 0; v < n; v++)
        O[t2[r2 + v]]++;
      for (k = g, w = 15; 1 <= w && 0 === O[w]; w--)
        ;
      if (w < k && (k = w), 0 === w)
        return i[s++] = 20971520, i[s++] = 20971520, o.bits = 1, 0;
      for (y = 1; y < w && 0 === O[y]; y++)
        ;
      for (k < y && (k = y), b = z = 1; b <= 15; b++)
        if (z <<= 1, (z -= O[b]) < 0)
          return -1;
      if (0 < z && (0 === e2 || 1 !== w))
        return -1;
      for (B[1] = 0, b = 1; b < 15; b++)
        B[b + 1] = B[b] + O[b];
      for (v = 0; v < n; v++)
        0 !== t2[r2 + v] && (a[B[t2[r2 + v]]++] = v);
      if (d = 0 === e2 ? (A = R = a, 19) : 1 === e2 ? (A = F, I -= 257, R = N, T -= 257, 256) : (A = U, R = P, -1), b = y, c = s, S = v = E = 0, l = -1, f = (C = 1 << (x = k)) - 1, 1 === e2 && 852 < C || 2 === e2 && 592 < C)
        return 1;
      for (; ; ) {
        for (p = b - S, _ = a[v] < d ? (m = 0, a[v]) : a[v] > d ? (m = R[T + a[v]], A[I + a[v]]) : (m = 96, 0), h = 1 << b - S, y = u = 1 << x; i[c + (E >> S) + (u -= h)] = p << 24 | m << 16 | _ | 0, 0 !== u; )
          ;
        for (h = 1 << b - 1; E & h; )
          h >>= 1;
        if (0 !== h ? (E &= h - 1, E += h) : E = 0, v++, 0 == --O[b]) {
          if (b === w)
            break;
          b = t2[r2 + a[v]];
        }
        if (k < b && (E & f) !== l) {
          for (0 === S && (S = k), c += y, z = 1 << (x = b - S); x + S < w && !((z -= O[x + S]) <= 0); )
            x++, z <<= 1;
          if (C += 1 << x, 1 === e2 && 852 < C || 2 === e2 && 592 < C)
            return 1;
          i[l = E & f] = k << 24 | x << 16 | c - s | 0;
        }
      }
      return 0 !== E && (i[c + E] = b - S << 24 | 64 << 16 | 0), o.bits = k, 0;
    };
  }, { "../utils/common": 41 }], 51: [function(e, t, r) {
    "use strict";
    t.exports = { 2: "need dictionary", 1: "stream end", 0: "", "-1": "file error", "-2": "stream error", "-3": "data error", "-4": "insufficient memory", "-5": "buffer error", "-6": "incompatible version" };
  }, {}], 52: [function(e, t, r) {
    "use strict";
    var i = e("../utils/common"), o = 0, h = 1;
    function n(e2) {
      for (var t2 = e2.length; 0 <= --t2; )
        e2[t2] = 0;
    }
    var s = 0, a = 29, u = 256, l = u + 1 + a, f = 30, c = 19, _ = 2 * l + 1, g = 15, d = 16, p = 7, m = 256, b = 16, v = 17, y = 18, w = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0], k = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13], x = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7], S = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], z = new Array(2 * (l + 2));
    n(z);
    var C = new Array(2 * f);
    n(C);
    var E = new Array(512);
    n(E);
    var A = new Array(256);
    n(A);
    var I = new Array(a);
    n(I);
    var O, B, R, T = new Array(f);
    function D(e2, t2, r2, n2, i2) {
      this.static_tree = e2, this.extra_bits = t2, this.extra_base = r2, this.elems = n2, this.max_length = i2, this.has_stree = e2 && e2.length;
    }
    function F(e2, t2) {
      this.dyn_tree = e2, this.max_code = 0, this.stat_desc = t2;
    }
    function N(e2) {
      return e2 < 256 ? E[e2] : E[256 + (e2 >>> 7)];
    }
    function U(e2, t2) {
      e2.pending_buf[e2.pending++] = 255 & t2, e2.pending_buf[e2.pending++] = t2 >>> 8 & 255;
    }
    function P(e2, t2, r2) {
      e2.bi_valid > d - r2 ? (e2.bi_buf |= t2 << e2.bi_valid & 65535, U(e2, e2.bi_buf), e2.bi_buf = t2 >> d - e2.bi_valid, e2.bi_valid += r2 - d) : (e2.bi_buf |= t2 << e2.bi_valid & 65535, e2.bi_valid += r2);
    }
    function L(e2, t2, r2) {
      P(e2, r2[2 * t2], r2[2 * t2 + 1]);
    }
    function j(e2, t2) {
      for (var r2 = 0; r2 |= 1 & e2, e2 >>>= 1, r2 <<= 1, 0 < --t2; )
        ;
      return r2 >>> 1;
    }
    function Z(e2, t2, r2) {
      var n2, i2, s2 = new Array(g + 1), a2 = 0;
      for (n2 = 1; n2 <= g; n2++)
        s2[n2] = a2 = a2 + r2[n2 - 1] << 1;
      for (i2 = 0; i2 <= t2; i2++) {
        var o2 = e2[2 * i2 + 1];
        0 !== o2 && (e2[2 * i2] = j(s2[o2]++, o2));
      }
    }
    function W(e2) {
      var t2;
      for (t2 = 0; t2 < l; t2++)
        e2.dyn_ltree[2 * t2] = 0;
      for (t2 = 0; t2 < f; t2++)
        e2.dyn_dtree[2 * t2] = 0;
      for (t2 = 0; t2 < c; t2++)
        e2.bl_tree[2 * t2] = 0;
      e2.dyn_ltree[2 * m] = 1, e2.opt_len = e2.static_len = 0, e2.last_lit = e2.matches = 0;
    }
    function M(e2) {
      8 < e2.bi_valid ? U(e2, e2.bi_buf) : 0 < e2.bi_valid && (e2.pending_buf[e2.pending++] = e2.bi_buf), e2.bi_buf = 0, e2.bi_valid = 0;
    }
    function H(e2, t2, r2, n2) {
      var i2 = 2 * t2, s2 = 2 * r2;
      return e2[i2] < e2[s2] || e2[i2] === e2[s2] && n2[t2] <= n2[r2];
    }
    function G(e2, t2, r2) {
      for (var n2 = e2.heap[r2], i2 = r2 << 1; i2 <= e2.heap_len && (i2 < e2.heap_len && H(t2, e2.heap[i2 + 1], e2.heap[i2], e2.depth) && i2++, !H(t2, n2, e2.heap[i2], e2.depth)); )
        e2.heap[r2] = e2.heap[i2], r2 = i2, i2 <<= 1;
      e2.heap[r2] = n2;
    }
    function K(e2, t2, r2) {
      var n2, i2, s2, a2, o2 = 0;
      if (0 !== e2.last_lit)
        for (; n2 = e2.pending_buf[e2.d_buf + 2 * o2] << 8 | e2.pending_buf[e2.d_buf + 2 * o2 + 1], i2 = e2.pending_buf[e2.l_buf + o2], o2++, 0 === n2 ? L(e2, i2, t2) : (L(e2, (s2 = A[i2]) + u + 1, t2), 0 !== (a2 = w[s2]) && P(e2, i2 -= I[s2], a2), L(e2, s2 = N(--n2), r2), 0 !== (a2 = k[s2]) && P(e2, n2 -= T[s2], a2)), o2 < e2.last_lit; )
          ;
      L(e2, m, t2);
    }
    function Y(e2, t2) {
      var r2, n2, i2, s2 = t2.dyn_tree, a2 = t2.stat_desc.static_tree, o2 = t2.stat_desc.has_stree, h2 = t2.stat_desc.elems, u2 = -1;
      for (e2.heap_len = 0, e2.heap_max = _, r2 = 0; r2 < h2; r2++)
        0 !== s2[2 * r2] ? (e2.heap[++e2.heap_len] = u2 = r2, e2.depth[r2] = 0) : s2[2 * r2 + 1] = 0;
      for (; e2.heap_len < 2; )
        s2[2 * (i2 = e2.heap[++e2.heap_len] = u2 < 2 ? ++u2 : 0)] = 1, e2.depth[i2] = 0, e2.opt_len--, o2 && (e2.static_len -= a2[2 * i2 + 1]);
      for (t2.max_code = u2, r2 = e2.heap_len >> 1; 1 <= r2; r2--)
        G(e2, s2, r2);
      for (i2 = h2; r2 = e2.heap[1], e2.heap[1] = e2.heap[e2.heap_len--], G(e2, s2, 1), n2 = e2.heap[1], e2.heap[--e2.heap_max] = r2, e2.heap[--e2.heap_max] = n2, s2[2 * i2] = s2[2 * r2] + s2[2 * n2], e2.depth[i2] = (e2.depth[r2] >= e2.depth[n2] ? e2.depth[r2] : e2.depth[n2]) + 1, s2[2 * r2 + 1] = s2[2 * n2 + 1] = i2, e2.heap[1] = i2++, G(e2, s2, 1), 2 <= e2.heap_len; )
        ;
      e2.heap[--e2.heap_max] = e2.heap[1], function(e3, t3) {
        var r3, n3, i3, s3, a3, o3, h3 = t3.dyn_tree, u3 = t3.max_code, l2 = t3.stat_desc.static_tree, f2 = t3.stat_desc.has_stree, c2 = t3.stat_desc.extra_bits, d2 = t3.stat_desc.extra_base, p2 = t3.stat_desc.max_length, m2 = 0;
        for (s3 = 0; s3 <= g; s3++)
          e3.bl_count[s3] = 0;
        for (h3[2 * e3.heap[e3.heap_max] + 1] = 0, r3 = e3.heap_max + 1; r3 < _; r3++)
          p2 < (s3 = h3[2 * h3[2 * (n3 = e3.heap[r3]) + 1] + 1] + 1) && (s3 = p2, m2++), h3[2 * n3 + 1] = s3, u3 < n3 || (e3.bl_count[s3]++, a3 = 0, d2 <= n3 && (a3 = c2[n3 - d2]), o3 = h3[2 * n3], e3.opt_len += o3 * (s3 + a3), f2 && (e3.static_len += o3 * (l2[2 * n3 + 1] + a3)));
        if (0 !== m2) {
          do {
            for (s3 = p2 - 1; 0 === e3.bl_count[s3]; )
              s3--;
            e3.bl_count[s3]--, e3.bl_count[s3 + 1] += 2, e3.bl_count[p2]--, m2 -= 2;
          } while (0 < m2);
          for (s3 = p2; 0 !== s3; s3--)
            for (n3 = e3.bl_count[s3]; 0 !== n3; )
              u3 < (i3 = e3.heap[--r3]) || (h3[2 * i3 + 1] !== s3 && (e3.opt_len += (s3 - h3[2 * i3 + 1]) * h3[2 * i3], h3[2 * i3 + 1] = s3), n3--);
        }
      }(e2, t2), Z(s2, u2, e2.bl_count);
    }
    function X(e2, t2, r2) {
      var n2, i2, s2 = -1, a2 = t2[1], o2 = 0, h2 = 7, u2 = 4;
      for (0 === a2 && (h2 = 138, u2 = 3), t2[2 * (r2 + 1) + 1] = 65535, n2 = 0; n2 <= r2; n2++)
        i2 = a2, a2 = t2[2 * (n2 + 1) + 1], ++o2 < h2 && i2 === a2 || (o2 < u2 ? e2.bl_tree[2 * i2] += o2 : 0 !== i2 ? (i2 !== s2 && e2.bl_tree[2 * i2]++, e2.bl_tree[2 * b]++) : o2 <= 10 ? e2.bl_tree[2 * v]++ : e2.bl_tree[2 * y]++, s2 = i2, u2 = (o2 = 0) === a2 ? (h2 = 138, 3) : i2 === a2 ? (h2 = 6, 3) : (h2 = 7, 4));
    }
    function V(e2, t2, r2) {
      var n2, i2, s2 = -1, a2 = t2[1], o2 = 0, h2 = 7, u2 = 4;
      for (0 === a2 && (h2 = 138, u2 = 3), n2 = 0; n2 <= r2; n2++)
        if (i2 = a2, a2 = t2[2 * (n2 + 1) + 1], !(++o2 < h2 && i2 === a2)) {
          if (o2 < u2)
            for (; L(e2, i2, e2.bl_tree), 0 != --o2; )
              ;
          else
            0 !== i2 ? (i2 !== s2 && (L(e2, i2, e2.bl_tree), o2--), L(e2, b, e2.bl_tree), P(e2, o2 - 3, 2)) : o2 <= 10 ? (L(e2, v, e2.bl_tree), P(e2, o2 - 3, 3)) : (L(e2, y, e2.bl_tree), P(e2, o2 - 11, 7));
          s2 = i2, u2 = (o2 = 0) === a2 ? (h2 = 138, 3) : i2 === a2 ? (h2 = 6, 3) : (h2 = 7, 4);
        }
    }
    n(T);
    var q = false;
    function J(e2, t2, r2, n2) {
      P(e2, (s << 1) + (n2 ? 1 : 0), 3), function(e3, t3, r3, n3) {
        M(e3), n3 && (U(e3, r3), U(e3, ~r3)), i.arraySet(e3.pending_buf, e3.window, t3, r3, e3.pending), e3.pending += r3;
      }(e2, t2, r2, true);
    }
    r._tr_init = function(e2) {
      q || (function() {
        var e3, t2, r2, n2, i2, s2 = new Array(g + 1);
        for (n2 = r2 = 0; n2 < a - 1; n2++)
          for (I[n2] = r2, e3 = 0; e3 < 1 << w[n2]; e3++)
            A[r2++] = n2;
        for (A[r2 - 1] = n2, n2 = i2 = 0; n2 < 16; n2++)
          for (T[n2] = i2, e3 = 0; e3 < 1 << k[n2]; e3++)
            E[i2++] = n2;
        for (i2 >>= 7; n2 < f; n2++)
          for (T[n2] = i2 << 7, e3 = 0; e3 < 1 << k[n2] - 7; e3++)
            E[256 + i2++] = n2;
        for (t2 = 0; t2 <= g; t2++)
          s2[t2] = 0;
        for (e3 = 0; e3 <= 143; )
          z[2 * e3 + 1] = 8, e3++, s2[8]++;
        for (; e3 <= 255; )
          z[2 * e3 + 1] = 9, e3++, s2[9]++;
        for (; e3 <= 279; )
          z[2 * e3 + 1] = 7, e3++, s2[7]++;
        for (; e3 <= 287; )
          z[2 * e3 + 1] = 8, e3++, s2[8]++;
        for (Z(z, l + 1, s2), e3 = 0; e3 < f; e3++)
          C[2 * e3 + 1] = 5, C[2 * e3] = j(e3, 5);
        O = new D(z, w, u + 1, l, g), B = new D(C, k, 0, f, g), R = new D(new Array(0), x, 0, c, p);
      }(), q = true), e2.l_desc = new F(e2.dyn_ltree, O), e2.d_desc = new F(e2.dyn_dtree, B), e2.bl_desc = new F(e2.bl_tree, R), e2.bi_buf = 0, e2.bi_valid = 0, W(e2);
    }, r._tr_stored_block = J, r._tr_flush_block = function(e2, t2, r2, n2) {
      var i2, s2, a2 = 0;
      0 < e2.level ? (2 === e2.strm.data_type && (e2.strm.data_type = function(e3) {
        var t3, r3 = 4093624447;
        for (t3 = 0; t3 <= 31; t3++, r3 >>>= 1)
          if (1 & r3 && 0 !== e3.dyn_ltree[2 * t3])
            return o;
        if (0 !== e3.dyn_ltree[18] || 0 !== e3.dyn_ltree[20] || 0 !== e3.dyn_ltree[26])
          return h;
        for (t3 = 32; t3 < u; t3++)
          if (0 !== e3.dyn_ltree[2 * t3])
            return h;
        return o;
      }(e2)), Y(e2, e2.l_desc), Y(e2, e2.d_desc), a2 = function(e3) {
        var t3;
        for (X(e3, e3.dyn_ltree, e3.l_desc.max_code), X(e3, e3.dyn_dtree, e3.d_desc.max_code), Y(e3, e3.bl_desc), t3 = c - 1; 3 <= t3 && 0 === e3.bl_tree[2 * S[t3] + 1]; t3--)
          ;
        return e3.opt_len += 3 * (t3 + 1) + 5 + 5 + 4, t3;
      }(e2), i2 = e2.opt_len + 3 + 7 >>> 3, (s2 = e2.static_len + 3 + 7 >>> 3) <= i2 && (i2 = s2)) : i2 = s2 = r2 + 5, r2 + 4 <= i2 && -1 !== t2 ? J(e2, t2, r2, n2) : 4 === e2.strategy || s2 === i2 ? (P(e2, 2 + (n2 ? 1 : 0), 3), K(e2, z, C)) : (P(e2, 4 + (n2 ? 1 : 0), 3), function(e3, t3, r3, n3) {
        var i3;
        for (P(e3, t3 - 257, 5), P(e3, r3 - 1, 5), P(e3, n3 - 4, 4), i3 = 0; i3 < n3; i3++)
          P(e3, e3.bl_tree[2 * S[i3] + 1], 3);
        V(e3, e3.dyn_ltree, t3 - 1), V(e3, e3.dyn_dtree, r3 - 1);
      }(e2, e2.l_desc.max_code + 1, e2.d_desc.max_code + 1, a2 + 1), K(e2, e2.dyn_ltree, e2.dyn_dtree)), W(e2), n2 && M(e2);
    }, r._tr_tally = function(e2, t2, r2) {
      return e2.pending_buf[e2.d_buf + 2 * e2.last_lit] = t2 >>> 8 & 255, e2.pending_buf[e2.d_buf + 2 * e2.last_lit + 1] = 255 & t2, e2.pending_buf[e2.l_buf + e2.last_lit] = 255 & r2, e2.last_lit++, 0 === t2 ? e2.dyn_ltree[2 * r2]++ : (e2.matches++, t2--, e2.dyn_ltree[2 * (A[r2] + u + 1)]++, e2.dyn_dtree[2 * N(t2)]++), e2.last_lit === e2.lit_bufsize - 1;
    }, r._tr_align = function(e2) {
      P(e2, 2, 3), L(e2, m, z), function(e3) {
        16 === e3.bi_valid ? (U(e3, e3.bi_buf), e3.bi_buf = 0, e3.bi_valid = 0) : 8 <= e3.bi_valid && (e3.pending_buf[e3.pending++] = 255 & e3.bi_buf, e3.bi_buf >>= 8, e3.bi_valid -= 8);
      }(e2);
    };
  }, { "../utils/common": 41 }], 53: [function(e, t, r) {
    "use strict";
    t.exports = function() {
      this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0;
    };
  }, {}], 54: [function(e, t, r) {
    (function(e2) {
      !function(r2, n) {
        "use strict";
        if (!r2.setImmediate) {
          var i, s, t2, a, o = 1, h = {}, u = false, l = r2.document, e3 = Object.getPrototypeOf && Object.getPrototypeOf(r2);
          e3 = e3 && e3.setTimeout ? e3 : r2, i = "[object process]" === {}.toString.call(r2.process) ? function(e4) {
            process.nextTick(function() {
              c(e4);
            });
          } : function() {
            if (r2.postMessage && !r2.importScripts) {
              var e4 = true, t3 = r2.onmessage;
              return r2.onmessage = function() {
                e4 = false;
              }, r2.postMessage("", "*"), r2.onmessage = t3, e4;
            }
          }() ? (a = "setImmediate$" + Math.random() + "$", r2.addEventListener ? r2.addEventListener("message", d, false) : r2.attachEvent("onmessage", d), function(e4) {
            r2.postMessage(a + e4, "*");
          }) : r2.MessageChannel ? ((t2 = new MessageChannel()).port1.onmessage = function(e4) {
            c(e4.data);
          }, function(e4) {
            t2.port2.postMessage(e4);
          }) : l && "onreadystatechange" in l.createElement("script") ? (s = l.documentElement, function(e4) {
            var t3 = l.createElement("script");
            t3.onreadystatechange = function() {
              c(e4), t3.onreadystatechange = null, s.removeChild(t3), t3 = null;
            }, s.appendChild(t3);
          }) : function(e4) {
            setTimeout(c, 0, e4);
          }, e3.setImmediate = function(e4) {
            "function" != typeof e4 && (e4 = new Function("" + e4));
            for (var t3 = new Array(arguments.length - 1), r3 = 0; r3 < t3.length; r3++)
              t3[r3] = arguments[r3 + 1];
            var n2 = { callback: e4, args: t3 };
            return h[o] = n2, i(o), o++;
          }, e3.clearImmediate = f;
        }
        function f(e4) {
          delete h[e4];
        }
        function c(e4) {
          if (u)
            setTimeout(c, 0, e4);
          else {
            var t3 = h[e4];
            if (t3) {
              u = true;
              try {
                !function(e5) {
                  var t4 = e5.callback, r3 = e5.args;
                  switch (r3.length) {
                    case 0:
                      t4();
                      break;
                    case 1:
                      t4(r3[0]);
                      break;
                    case 2:
                      t4(r3[0], r3[1]);
                      break;
                    case 3:
                      t4(r3[0], r3[1], r3[2]);
                      break;
                    default:
                      t4.apply(n, r3);
                  }
                }(t3);
              } finally {
                f(e4), u = false;
              }
            }
          }
        }
        function d(e4) {
          e4.source === r2 && "string" == typeof e4.data && 0 === e4.data.indexOf(a) && c(+e4.data.slice(a.length));
        }
      }("undefined" == typeof self ? void 0 === e2 ? this : e2 : self);
    }).call(this, "undefined" != typeof __webpack_require__.g ? __webpack_require__.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
  }, {}] }, {}, [10])(10);
});


/***/ }),

/***/ "./node_modules/lodash.get/index.js":
/*!******************************************!*\
  !*** ./node_modules/lodash.get/index.js ***!
  \******************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var FUNC_ERROR_TEXT = "Expected a function";
var HASH_UNDEFINED = "__lodash_hash_undefined__";
var INFINITY = 1 / 0;
var funcTag = "[object Function]", genTag = "[object GeneratorFunction]", symbolTag = "[object Symbol]";
var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, reIsPlainProp = /^\w*$/, reLeadingDot = /^\./, rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
var reEscapeChar = /\\(\\)?/g;
var reIsHostCtor = /^\[object .+?Constructor\]$/;
var freeGlobal = typeof __webpack_require__.g == "object" && __webpack_require__.g && __webpack_require__.g.Object === Object && __webpack_require__.g;
var freeSelf = typeof self == "object" && self && self.Object === Object && self;
var root = freeGlobal || freeSelf || Function("return this")();
function getValue(object, key) {
  return object == null ? void 0 : object[key];
}
function isHostObject(value) {
  var result = false;
  if (value != null && typeof value.toString != "function") {
    try {
      result = !!(value + "");
    } catch (e) {
    }
  }
  return result;
}
var arrayProto = Array.prototype, funcProto = Function.prototype, objectProto = Object.prototype;
var coreJsData = root["__core-js_shared__"];
var maskSrcKey = function() {
  var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || "");
  return uid ? "Symbol(src)_1." + uid : "";
}();
var funcToString = funcProto.toString;
var hasOwnProperty = objectProto.hasOwnProperty;
var objectToString = objectProto.toString;
var reIsNative = RegExp(
  "^" + funcToString.call(hasOwnProperty).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
);
var Symbol = root.Symbol, splice = arrayProto.splice;
var Map = getNative(root, "Map"), nativeCreate = getNative(Object, "create");
var symbolProto = Symbol ? Symbol.prototype : void 0, symbolToString = symbolProto ? symbolProto.toString : void 0;
function Hash(entries) {
  var index = -1, length = entries ? entries.length : 0;
  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}
function hashClear() {
  this.__data__ = nativeCreate ? nativeCreate(null) : {};
}
function hashDelete(key) {
  return this.has(key) && delete this.__data__[key];
}
function hashGet(key) {
  var data = this.__data__;
  if (nativeCreate) {
    var result = data[key];
    return result === HASH_UNDEFINED ? void 0 : result;
  }
  return hasOwnProperty.call(data, key) ? data[key] : void 0;
}
function hashHas(key) {
  var data = this.__data__;
  return nativeCreate ? data[key] !== void 0 : hasOwnProperty.call(data, key);
}
function hashSet(key, value) {
  var data = this.__data__;
  data[key] = nativeCreate && value === void 0 ? HASH_UNDEFINED : value;
  return this;
}
Hash.prototype.clear = hashClear;
Hash.prototype["delete"] = hashDelete;
Hash.prototype.get = hashGet;
Hash.prototype.has = hashHas;
Hash.prototype.set = hashSet;
function ListCache(entries) {
  var index = -1, length = entries ? entries.length : 0;
  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}
function listCacheClear() {
  this.__data__ = [];
}
function listCacheDelete(key) {
  var data = this.__data__, index = assocIndexOf(data, key);
  if (index < 0) {
    return false;
  }
  var lastIndex = data.length - 1;
  if (index == lastIndex) {
    data.pop();
  } else {
    splice.call(data, index, 1);
  }
  return true;
}
function listCacheGet(key) {
  var data = this.__data__, index = assocIndexOf(data, key);
  return index < 0 ? void 0 : data[index][1];
}
function listCacheHas(key) {
  return assocIndexOf(this.__data__, key) > -1;
}
function listCacheSet(key, value) {
  var data = this.__data__, index = assocIndexOf(data, key);
  if (index < 0) {
    data.push([key, value]);
  } else {
    data[index][1] = value;
  }
  return this;
}
ListCache.prototype.clear = listCacheClear;
ListCache.prototype["delete"] = listCacheDelete;
ListCache.prototype.get = listCacheGet;
ListCache.prototype.has = listCacheHas;
ListCache.prototype.set = listCacheSet;
function MapCache(entries) {
  var index = -1, length = entries ? entries.length : 0;
  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}
function mapCacheClear() {
  this.__data__ = {
    "hash": new Hash(),
    "map": new (Map || ListCache)(),
    "string": new Hash()
  };
}
function mapCacheDelete(key) {
  return getMapData(this, key)["delete"](key);
}
function mapCacheGet(key) {
  return getMapData(this, key).get(key);
}
function mapCacheHas(key) {
  return getMapData(this, key).has(key);
}
function mapCacheSet(key, value) {
  getMapData(this, key).set(key, value);
  return this;
}
MapCache.prototype.clear = mapCacheClear;
MapCache.prototype["delete"] = mapCacheDelete;
MapCache.prototype.get = mapCacheGet;
MapCache.prototype.has = mapCacheHas;
MapCache.prototype.set = mapCacheSet;
function assocIndexOf(array, key) {
  var length = array.length;
  while (length--) {
    if (eq(array[length][0], key)) {
      return length;
    }
  }
  return -1;
}
function baseGet(object, path) {
  path = isKey(path, object) ? [path] : castPath(path);
  var index = 0, length = path.length;
  while (object != null && index < length) {
    object = object[toKey(path[index++])];
  }
  return index && index == length ? object : void 0;
}
function baseIsNative(value) {
  if (!isObject(value) || isMasked(value)) {
    return false;
  }
  var pattern = isFunction(value) || isHostObject(value) ? reIsNative : reIsHostCtor;
  return pattern.test(toSource(value));
}
function baseToString(value) {
  if (typeof value == "string") {
    return value;
  }
  if (isSymbol(value)) {
    return symbolToString ? symbolToString.call(value) : "";
  }
  var result = value + "";
  return result == "0" && 1 / value == -INFINITY ? "-0" : result;
}
function castPath(value) {
  return isArray(value) ? value : stringToPath(value);
}
function getMapData(map, key) {
  var data = map.__data__;
  return isKeyable(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
}
function getNative(object, key) {
  var value = getValue(object, key);
  return baseIsNative(value) ? value : void 0;
}
function isKey(value, object) {
  if (isArray(value)) {
    return false;
  }
  var type = typeof value;
  if (type == "number" || type == "symbol" || type == "boolean" || value == null || isSymbol(value)) {
    return true;
  }
  return reIsPlainProp.test(value) || !reIsDeepProp.test(value) || object != null && value in Object(object);
}
function isKeyable(value) {
  var type = typeof value;
  return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
}
function isMasked(func) {
  return !!maskSrcKey && maskSrcKey in func;
}
var stringToPath = memoize(function(string) {
  string = toString(string);
  var result = [];
  if (reLeadingDot.test(string)) {
    result.push("");
  }
  string.replace(rePropName, function(match, number, quote, string2) {
    result.push(quote ? string2.replace(reEscapeChar, "$1") : number || match);
  });
  return result;
});
function toKey(value) {
  if (typeof value == "string" || isSymbol(value)) {
    return value;
  }
  var result = value + "";
  return result == "0" && 1 / value == -INFINITY ? "-0" : result;
}
function toSource(func) {
  if (func != null) {
    try {
      return funcToString.call(func);
    } catch (e) {
    }
    try {
      return func + "";
    } catch (e) {
    }
  }
  return "";
}
function memoize(func, resolver) {
  if (typeof func != "function" || resolver && typeof resolver != "function") {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  var memoized = function() {
    var args = arguments, key = resolver ? resolver.apply(this, args) : args[0], cache = memoized.cache;
    if (cache.has(key)) {
      return cache.get(key);
    }
    var result = func.apply(this, args);
    memoized.cache = cache.set(key, result);
    return result;
  };
  memoized.cache = new (memoize.Cache || MapCache)();
  return memoized;
}
memoize.Cache = MapCache;
function eq(value, other) {
  return value === other || value !== value && other !== other;
}
var isArray = Array.isArray;
function isFunction(value) {
  var tag = isObject(value) ? objectToString.call(value) : "";
  return tag == funcTag || tag == genTag;
}
function isObject(value) {
  var type = typeof value;
  return !!value && (type == "object" || type == "function");
}
function isObjectLike(value) {
  return !!value && typeof value == "object";
}
function isSymbol(value) {
  return typeof value == "symbol" || isObjectLike(value) && objectToString.call(value) == symbolTag;
}
function toString(value) {
  return value == null ? "" : baseToString(value);
}
function get(object, path, defaultValue) {
  var result = object == null ? void 0 : baseGet(object, path);
  return result === void 0 ? defaultValue : result;
}
module.exports = get;


/***/ }),

/***/ "./node_modules/xmldom/lib/dom-parser.js":
/*!***********************************************!*\
  !*** ./node_modules/xmldom/lib/dom-parser.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

function DOMParser(options) {
  this.options = options || { locator: {} };
}
DOMParser.prototype.parseFromString = function(source, mimeType) {
  var options = this.options;
  var sax2 = new XMLReader();
  var domBuilder = options.domBuilder || new DOMHandler();
  var errorHandler = options.errorHandler;
  var locator = options.locator;
  var defaultNSMap = options.xmlns || {};
  var isHTML = /\/x?html?$/.test(mimeType);
  var entityMap = isHTML ? htmlEntity.entityMap : { "lt": "<", "gt": ">", "amp": "&", "quot": '"', "apos": "'" };
  if (locator) {
    domBuilder.setDocumentLocator(locator);
  }
  sax2.errorHandler = buildErrorHandler(errorHandler, domBuilder, locator);
  sax2.domBuilder = options.domBuilder || domBuilder;
  if (isHTML) {
    defaultNSMap[""] = "http://www.w3.org/1999/xhtml";
  }
  defaultNSMap.xml = defaultNSMap.xml || "http://www.w3.org/XML/1998/namespace";
  if (source && typeof source === "string") {
    sax2.parse(source, defaultNSMap, entityMap);
  } else {
    sax2.errorHandler.error("invalid doc source");
  }
  return domBuilder.doc;
};
function buildErrorHandler(errorImpl, domBuilder, locator) {
  if (!errorImpl) {
    if (domBuilder instanceof DOMHandler) {
      return domBuilder;
    }
    errorImpl = domBuilder;
  }
  var errorHandler = {};
  var isCallback = errorImpl instanceof Function;
  locator = locator || {};
  function build(key) {
    var fn = errorImpl[key];
    if (!fn && isCallback) {
      fn = errorImpl.length == 2 ? function(msg) {
        errorImpl(key, msg);
      } : errorImpl;
    }
    errorHandler[key] = fn && function(msg) {
      fn("[xmldom " + key + "]	" + msg + _locator(locator));
    } || function() {
    };
  }
  build("warning");
  build("error");
  build("fatalError");
  return errorHandler;
}
function DOMHandler() {
  this.cdata = false;
}
function position(locator, node) {
  node.lineNumber = locator.lineNumber;
  node.columnNumber = locator.columnNumber;
}
DOMHandler.prototype = {
  startDocument: function() {
    this.doc = new DOMImplementation().createDocument(null, null, null);
    if (this.locator) {
      this.doc.documentURI = this.locator.systemId;
    }
  },
  startElement: function(namespaceURI, localName, qName, attrs) {
    var doc = this.doc;
    var el = doc.createElementNS(namespaceURI, qName || localName);
    var len = attrs.length;
    appendElement(this, el);
    this.currentElement = el;
    this.locator && position(this.locator, el);
    for (var i = 0; i < len; i++) {
      var namespaceURI = attrs.getURI(i);
      var value = attrs.getValue(i);
      var qName = attrs.getQName(i);
      var attr = doc.createAttributeNS(namespaceURI, qName);
      this.locator && position(attrs.getLocator(i), attr);
      attr.value = attr.nodeValue = value;
      el.setAttributeNode(attr);
    }
  },
  endElement: function(namespaceURI, localName, qName) {
    var current = this.currentElement;
    var tagName = current.tagName;
    this.currentElement = current.parentNode;
  },
  startPrefixMapping: function(prefix, uri) {
  },
  endPrefixMapping: function(prefix) {
  },
  processingInstruction: function(target, data) {
    var ins = this.doc.createProcessingInstruction(target, data);
    this.locator && position(this.locator, ins);
    appendElement(this, ins);
  },
  ignorableWhitespace: function(ch, start, length) {
  },
  characters: function(chars, start, length) {
    chars = _toString.apply(this, arguments);
    if (chars) {
      if (this.cdata) {
        var charNode = this.doc.createCDATASection(chars);
      } else {
        var charNode = this.doc.createTextNode(chars);
      }
      if (this.currentElement) {
        this.currentElement.appendChild(charNode);
      } else if (/^\s*$/.test(chars)) {
        this.doc.appendChild(charNode);
      }
      this.locator && position(this.locator, charNode);
    }
  },
  skippedEntity: function(name) {
  },
  endDocument: function() {
    this.doc.normalize();
  },
  setDocumentLocator: function(locator) {
    if (this.locator = locator) {
      locator.lineNumber = 0;
    }
  },
  comment: function(chars, start, length) {
    chars = _toString.apply(this, arguments);
    var comm = this.doc.createComment(chars);
    this.locator && position(this.locator, comm);
    appendElement(this, comm);
  },
  startCDATA: function() {
    this.cdata = true;
  },
  endCDATA: function() {
    this.cdata = false;
  },
  startDTD: function(name, publicId, systemId) {
    var impl = this.doc.implementation;
    if (impl && impl.createDocumentType) {
      var dt = impl.createDocumentType(name, publicId, systemId);
      this.locator && position(this.locator, dt);
      appendElement(this, dt);
    }
  },
  warning: function(error) {
    console.warn("[xmldom warning]	" + error, _locator(this.locator));
  },
  error: function(error) {
    console.error("[xmldom error]	" + error, _locator(this.locator));
  },
  fatalError: function(error) {
    throw new ParseError(error, this.locator);
  }
};
function _locator(l) {
  if (l) {
    return "\n@" + (l.systemId || "") + "#[line:" + l.lineNumber + ",col:" + l.columnNumber + "]";
  }
}
function _toString(chars, start, length) {
  if (typeof chars == "string") {
    return chars.substr(start, length);
  } else {
    if (chars.length >= start + length || start) {
      return new java.lang.String(chars, start, length) + "";
    }
    return chars;
  }
}
"endDTD,startEntity,endEntity,attributeDecl,elementDecl,externalEntityDecl,internalEntityDecl,resolveEntity,getExternalSubset,notationDecl,unparsedEntityDecl".replace(/\w+/g, function(key) {
  DOMHandler.prototype[key] = function() {
    return null;
  };
});
function appendElement(hander, node) {
  if (!hander.currentElement) {
    hander.doc.appendChild(node);
  } else {
    hander.currentElement.appendChild(node);
  }
}
var htmlEntity = __webpack_require__(/*! ./entities */ "./node_modules/xmldom/lib/entities.js");
var sax = __webpack_require__(/*! ./sax */ "./node_modules/xmldom/lib/sax.js");
var XMLReader = sax.XMLReader;
var ParseError = sax.ParseError;
var DOMImplementation = exports.DOMImplementation = __webpack_require__(/*! ./dom */ "./node_modules/xmldom/lib/dom.js").DOMImplementation;
exports.XMLSerializer = __webpack_require__(/*! ./dom */ "./node_modules/xmldom/lib/dom.js").XMLSerializer;
exports.DOMParser = DOMParser;
exports.__DOMHandler = DOMHandler;


/***/ }),

/***/ "./node_modules/xmldom/lib/dom.js":
/*!****************************************!*\
  !*** ./node_modules/xmldom/lib/dom.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, exports) => {

function copy(src, dest) {
  for (var p in src) {
    dest[p] = src[p];
  }
}
function _extends(Class, Super) {
  var pt = Class.prototype;
  if (!(pt instanceof Super)) {
    let t2 = function() {
    };
    var t = t2;
    ;
    t2.prototype = Super.prototype;
    t2 = new t2();
    copy(pt, t2);
    Class.prototype = pt = t2;
  }
  if (pt.constructor != Class) {
    if (typeof Class != "function") {
      console.error("unknow Class:" + Class);
    }
    pt.constructor = Class;
  }
}
var htmlns = "http://www.w3.org/1999/xhtml";
var NodeType = {};
var ELEMENT_NODE = NodeType.ELEMENT_NODE = 1;
var ATTRIBUTE_NODE = NodeType.ATTRIBUTE_NODE = 2;
var TEXT_NODE = NodeType.TEXT_NODE = 3;
var CDATA_SECTION_NODE = NodeType.CDATA_SECTION_NODE = 4;
var ENTITY_REFERENCE_NODE = NodeType.ENTITY_REFERENCE_NODE = 5;
var ENTITY_NODE = NodeType.ENTITY_NODE = 6;
var PROCESSING_INSTRUCTION_NODE = NodeType.PROCESSING_INSTRUCTION_NODE = 7;
var COMMENT_NODE = NodeType.COMMENT_NODE = 8;
var DOCUMENT_NODE = NodeType.DOCUMENT_NODE = 9;
var DOCUMENT_TYPE_NODE = NodeType.DOCUMENT_TYPE_NODE = 10;
var DOCUMENT_FRAGMENT_NODE = NodeType.DOCUMENT_FRAGMENT_NODE = 11;
var NOTATION_NODE = NodeType.NOTATION_NODE = 12;
var ExceptionCode = {};
var ExceptionMessage = {};
var INDEX_SIZE_ERR = ExceptionCode.INDEX_SIZE_ERR = (ExceptionMessage[1] = "Index size error", 1);
var DOMSTRING_SIZE_ERR = ExceptionCode.DOMSTRING_SIZE_ERR = (ExceptionMessage[2] = "DOMString size error", 2);
var HIERARCHY_REQUEST_ERR = ExceptionCode.HIERARCHY_REQUEST_ERR = (ExceptionMessage[3] = "Hierarchy request error", 3);
var WRONG_DOCUMENT_ERR = ExceptionCode.WRONG_DOCUMENT_ERR = (ExceptionMessage[4] = "Wrong document", 4);
var INVALID_CHARACTER_ERR = ExceptionCode.INVALID_CHARACTER_ERR = (ExceptionMessage[5] = "Invalid character", 5);
var NO_DATA_ALLOWED_ERR = ExceptionCode.NO_DATA_ALLOWED_ERR = (ExceptionMessage[6] = "No data allowed", 6);
var NO_MODIFICATION_ALLOWED_ERR = ExceptionCode.NO_MODIFICATION_ALLOWED_ERR = (ExceptionMessage[7] = "No modification allowed", 7);
var NOT_FOUND_ERR = ExceptionCode.NOT_FOUND_ERR = (ExceptionMessage[8] = "Not found", 8);
var NOT_SUPPORTED_ERR = ExceptionCode.NOT_SUPPORTED_ERR = (ExceptionMessage[9] = "Not supported", 9);
var INUSE_ATTRIBUTE_ERR = ExceptionCode.INUSE_ATTRIBUTE_ERR = (ExceptionMessage[10] = "Attribute in use", 10);
var INVALID_STATE_ERR = ExceptionCode.INVALID_STATE_ERR = (ExceptionMessage[11] = "Invalid state", 11);
var SYNTAX_ERR = ExceptionCode.SYNTAX_ERR = (ExceptionMessage[12] = "Syntax error", 12);
var INVALID_MODIFICATION_ERR = ExceptionCode.INVALID_MODIFICATION_ERR = (ExceptionMessage[13] = "Invalid modification", 13);
var NAMESPACE_ERR = ExceptionCode.NAMESPACE_ERR = (ExceptionMessage[14] = "Invalid namespace", 14);
var INVALID_ACCESS_ERR = ExceptionCode.INVALID_ACCESS_ERR = (ExceptionMessage[15] = "Invalid access", 15);
function DOMException(code, message) {
  if (message instanceof Error) {
    var error = message;
  } else {
    error = this;
    Error.call(this, ExceptionMessage[code]);
    this.message = ExceptionMessage[code];
    if (Error.captureStackTrace)
      Error.captureStackTrace(this, DOMException);
  }
  error.code = code;
  if (message)
    this.message = this.message + ": " + message;
  return error;
}
;
DOMException.prototype = Error.prototype;
copy(ExceptionCode, DOMException);
function NodeList() {
}
;
NodeList.prototype = {
  length: 0,
  item: function(index) {
    return this[index] || null;
  },
  toString: function(isHTML, nodeFilter) {
    for (var buf = [], i = 0; i < this.length; i++) {
      serializeToString(this[i], buf, isHTML, nodeFilter);
    }
    return buf.join("");
  }
};
function LiveNodeList(node, refresh) {
  this._node = node;
  this._refresh = refresh;
  _updateLiveList(this);
}
function _updateLiveList(list) {
  var inc = list._node._inc || list._node.ownerDocument._inc;
  if (list._inc != inc) {
    var ls = list._refresh(list._node);
    __set__(list, "length", ls.length);
    copy(ls, list);
    list._inc = inc;
  }
}
LiveNodeList.prototype.item = function(i) {
  _updateLiveList(this);
  return this[i];
};
_extends(LiveNodeList, NodeList);
function NamedNodeMap() {
}
;
function _findNodeIndex(list, node) {
  var i = list.length;
  while (i--) {
    if (list[i] === node) {
      return i;
    }
  }
}
function _addNamedNode(el, list, newAttr, oldAttr) {
  if (oldAttr) {
    list[_findNodeIndex(list, oldAttr)] = newAttr;
  } else {
    list[list.length++] = newAttr;
  }
  if (el) {
    newAttr.ownerElement = el;
    var doc = el.ownerDocument;
    if (doc) {
      oldAttr && _onRemoveAttribute(doc, el, oldAttr);
      _onAddAttribute(doc, el, newAttr);
    }
  }
}
function _removeNamedNode(el, list, attr) {
  var i = _findNodeIndex(list, attr);
  if (i >= 0) {
    var lastIndex = list.length - 1;
    while (i < lastIndex) {
      list[i] = list[++i];
    }
    list.length = lastIndex;
    if (el) {
      var doc = el.ownerDocument;
      if (doc) {
        _onRemoveAttribute(doc, el, attr);
        attr.ownerElement = null;
      }
    }
  } else {
    throw DOMException(NOT_FOUND_ERR, new Error(el.tagName + "@" + attr));
  }
}
NamedNodeMap.prototype = {
  length: 0,
  item: NodeList.prototype.item,
  getNamedItem: function(key) {
    var i = this.length;
    while (i--) {
      var attr = this[i];
      if (attr.nodeName == key) {
        return attr;
      }
    }
  },
  setNamedItem: function(attr) {
    var el = attr.ownerElement;
    if (el && el != this._ownerElement) {
      throw new DOMException(INUSE_ATTRIBUTE_ERR);
    }
    var oldAttr = this.getNamedItem(attr.nodeName);
    _addNamedNode(this._ownerElement, this, attr, oldAttr);
    return oldAttr;
  },
  setNamedItemNS: function(attr) {
    var el = attr.ownerElement, oldAttr;
    if (el && el != this._ownerElement) {
      throw new DOMException(INUSE_ATTRIBUTE_ERR);
    }
    oldAttr = this.getNamedItemNS(attr.namespaceURI, attr.localName);
    _addNamedNode(this._ownerElement, this, attr, oldAttr);
    return oldAttr;
  },
  removeNamedItem: function(key) {
    var attr = this.getNamedItem(key);
    _removeNamedNode(this._ownerElement, this, attr);
    return attr;
  },
  removeNamedItemNS: function(namespaceURI, localName) {
    var attr = this.getNamedItemNS(namespaceURI, localName);
    _removeNamedNode(this._ownerElement, this, attr);
    return attr;
  },
  getNamedItemNS: function(namespaceURI, localName) {
    var i = this.length;
    while (i--) {
      var node = this[i];
      if (node.localName == localName && node.namespaceURI == namespaceURI) {
        return node;
      }
    }
    return null;
  }
};
function DOMImplementation(features) {
  this._features = {};
  if (features) {
    for (var feature in features) {
      this._features = features[feature];
    }
  }
}
;
DOMImplementation.prototype = {
  hasFeature: function(feature, version) {
    var versions = this._features[feature.toLowerCase()];
    if (versions && (!version || version in versions)) {
      return true;
    } else {
      return false;
    }
  },
  createDocument: function(namespaceURI, qualifiedName, doctype) {
    var doc = new Document();
    doc.implementation = this;
    doc.childNodes = new NodeList();
    doc.doctype = doctype;
    if (doctype) {
      doc.appendChild(doctype);
    }
    if (qualifiedName) {
      var root = doc.createElementNS(namespaceURI, qualifiedName);
      doc.appendChild(root);
    }
    return doc;
  },
  createDocumentType: function(qualifiedName, publicId, systemId) {
    var node = new DocumentType();
    node.name = qualifiedName;
    node.nodeName = qualifiedName;
    node.publicId = publicId;
    node.systemId = systemId;
    return node;
  }
};
function Node() {
}
;
Node.prototype = {
  firstChild: null,
  lastChild: null,
  previousSibling: null,
  nextSibling: null,
  attributes: null,
  parentNode: null,
  childNodes: null,
  ownerDocument: null,
  nodeValue: null,
  namespaceURI: null,
  prefix: null,
  localName: null,
  insertBefore: function(newChild, refChild) {
    return _insertBefore(this, newChild, refChild);
  },
  replaceChild: function(newChild, oldChild) {
    this.insertBefore(newChild, oldChild);
    if (oldChild) {
      this.removeChild(oldChild);
    }
  },
  removeChild: function(oldChild) {
    return _removeChild(this, oldChild);
  },
  appendChild: function(newChild) {
    return this.insertBefore(newChild, null);
  },
  hasChildNodes: function() {
    return this.firstChild != null;
  },
  cloneNode: function(deep) {
    return cloneNode(this.ownerDocument || this, this, deep);
  },
  normalize: function() {
    var child = this.firstChild;
    while (child) {
      var next = child.nextSibling;
      if (next && next.nodeType == TEXT_NODE && child.nodeType == TEXT_NODE) {
        this.removeChild(next);
        child.appendData(next.data);
      } else {
        child.normalize();
        child = next;
      }
    }
  },
  isSupported: function(feature, version) {
    return this.ownerDocument.implementation.hasFeature(feature, version);
  },
  hasAttributes: function() {
    return this.attributes.length > 0;
  },
  lookupPrefix: function(namespaceURI) {
    var el = this;
    while (el) {
      var map = el._nsMap;
      if (map) {
        for (var n in map) {
          if (map[n] == namespaceURI) {
            return n;
          }
        }
      }
      el = el.nodeType == ATTRIBUTE_NODE ? el.ownerDocument : el.parentNode;
    }
    return null;
  },
  lookupNamespaceURI: function(prefix) {
    var el = this;
    while (el) {
      var map = el._nsMap;
      if (map) {
        if (prefix in map) {
          return map[prefix];
        }
      }
      el = el.nodeType == ATTRIBUTE_NODE ? el.ownerDocument : el.parentNode;
    }
    return null;
  },
  isDefaultNamespace: function(namespaceURI) {
    var prefix = this.lookupPrefix(namespaceURI);
    return prefix == null;
  }
};
function _xmlEncoder(c) {
  return c == "<" && "&lt;" || c == ">" && "&gt;" || c == "&" && "&amp;" || c == '"' && "&quot;" || "&#" + c.charCodeAt() + ";";
}
copy(NodeType, Node);
copy(NodeType, Node.prototype);
function _visitNode(node, callback) {
  if (callback(node)) {
    return true;
  }
  if (node = node.firstChild) {
    do {
      if (_visitNode(node, callback)) {
        return true;
      }
    } while (node = node.nextSibling);
  }
}
function Document() {
}
function _onAddAttribute(doc, el, newAttr) {
  doc && doc._inc++;
  var ns = newAttr.namespaceURI;
  if (ns == "http://www.w3.org/2000/xmlns/") {
    el._nsMap[newAttr.prefix ? newAttr.localName : ""] = newAttr.value;
  }
}
function _onRemoveAttribute(doc, el, newAttr, remove) {
  doc && doc._inc++;
  var ns = newAttr.namespaceURI;
  if (ns == "http://www.w3.org/2000/xmlns/") {
    delete el._nsMap[newAttr.prefix ? newAttr.localName : ""];
  }
}
function _onUpdateChild(doc, el, newChild) {
  if (doc && doc._inc) {
    doc._inc++;
    var cs = el.childNodes;
    if (newChild) {
      cs[cs.length++] = newChild;
    } else {
      var child = el.firstChild;
      var i = 0;
      while (child) {
        cs[i++] = child;
        child = child.nextSibling;
      }
      cs.length = i;
    }
  }
}
function _removeChild(parentNode, child) {
  var previous = child.previousSibling;
  var next = child.nextSibling;
  if (previous) {
    previous.nextSibling = next;
  } else {
    parentNode.firstChild = next;
  }
  if (next) {
    next.previousSibling = previous;
  } else {
    parentNode.lastChild = previous;
  }
  _onUpdateChild(parentNode.ownerDocument, parentNode);
  return child;
}
function _insertBefore(parentNode, newChild, nextChild) {
  var cp = newChild.parentNode;
  if (cp) {
    cp.removeChild(newChild);
  }
  if (newChild.nodeType === DOCUMENT_FRAGMENT_NODE) {
    var newFirst = newChild.firstChild;
    if (newFirst == null) {
      return newChild;
    }
    var newLast = newChild.lastChild;
  } else {
    newFirst = newLast = newChild;
  }
  var pre = nextChild ? nextChild.previousSibling : parentNode.lastChild;
  newFirst.previousSibling = pre;
  newLast.nextSibling = nextChild;
  if (pre) {
    pre.nextSibling = newFirst;
  } else {
    parentNode.firstChild = newFirst;
  }
  if (nextChild == null) {
    parentNode.lastChild = newLast;
  } else {
    nextChild.previousSibling = newLast;
  }
  do {
    newFirst.parentNode = parentNode;
  } while (newFirst !== newLast && (newFirst = newFirst.nextSibling));
  _onUpdateChild(parentNode.ownerDocument || parentNode, parentNode);
  if (newChild.nodeType == DOCUMENT_FRAGMENT_NODE) {
    newChild.firstChild = newChild.lastChild = null;
  }
  return newChild;
}
function _appendSingleChild(parentNode, newChild) {
  var cp = newChild.parentNode;
  if (cp) {
    var pre = parentNode.lastChild;
    cp.removeChild(newChild);
    var pre = parentNode.lastChild;
  }
  var pre = parentNode.lastChild;
  newChild.parentNode = parentNode;
  newChild.previousSibling = pre;
  newChild.nextSibling = null;
  if (pre) {
    pre.nextSibling = newChild;
  } else {
    parentNode.firstChild = newChild;
  }
  parentNode.lastChild = newChild;
  _onUpdateChild(parentNode.ownerDocument, parentNode, newChild);
  return newChild;
}
Document.prototype = {
  nodeName: "#document",
  nodeType: DOCUMENT_NODE,
  doctype: null,
  documentElement: null,
  _inc: 1,
  insertBefore: function(newChild, refChild) {
    if (newChild.nodeType == DOCUMENT_FRAGMENT_NODE) {
      var child = newChild.firstChild;
      while (child) {
        var next = child.nextSibling;
        this.insertBefore(child, refChild);
        child = next;
      }
      return newChild;
    }
    if (this.documentElement == null && newChild.nodeType == ELEMENT_NODE) {
      this.documentElement = newChild;
    }
    return _insertBefore(this, newChild, refChild), newChild.ownerDocument = this, newChild;
  },
  removeChild: function(oldChild) {
    if (this.documentElement == oldChild) {
      this.documentElement = null;
    }
    return _removeChild(this, oldChild);
  },
  importNode: function(importedNode, deep) {
    return importNode(this, importedNode, deep);
  },
  getElementById: function(id) {
    var rtv = null;
    _visitNode(this.documentElement, function(node) {
      if (node.nodeType == ELEMENT_NODE) {
        if (node.getAttribute("id") == id) {
          rtv = node;
          return true;
        }
      }
    });
    return rtv;
  },
  getElementsByClassName: function(className) {
    var pattern = new RegExp("(^|\\s)" + className + "(\\s|$)");
    return new LiveNodeList(this, function(base) {
      var ls = [];
      _visitNode(base.documentElement, function(node) {
        if (node !== base && node.nodeType == ELEMENT_NODE) {
          if (pattern.test(node.getAttribute("class"))) {
            ls.push(node);
          }
        }
      });
      return ls;
    });
  },
  createElement: function(tagName) {
    var node = new Element();
    node.ownerDocument = this;
    node.nodeName = tagName;
    node.tagName = tagName;
    node.childNodes = new NodeList();
    var attrs = node.attributes = new NamedNodeMap();
    attrs._ownerElement = node;
    return node;
  },
  createDocumentFragment: function() {
    var node = new DocumentFragment();
    node.ownerDocument = this;
    node.childNodes = new NodeList();
    return node;
  },
  createTextNode: function(data) {
    var node = new Text();
    node.ownerDocument = this;
    node.appendData(data);
    return node;
  },
  createComment: function(data) {
    var node = new Comment();
    node.ownerDocument = this;
    node.appendData(data);
    return node;
  },
  createCDATASection: function(data) {
    var node = new CDATASection();
    node.ownerDocument = this;
    node.appendData(data);
    return node;
  },
  createProcessingInstruction: function(target, data) {
    var node = new ProcessingInstruction();
    node.ownerDocument = this;
    node.tagName = node.target = target;
    node.nodeValue = node.data = data;
    return node;
  },
  createAttribute: function(name) {
    var node = new Attr();
    node.ownerDocument = this;
    node.name = name;
    node.nodeName = name;
    node.localName = name;
    node.specified = true;
    return node;
  },
  createEntityReference: function(name) {
    var node = new EntityReference();
    node.ownerDocument = this;
    node.nodeName = name;
    return node;
  },
  createElementNS: function(namespaceURI, qualifiedName) {
    var node = new Element();
    var pl = qualifiedName.split(":");
    var attrs = node.attributes = new NamedNodeMap();
    node.childNodes = new NodeList();
    node.ownerDocument = this;
    node.nodeName = qualifiedName;
    node.tagName = qualifiedName;
    node.namespaceURI = namespaceURI;
    if (pl.length == 2) {
      node.prefix = pl[0];
      node.localName = pl[1];
    } else {
      node.localName = qualifiedName;
    }
    attrs._ownerElement = node;
    return node;
  },
  createAttributeNS: function(namespaceURI, qualifiedName) {
    var node = new Attr();
    var pl = qualifiedName.split(":");
    node.ownerDocument = this;
    node.nodeName = qualifiedName;
    node.name = qualifiedName;
    node.namespaceURI = namespaceURI;
    node.specified = true;
    if (pl.length == 2) {
      node.prefix = pl[0];
      node.localName = pl[1];
    } else {
      node.localName = qualifiedName;
    }
    return node;
  }
};
_extends(Document, Node);
function Element() {
  this._nsMap = {};
}
;
Element.prototype = {
  nodeType: ELEMENT_NODE,
  hasAttribute: function(name) {
    return this.getAttributeNode(name) != null;
  },
  getAttribute: function(name) {
    var attr = this.getAttributeNode(name);
    return attr && attr.value || "";
  },
  getAttributeNode: function(name) {
    return this.attributes.getNamedItem(name);
  },
  setAttribute: function(name, value) {
    var attr = this.ownerDocument.createAttribute(name);
    attr.value = attr.nodeValue = "" + value;
    this.setAttributeNode(attr);
  },
  removeAttribute: function(name) {
    var attr = this.getAttributeNode(name);
    attr && this.removeAttributeNode(attr);
  },
  appendChild: function(newChild) {
    if (newChild.nodeType === DOCUMENT_FRAGMENT_NODE) {
      return this.insertBefore(newChild, null);
    } else {
      return _appendSingleChild(this, newChild);
    }
  },
  setAttributeNode: function(newAttr) {
    return this.attributes.setNamedItem(newAttr);
  },
  setAttributeNodeNS: function(newAttr) {
    return this.attributes.setNamedItemNS(newAttr);
  },
  removeAttributeNode: function(oldAttr) {
    return this.attributes.removeNamedItem(oldAttr.nodeName);
  },
  removeAttributeNS: function(namespaceURI, localName) {
    var old = this.getAttributeNodeNS(namespaceURI, localName);
    old && this.removeAttributeNode(old);
  },
  hasAttributeNS: function(namespaceURI, localName) {
    return this.getAttributeNodeNS(namespaceURI, localName) != null;
  },
  getAttributeNS: function(namespaceURI, localName) {
    var attr = this.getAttributeNodeNS(namespaceURI, localName);
    return attr && attr.value || "";
  },
  setAttributeNS: function(namespaceURI, qualifiedName, value) {
    var attr = this.ownerDocument.createAttributeNS(namespaceURI, qualifiedName);
    attr.value = attr.nodeValue = "" + value;
    this.setAttributeNode(attr);
  },
  getAttributeNodeNS: function(namespaceURI, localName) {
    return this.attributes.getNamedItemNS(namespaceURI, localName);
  },
  getElementsByTagName: function(tagName) {
    return new LiveNodeList(this, function(base) {
      var ls = [];
      _visitNode(base, function(node) {
        if (node !== base && node.nodeType == ELEMENT_NODE && (tagName === "*" || node.tagName == tagName)) {
          ls.push(node);
        }
      });
      return ls;
    });
  },
  getElementsByTagNameNS: function(namespaceURI, localName) {
    return new LiveNodeList(this, function(base) {
      var ls = [];
      _visitNode(base, function(node) {
        if (node !== base && node.nodeType === ELEMENT_NODE && (namespaceURI === "*" || node.namespaceURI === namespaceURI) && (localName === "*" || node.localName == localName)) {
          ls.push(node);
        }
      });
      return ls;
    });
  }
};
Document.prototype.getElementsByTagName = Element.prototype.getElementsByTagName;
Document.prototype.getElementsByTagNameNS = Element.prototype.getElementsByTagNameNS;
_extends(Element, Node);
function Attr() {
}
;
Attr.prototype.nodeType = ATTRIBUTE_NODE;
_extends(Attr, Node);
function CharacterData() {
}
;
CharacterData.prototype = {
  data: "",
  substringData: function(offset, count) {
    return this.data.substring(offset, offset + count);
  },
  appendData: function(text) {
    text = this.data + text;
    this.nodeValue = this.data = text;
    this.length = text.length;
  },
  insertData: function(offset, text) {
    this.replaceData(offset, 0, text);
  },
  appendChild: function(newChild) {
    throw new Error(ExceptionMessage[HIERARCHY_REQUEST_ERR]);
  },
  deleteData: function(offset, count) {
    this.replaceData(offset, count, "");
  },
  replaceData: function(offset, count, text) {
    var start = this.data.substring(0, offset);
    var end = this.data.substring(offset + count);
    text = start + text + end;
    this.nodeValue = this.data = text;
    this.length = text.length;
  }
};
_extends(CharacterData, Node);
function Text() {
}
;
Text.prototype = {
  nodeName: "#text",
  nodeType: TEXT_NODE,
  splitText: function(offset) {
    var text = this.data;
    var newText = text.substring(offset);
    text = text.substring(0, offset);
    this.data = this.nodeValue = text;
    this.length = text.length;
    var newNode = this.ownerDocument.createTextNode(newText);
    if (this.parentNode) {
      this.parentNode.insertBefore(newNode, this.nextSibling);
    }
    return newNode;
  }
};
_extends(Text, CharacterData);
function Comment() {
}
;
Comment.prototype = {
  nodeName: "#comment",
  nodeType: COMMENT_NODE
};
_extends(Comment, CharacterData);
function CDATASection() {
}
;
CDATASection.prototype = {
  nodeName: "#cdata-section",
  nodeType: CDATA_SECTION_NODE
};
_extends(CDATASection, CharacterData);
function DocumentType() {
}
;
DocumentType.prototype.nodeType = DOCUMENT_TYPE_NODE;
_extends(DocumentType, Node);
function Notation() {
}
;
Notation.prototype.nodeType = NOTATION_NODE;
_extends(Notation, Node);
function Entity() {
}
;
Entity.prototype.nodeType = ENTITY_NODE;
_extends(Entity, Node);
function EntityReference() {
}
;
EntityReference.prototype.nodeType = ENTITY_REFERENCE_NODE;
_extends(EntityReference, Node);
function DocumentFragment() {
}
;
DocumentFragment.prototype.nodeName = "#document-fragment";
DocumentFragment.prototype.nodeType = DOCUMENT_FRAGMENT_NODE;
_extends(DocumentFragment, Node);
function ProcessingInstruction() {
}
ProcessingInstruction.prototype.nodeType = PROCESSING_INSTRUCTION_NODE;
_extends(ProcessingInstruction, Node);
function XMLSerializer() {
}
XMLSerializer.prototype.serializeToString = function(node, isHtml, nodeFilter) {
  return nodeSerializeToString.call(node, isHtml, nodeFilter);
};
Node.prototype.toString = nodeSerializeToString;
function nodeSerializeToString(isHtml, nodeFilter) {
  var buf = [];
  var refNode = this.nodeType == 9 && this.documentElement || this;
  var prefix = refNode.prefix;
  var uri = refNode.namespaceURI;
  if (uri && prefix == null) {
    var prefix = refNode.lookupPrefix(uri);
    if (prefix == null) {
      var visibleNamespaces = [
        { namespace: uri, prefix: null }
      ];
    }
  }
  serializeToString(this, buf, isHtml, nodeFilter, visibleNamespaces);
  return buf.join("");
}
function needNamespaceDefine(node, isHTML, visibleNamespaces) {
  var prefix = node.prefix || "";
  var uri = node.namespaceURI;
  if (!prefix && !uri) {
    return false;
  }
  if (prefix === "xml" && uri === "http://www.w3.org/XML/1998/namespace" || uri == "http://www.w3.org/2000/xmlns/") {
    return false;
  }
  var i = visibleNamespaces.length;
  while (i--) {
    var ns = visibleNamespaces[i];
    if (ns.prefix == prefix) {
      return ns.namespace != uri;
    }
  }
  return true;
}
function serializeToString(node, buf, isHTML, nodeFilter, visibleNamespaces) {
  if (nodeFilter) {
    node = nodeFilter(node);
    if (node) {
      if (typeof node == "string") {
        buf.push(node);
        return;
      }
    } else {
      return;
    }
  }
  switch (node.nodeType) {
    case ELEMENT_NODE:
      if (!visibleNamespaces)
        visibleNamespaces = [];
      var startVisibleNamespaces = visibleNamespaces.length;
      var attrs = node.attributes;
      var len = attrs.length;
      var child = node.firstChild;
      var nodeName = node.tagName;
      isHTML = htmlns === node.namespaceURI || isHTML;
      buf.push("<", nodeName);
      for (var i = 0; i < len; i++) {
        var attr = attrs.item(i);
        if (attr.prefix == "xmlns") {
          visibleNamespaces.push({ prefix: attr.localName, namespace: attr.value });
        } else if (attr.nodeName == "xmlns") {
          visibleNamespaces.push({ prefix: "", namespace: attr.value });
        }
      }
      for (var i = 0; i < len; i++) {
        var attr = attrs.item(i);
        if (needNamespaceDefine(attr, isHTML, visibleNamespaces)) {
          var prefix = attr.prefix || "";
          var uri = attr.namespaceURI;
          var ns = prefix ? " xmlns:" + prefix : " xmlns";
          buf.push(ns, '="', uri, '"');
          visibleNamespaces.push({ prefix, namespace: uri });
        }
        serializeToString(attr, buf, isHTML, nodeFilter, visibleNamespaces);
      }
      if (needNamespaceDefine(node, isHTML, visibleNamespaces)) {
        var prefix = node.prefix || "";
        var uri = node.namespaceURI;
        if (uri) {
          var ns = prefix ? " xmlns:" + prefix : " xmlns";
          buf.push(ns, '="', uri, '"');
          visibleNamespaces.push({ prefix, namespace: uri });
        }
      }
      if (child || isHTML && !/^(?:meta|link|img|br|hr|input)$/i.test(nodeName)) {
        buf.push(">");
        if (isHTML && /^script$/i.test(nodeName)) {
          while (child) {
            if (child.data) {
              buf.push(child.data);
            } else {
              serializeToString(child, buf, isHTML, nodeFilter, visibleNamespaces);
            }
            child = child.nextSibling;
          }
        } else {
          while (child) {
            serializeToString(child, buf, isHTML, nodeFilter, visibleNamespaces);
            child = child.nextSibling;
          }
        }
        buf.push("</", nodeName, ">");
      } else {
        buf.push("/>");
      }
      return;
    case DOCUMENT_NODE:
    case DOCUMENT_FRAGMENT_NODE:
      var child = node.firstChild;
      while (child) {
        serializeToString(child, buf, isHTML, nodeFilter, visibleNamespaces);
        child = child.nextSibling;
      }
      return;
    case ATTRIBUTE_NODE:
      return buf.push(" ", node.name, '="', node.value.replace(/[<&"]/g, _xmlEncoder), '"');
    case TEXT_NODE:
      return buf.push(
        node.data.replace(/[<&]/g, _xmlEncoder).replace(/]]>/g, "]]&gt;")
      );
    case CDATA_SECTION_NODE:
      return buf.push("<![CDATA[", node.data, "]]>");
    case COMMENT_NODE:
      return buf.push("<!--", node.data, "-->");
    case DOCUMENT_TYPE_NODE:
      var pubid = node.publicId;
      var sysid = node.systemId;
      buf.push("<!DOCTYPE ", node.name);
      if (pubid) {
        buf.push(" PUBLIC ", pubid);
        if (sysid && sysid != ".") {
          buf.push(" ", sysid);
        }
        buf.push(">");
      } else if (sysid && sysid != ".") {
        buf.push(" SYSTEM ", sysid, ">");
      } else {
        var sub = node.internalSubset;
        if (sub) {
          buf.push(" [", sub, "]");
        }
        buf.push(">");
      }
      return;
    case PROCESSING_INSTRUCTION_NODE:
      return buf.push("<?", node.target, " ", node.data, "?>");
    case ENTITY_REFERENCE_NODE:
      return buf.push("&", node.nodeName, ";");
    default:
      buf.push("??", node.nodeName);
  }
}
function importNode(doc, node, deep) {
  var node2;
  switch (node.nodeType) {
    case ELEMENT_NODE:
      node2 = node.cloneNode(false);
      node2.ownerDocument = doc;
    case DOCUMENT_FRAGMENT_NODE:
      break;
    case ATTRIBUTE_NODE:
      deep = true;
      break;
  }
  if (!node2) {
    node2 = node.cloneNode(false);
  }
  node2.ownerDocument = doc;
  node2.parentNode = null;
  if (deep) {
    var child = node.firstChild;
    while (child) {
      node2.appendChild(importNode(doc, child, deep));
      child = child.nextSibling;
    }
  }
  return node2;
}
function cloneNode(doc, node, deep) {
  var node2 = new node.constructor();
  for (var n in node) {
    var v = node[n];
    if (typeof v != "object") {
      if (v != node2[n]) {
        node2[n] = v;
      }
    }
  }
  if (node.childNodes) {
    node2.childNodes = new NodeList();
  }
  node2.ownerDocument = doc;
  switch (node2.nodeType) {
    case ELEMENT_NODE:
      var attrs = node.attributes;
      var attrs2 = node2.attributes = new NamedNodeMap();
      var len = attrs.length;
      attrs2._ownerElement = node2;
      for (var i = 0; i < len; i++) {
        node2.setAttributeNode(cloneNode(doc, attrs.item(i), true));
      }
      break;
      ;
    case ATTRIBUTE_NODE:
      deep = true;
  }
  if (deep) {
    var child = node.firstChild;
    while (child) {
      node2.appendChild(cloneNode(doc, child, deep));
      child = child.nextSibling;
    }
  }
  return node2;
}
function __set__(object, key, value) {
  object[key] = value;
}
try {
  if (Object.defineProperty) {
    let getTextContent2 = function(node) {
      switch (node.nodeType) {
        case ELEMENT_NODE:
        case DOCUMENT_FRAGMENT_NODE:
          var buf = [];
          node = node.firstChild;
          while (node) {
            if (node.nodeType !== 7 && node.nodeType !== 8) {
              buf.push(getTextContent2(node));
            }
            node = node.nextSibling;
          }
          return buf.join("");
        default:
          return node.nodeValue;
      }
    };
    var getTextContent = getTextContent2;
    Object.defineProperty(LiveNodeList.prototype, "length", {
      get: function() {
        _updateLiveList(this);
        return this.$$length;
      }
    });
    Object.defineProperty(Node.prototype, "textContent", {
      get: function() {
        return getTextContent2(this);
      },
      set: function(data) {
        switch (this.nodeType) {
          case ELEMENT_NODE:
          case DOCUMENT_FRAGMENT_NODE:
            while (this.firstChild) {
              this.removeChild(this.firstChild);
            }
            if (data || String(data)) {
              this.appendChild(this.ownerDocument.createTextNode(data));
            }
            break;
          default:
            this.data = data;
            this.value = data;
            this.nodeValue = data;
        }
      }
    });
    __set__ = function(object, key, value) {
      object["$$" + key] = value;
    };
  }
} catch (e) {
}
exports.Node = Node;
exports.DOMException = DOMException;
exports.DOMImplementation = DOMImplementation;
exports.XMLSerializer = XMLSerializer;


/***/ }),

/***/ "./node_modules/xmldom/lib/entities.js":
/*!*********************************************!*\
  !*** ./node_modules/xmldom/lib/entities.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, exports) => {

exports.entityMap = {
  lt: "<",
  gt: ">",
  amp: "&",
  quot: '"',
  apos: "'",
  Agrave: "\xC0",
  Aacute: "\xC1",
  Acirc: "\xC2",
  Atilde: "\xC3",
  Auml: "\xC4",
  Aring: "\xC5",
  AElig: "\xC6",
  Ccedil: "\xC7",
  Egrave: "\xC8",
  Eacute: "\xC9",
  Ecirc: "\xCA",
  Euml: "\xCB",
  Igrave: "\xCC",
  Iacute: "\xCD",
  Icirc: "\xCE",
  Iuml: "\xCF",
  ETH: "\xD0",
  Ntilde: "\xD1",
  Ograve: "\xD2",
  Oacute: "\xD3",
  Ocirc: "\xD4",
  Otilde: "\xD5",
  Ouml: "\xD6",
  Oslash: "\xD8",
  Ugrave: "\xD9",
  Uacute: "\xDA",
  Ucirc: "\xDB",
  Uuml: "\xDC",
  Yacute: "\xDD",
  THORN: "\xDE",
  szlig: "\xDF",
  agrave: "\xE0",
  aacute: "\xE1",
  acirc: "\xE2",
  atilde: "\xE3",
  auml: "\xE4",
  aring: "\xE5",
  aelig: "\xE6",
  ccedil: "\xE7",
  egrave: "\xE8",
  eacute: "\xE9",
  ecirc: "\xEA",
  euml: "\xEB",
  igrave: "\xEC",
  iacute: "\xED",
  icirc: "\xEE",
  iuml: "\xEF",
  eth: "\xF0",
  ntilde: "\xF1",
  ograve: "\xF2",
  oacute: "\xF3",
  ocirc: "\xF4",
  otilde: "\xF5",
  ouml: "\xF6",
  oslash: "\xF8",
  ugrave: "\xF9",
  uacute: "\xFA",
  ucirc: "\xFB",
  uuml: "\xFC",
  yacute: "\xFD",
  thorn: "\xFE",
  yuml: "\xFF",
  nbsp: "\xA0",
  iexcl: "\xA1",
  cent: "\xA2",
  pound: "\xA3",
  curren: "\xA4",
  yen: "\xA5",
  brvbar: "\xA6",
  sect: "\xA7",
  uml: "\xA8",
  copy: "\xA9",
  ordf: "\xAA",
  laquo: "\xAB",
  not: "\xAC",
  shy: "\xAD\xAD",
  reg: "\xAE",
  macr: "\xAF",
  deg: "\xB0",
  plusmn: "\xB1",
  sup2: "\xB2",
  sup3: "\xB3",
  acute: "\xB4",
  micro: "\xB5",
  para: "\xB6",
  middot: "\xB7",
  cedil: "\xB8",
  sup1: "\xB9",
  ordm: "\xBA",
  raquo: "\xBB",
  frac14: "\xBC",
  frac12: "\xBD",
  frac34: "\xBE",
  iquest: "\xBF",
  times: "\xD7",
  divide: "\xF7",
  forall: "\u2200",
  part: "\u2202",
  exist: "\u2203",
  empty: "\u2205",
  nabla: "\u2207",
  isin: "\u2208",
  notin: "\u2209",
  ni: "\u220B",
  prod: "\u220F",
  sum: "\u2211",
  minus: "\u2212",
  lowast: "\u2217",
  radic: "\u221A",
  prop: "\u221D",
  infin: "\u221E",
  ang: "\u2220",
  and: "\u2227",
  or: "\u2228",
  cap: "\u2229",
  cup: "\u222A",
  "int": "\u222B",
  there4: "\u2234",
  sim: "\u223C",
  cong: "\u2245",
  asymp: "\u2248",
  ne: "\u2260",
  equiv: "\u2261",
  le: "\u2264",
  ge: "\u2265",
  sub: "\u2282",
  sup: "\u2283",
  nsub: "\u2284",
  sube: "\u2286",
  supe: "\u2287",
  oplus: "\u2295",
  otimes: "\u2297",
  perp: "\u22A5",
  sdot: "\u22C5",
  Alpha: "\u0391",
  Beta: "\u0392",
  Gamma: "\u0393",
  Delta: "\u0394",
  Epsilon: "\u0395",
  Zeta: "\u0396",
  Eta: "\u0397",
  Theta: "\u0398",
  Iota: "\u0399",
  Kappa: "\u039A",
  Lambda: "\u039B",
  Mu: "\u039C",
  Nu: "\u039D",
  Xi: "\u039E",
  Omicron: "\u039F",
  Pi: "\u03A0",
  Rho: "\u03A1",
  Sigma: "\u03A3",
  Tau: "\u03A4",
  Upsilon: "\u03A5",
  Phi: "\u03A6",
  Chi: "\u03A7",
  Psi: "\u03A8",
  Omega: "\u03A9",
  alpha: "\u03B1",
  beta: "\u03B2",
  gamma: "\u03B3",
  delta: "\u03B4",
  epsilon: "\u03B5",
  zeta: "\u03B6",
  eta: "\u03B7",
  theta: "\u03B8",
  iota: "\u03B9",
  kappa: "\u03BA",
  lambda: "\u03BB",
  mu: "\u03BC",
  nu: "\u03BD",
  xi: "\u03BE",
  omicron: "\u03BF",
  pi: "\u03C0",
  rho: "\u03C1",
  sigmaf: "\u03C2",
  sigma: "\u03C3",
  tau: "\u03C4",
  upsilon: "\u03C5",
  phi: "\u03C6",
  chi: "\u03C7",
  psi: "\u03C8",
  omega: "\u03C9",
  thetasym: "\u03D1",
  upsih: "\u03D2",
  piv: "\u03D6",
  OElig: "\u0152",
  oelig: "\u0153",
  Scaron: "\u0160",
  scaron: "\u0161",
  Yuml: "\u0178",
  fnof: "\u0192",
  circ: "\u02C6",
  tilde: "\u02DC",
  ensp: "\u2002",
  emsp: "\u2003",
  thinsp: "\u2009",
  zwnj: "\u200C",
  zwj: "\u200D",
  lrm: "\u200E",
  rlm: "\u200F",
  ndash: "\u2013",
  mdash: "\u2014",
  lsquo: "\u2018",
  rsquo: "\u2019",
  sbquo: "\u201A",
  ldquo: "\u201C",
  rdquo: "\u201D",
  bdquo: "\u201E",
  dagger: "\u2020",
  Dagger: "\u2021",
  bull: "\u2022",
  hellip: "\u2026",
  permil: "\u2030",
  prime: "\u2032",
  Prime: "\u2033",
  lsaquo: "\u2039",
  rsaquo: "\u203A",
  oline: "\u203E",
  euro: "\u20AC",
  trade: "\u2122",
  larr: "\u2190",
  uarr: "\u2191",
  rarr: "\u2192",
  darr: "\u2193",
  harr: "\u2194",
  crarr: "\u21B5",
  lceil: "\u2308",
  rceil: "\u2309",
  lfloor: "\u230A",
  rfloor: "\u230B",
  loz: "\u25CA",
  spades: "\u2660",
  clubs: "\u2663",
  hearts: "\u2665",
  diams: "\u2666"
};


/***/ }),

/***/ "./node_modules/xmldom/lib/sax.js":
/*!****************************************!*\
  !*** ./node_modules/xmldom/lib/sax.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, exports) => {

var nameStartChar = /[A-Z_a-z\xC0-\xD6\xD8-\xF6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/;
var nameChar = new RegExp("[\\-\\.0-9" + nameStartChar.source.slice(1, -1) + "\\u00B7\\u0300-\\u036F\\u203F-\\u2040]");
var tagNamePattern = new RegExp("^" + nameStartChar.source + nameChar.source + "*(?::" + nameStartChar.source + nameChar.source + "*)?$");
var S_TAG = 0;
var S_ATTR = 1;
var S_ATTR_SPACE = 2;
var S_EQ = 3;
var S_ATTR_NOQUOT_VALUE = 4;
var S_ATTR_END = 5;
var S_TAG_SPACE = 6;
var S_TAG_CLOSE = 7;
function ParseError(message, locator) {
  this.message = message;
  this.locator = locator;
  if (Error.captureStackTrace)
    Error.captureStackTrace(this, ParseError);
}
ParseError.prototype = new Error();
ParseError.prototype.name = ParseError.name;
function XMLReader() {
}
XMLReader.prototype = {
  parse: function(source, defaultNSMap, entityMap) {
    var domBuilder = this.domBuilder;
    domBuilder.startDocument();
    _copy(defaultNSMap, defaultNSMap = {});
    parse(
      source,
      defaultNSMap,
      entityMap,
      domBuilder,
      this.errorHandler
    );
    domBuilder.endDocument();
  }
};
function parse(source, defaultNSMapCopy, entityMap, domBuilder, errorHandler) {
  function fixedFromCharCode(code) {
    if (code > 65535) {
      code -= 65536;
      var surrogate1 = 55296 + (code >> 10), surrogate2 = 56320 + (code & 1023);
      return String.fromCharCode(surrogate1, surrogate2);
    } else {
      return String.fromCharCode(code);
    }
  }
  function entityReplacer(a2) {
    var k = a2.slice(1, -1);
    if (k in entityMap) {
      return entityMap[k];
    } else if (k.charAt(0) === "#") {
      return fixedFromCharCode(parseInt(k.substr(1).replace("x", "0x")));
    } else {
      errorHandler.error("entity not found:" + a2);
      return a2;
    }
  }
  function appendText(end2) {
    if (end2 > start) {
      var xt = source.substring(start, end2).replace(/&#?\w+;/g, entityReplacer);
      locator && position(start);
      domBuilder.characters(xt, 0, end2 - start);
      start = end2;
    }
  }
  function position(p, m) {
    while (p >= lineEnd && (m = linePattern.exec(source))) {
      lineStart = m.index;
      lineEnd = lineStart + m[0].length;
      locator.lineNumber++;
    }
    locator.columnNumber = p - lineStart + 1;
  }
  var lineStart = 0;
  var lineEnd = 0;
  var linePattern = /.*(?:\r\n?|\n)|.*$/g;
  var locator = domBuilder.locator;
  var parseStack = [{ currentNSMap: defaultNSMapCopy }];
  var closeMap = {};
  var start = 0;
  while (true) {
    try {
      var tagStart = source.indexOf("<", start);
      if (tagStart < 0) {
        if (!source.substr(start).match(/^\s*$/)) {
          var doc = domBuilder.doc;
          var text = doc.createTextNode(source.substr(start));
          doc.appendChild(text);
          domBuilder.currentElement = text;
        }
        return;
      }
      if (tagStart > start) {
        appendText(tagStart);
      }
      switch (source.charAt(tagStart + 1)) {
        case "/":
          var end = source.indexOf(">", tagStart + 3);
          var tagName = source.substring(tagStart + 2, end);
          var config = parseStack.pop();
          if (end < 0) {
            tagName = source.substring(tagStart + 2).replace(/[\s<].*/, "");
            errorHandler.error("end tag name: " + tagName + " is not complete:" + config.tagName);
            end = tagStart + 1 + tagName.length;
          } else if (tagName.match(/\s</)) {
            tagName = tagName.replace(/[\s<].*/, "");
            errorHandler.error("end tag name: " + tagName + " maybe not complete");
            end = tagStart + 1 + tagName.length;
          }
          var localNSMap = config.localNSMap;
          var endMatch = config.tagName == tagName;
          var endIgnoreCaseMach = endMatch || config.tagName && config.tagName.toLowerCase() == tagName.toLowerCase();
          if (endIgnoreCaseMach) {
            domBuilder.endElement(config.uri, config.localName, tagName);
            if (localNSMap) {
              for (var prefix in localNSMap) {
                domBuilder.endPrefixMapping(prefix);
              }
            }
            if (!endMatch) {
              errorHandler.fatalError("end tag name: " + tagName + " is not match the current start tagName:" + config.tagName);
            }
          } else {
            parseStack.push(config);
          }
          end++;
          break;
        case "?":
          locator && position(tagStart);
          end = parseInstruction(source, tagStart, domBuilder);
          break;
        case "!":
          locator && position(tagStart);
          end = parseDCC(source, tagStart, domBuilder, errorHandler);
          break;
        default:
          locator && position(tagStart);
          var el = new ElementAttributes();
          var currentNSMap = parseStack[parseStack.length - 1].currentNSMap;
          var end = parseElementStartPart(source, tagStart, el, currentNSMap, entityReplacer, errorHandler);
          var len = el.length;
          if (!el.closed && fixSelfClosed(source, end, el.tagName, closeMap)) {
            el.closed = true;
            if (!entityMap.nbsp) {
              errorHandler.warning("unclosed xml attribute");
            }
          }
          if (locator && len) {
            var locator2 = copyLocator(locator, {});
            for (var i = 0; i < len; i++) {
              var a = el[i];
              position(a.offset);
              a.locator = copyLocator(locator, {});
            }
            domBuilder.locator = locator2;
            if (appendElement(el, domBuilder, currentNSMap)) {
              parseStack.push(el);
            }
            domBuilder.locator = locator;
          } else {
            if (appendElement(el, domBuilder, currentNSMap)) {
              parseStack.push(el);
            }
          }
          if (el.uri === "http://www.w3.org/1999/xhtml" && !el.closed) {
            end = parseHtmlSpecialContent(source, end, el.tagName, entityReplacer, domBuilder);
          } else {
            end++;
          }
      }
    } catch (e) {
      if (e instanceof ParseError) {
        throw e;
      }
      errorHandler.error("element parse error: " + e);
      end = -1;
    }
    if (end > start) {
      start = end;
    } else {
      appendText(Math.max(tagStart, start) + 1);
    }
  }
}
function copyLocator(f, t) {
  t.lineNumber = f.lineNumber;
  t.columnNumber = f.columnNumber;
  return t;
}
function parseElementStartPart(source, start, el, currentNSMap, entityReplacer, errorHandler) {
  function addAttribute(qname, value2, startIndex) {
    if (qname in el.attributeNames)
      errorHandler.fatalError("Attribute " + qname + " redefined");
    el.addValue(qname, value2, startIndex);
  }
  var attrName;
  var value;
  var p = ++start;
  var s = S_TAG;
  while (true) {
    var c = source.charAt(p);
    switch (c) {
      case "=":
        if (s === S_ATTR) {
          attrName = source.slice(start, p);
          s = S_EQ;
        } else if (s === S_ATTR_SPACE) {
          s = S_EQ;
        } else {
          throw new Error("attribute equal must after attrName");
        }
        break;
      case "'":
      case '"':
        if (s === S_EQ || s === S_ATTR) {
          if (s === S_ATTR) {
            errorHandler.warning('attribute value must after "="');
            attrName = source.slice(start, p);
          }
          start = p + 1;
          p = source.indexOf(c, start);
          if (p > 0) {
            value = source.slice(start, p).replace(/&#?\w+;/g, entityReplacer);
            addAttribute(attrName, value, start - 1);
            s = S_ATTR_END;
          } else {
            throw new Error("attribute value no end '" + c + "' match");
          }
        } else if (s == S_ATTR_NOQUOT_VALUE) {
          value = source.slice(start, p).replace(/&#?\w+;/g, entityReplacer);
          addAttribute(attrName, value, start);
          errorHandler.warning('attribute "' + attrName + '" missed start quot(' + c + ")!!");
          start = p + 1;
          s = S_ATTR_END;
        } else {
          throw new Error('attribute value must after "="');
        }
        break;
      case "/":
        switch (s) {
          case S_TAG:
            el.setTagName(source.slice(start, p));
          case S_ATTR_END:
          case S_TAG_SPACE:
          case S_TAG_CLOSE:
            s = S_TAG_CLOSE;
            el.closed = true;
          case S_ATTR_NOQUOT_VALUE:
          case S_ATTR:
          case S_ATTR_SPACE:
            break;
          default:
            throw new Error("attribute invalid close char('/')");
        }
        break;
      case "":
        errorHandler.error("unexpected end of input");
        if (s == S_TAG) {
          el.setTagName(source.slice(start, p));
        }
        return p;
      case ">":
        switch (s) {
          case S_TAG:
            el.setTagName(source.slice(start, p));
          case S_ATTR_END:
          case S_TAG_SPACE:
          case S_TAG_CLOSE:
            break;
          case S_ATTR_NOQUOT_VALUE:
          case S_ATTR:
            value = source.slice(start, p);
            if (value.slice(-1) === "/") {
              el.closed = true;
              value = value.slice(0, -1);
            }
          case S_ATTR_SPACE:
            if (s === S_ATTR_SPACE) {
              value = attrName;
            }
            if (s == S_ATTR_NOQUOT_VALUE) {
              errorHandler.warning('attribute "' + value + '" missed quot(")!');
              addAttribute(attrName, value.replace(/&#?\w+;/g, entityReplacer), start);
            } else {
              if (currentNSMap[""] !== "http://www.w3.org/1999/xhtml" || !value.match(/^(?:disabled|checked|selected)$/i)) {
                errorHandler.warning('attribute "' + value + '" missed value!! "' + value + '" instead!!');
              }
              addAttribute(value, value, start);
            }
            break;
          case S_EQ:
            throw new Error("attribute value missed!!");
        }
        return p;
      case "\x80":
        c = " ";
      default:
        if (c <= " ") {
          switch (s) {
            case S_TAG:
              el.setTagName(source.slice(start, p));
              s = S_TAG_SPACE;
              break;
            case S_ATTR:
              attrName = source.slice(start, p);
              s = S_ATTR_SPACE;
              break;
            case S_ATTR_NOQUOT_VALUE:
              var value = source.slice(start, p).replace(/&#?\w+;/g, entityReplacer);
              errorHandler.warning('attribute "' + value + '" missed quot(")!!');
              addAttribute(attrName, value, start);
            case S_ATTR_END:
              s = S_TAG_SPACE;
              break;
          }
        } else {
          switch (s) {
            case S_ATTR_SPACE:
              var tagName = el.tagName;
              if (currentNSMap[""] !== "http://www.w3.org/1999/xhtml" || !attrName.match(/^(?:disabled|checked|selected)$/i)) {
                errorHandler.warning('attribute "' + attrName + '" missed value!! "' + attrName + '" instead2!!');
              }
              addAttribute(attrName, attrName, start);
              start = p;
              s = S_ATTR;
              break;
            case S_ATTR_END:
              errorHandler.warning('attribute space is required"' + attrName + '"!!');
            case S_TAG_SPACE:
              s = S_ATTR;
              start = p;
              break;
            case S_EQ:
              s = S_ATTR_NOQUOT_VALUE;
              start = p;
              break;
            case S_TAG_CLOSE:
              throw new Error("elements closed character '/' and '>' must be connected to");
          }
        }
    }
    p++;
  }
}
function appendElement(el, domBuilder, currentNSMap) {
  var tagName = el.tagName;
  var localNSMap = null;
  var i = el.length;
  while (i--) {
    var a = el[i];
    var qName = a.qName;
    var value = a.value;
    var nsp = qName.indexOf(":");
    if (nsp > 0) {
      var prefix = a.prefix = qName.slice(0, nsp);
      var localName = qName.slice(nsp + 1);
      var nsPrefix = prefix === "xmlns" && localName;
    } else {
      localName = qName;
      prefix = null;
      nsPrefix = qName === "xmlns" && "";
    }
    a.localName = localName;
    if (nsPrefix !== false) {
      if (localNSMap == null) {
        localNSMap = {};
        _copy(currentNSMap, currentNSMap = {});
      }
      currentNSMap[nsPrefix] = localNSMap[nsPrefix] = value;
      a.uri = "http://www.w3.org/2000/xmlns/";
      domBuilder.startPrefixMapping(nsPrefix, value);
    }
  }
  var i = el.length;
  while (i--) {
    a = el[i];
    var prefix = a.prefix;
    if (prefix) {
      if (prefix === "xml") {
        a.uri = "http://www.w3.org/XML/1998/namespace";
      }
      if (prefix !== "xmlns") {
        a.uri = currentNSMap[prefix || ""];
      }
    }
  }
  var nsp = tagName.indexOf(":");
  if (nsp > 0) {
    prefix = el.prefix = tagName.slice(0, nsp);
    localName = el.localName = tagName.slice(nsp + 1);
  } else {
    prefix = null;
    localName = el.localName = tagName;
  }
  var ns = el.uri = currentNSMap[prefix || ""];
  domBuilder.startElement(ns, localName, tagName, el);
  if (el.closed) {
    domBuilder.endElement(ns, localName, tagName);
    if (localNSMap) {
      for (prefix in localNSMap) {
        domBuilder.endPrefixMapping(prefix);
      }
    }
  } else {
    el.currentNSMap = currentNSMap;
    el.localNSMap = localNSMap;
    return true;
  }
}
function parseHtmlSpecialContent(source, elStartEnd, tagName, entityReplacer, domBuilder) {
  if (/^(?:script|textarea)$/i.test(tagName)) {
    var elEndStart = source.indexOf("</" + tagName + ">", elStartEnd);
    var text = source.substring(elStartEnd + 1, elEndStart);
    if (/[&<]/.test(text)) {
      if (/^script$/i.test(tagName)) {
        domBuilder.characters(text, 0, text.length);
        return elEndStart;
      }
      text = text.replace(/&#?\w+;/g, entityReplacer);
      domBuilder.characters(text, 0, text.length);
      return elEndStart;
    }
  }
  return elStartEnd + 1;
}
function fixSelfClosed(source, elStartEnd, tagName, closeMap) {
  var pos = closeMap[tagName];
  if (pos == null) {
    pos = source.lastIndexOf("</" + tagName + ">");
    if (pos < elStartEnd) {
      pos = source.lastIndexOf("</" + tagName);
    }
    closeMap[tagName] = pos;
  }
  return pos < elStartEnd;
}
function _copy(source, target) {
  for (var n in source) {
    target[n] = source[n];
  }
}
function parseDCC(source, start, domBuilder, errorHandler) {
  var next = source.charAt(start + 2);
  switch (next) {
    case "-":
      if (source.charAt(start + 3) === "-") {
        var end = source.indexOf("-->", start + 4);
        if (end > start) {
          domBuilder.comment(source, start + 4, end - start - 4);
          return end + 3;
        } else {
          errorHandler.error("Unclosed comment");
          return -1;
        }
      } else {
        return -1;
      }
    default:
      if (source.substr(start + 3, 6) == "CDATA[") {
        var end = source.indexOf("]]>", start + 9);
        domBuilder.startCDATA();
        domBuilder.characters(source, start + 9, end - start - 9);
        domBuilder.endCDATA();
        return end + 3;
      }
      var matchs = split(source, start);
      var len = matchs.length;
      if (len > 1 && /!doctype/i.test(matchs[0][0])) {
        var name = matchs[1][0];
        var pubid = false;
        var sysid = false;
        if (len > 3) {
          if (/^public$/i.test(matchs[2][0])) {
            pubid = matchs[3][0];
            sysid = len > 4 && matchs[4][0];
          } else if (/^system$/i.test(matchs[2][0])) {
            sysid = matchs[3][0];
          }
        }
        var lastMatch = matchs[len - 1];
        domBuilder.startDTD(name, pubid, sysid);
        domBuilder.endDTD();
        return lastMatch.index + lastMatch[0].length;
      }
  }
  return -1;
}
function parseInstruction(source, start, domBuilder) {
  var end = source.indexOf("?>", start);
  if (end) {
    var match = source.substring(start, end).match(/^<\?(\S*)\s*([\s\S]*?)\s*$/);
    if (match) {
      var len = match[0].length;
      domBuilder.processingInstruction(match[1], match[2]);
      return end + 2;
    } else {
      return -1;
    }
  }
  return -1;
}
function ElementAttributes() {
  this.attributeNames = {};
}
ElementAttributes.prototype = {
  setTagName: function(tagName) {
    if (!tagNamePattern.test(tagName)) {
      throw new Error("invalid tagName:" + tagName);
    }
    this.tagName = tagName;
  },
  addValue: function(qName, value, offset) {
    if (!tagNamePattern.test(qName)) {
      throw new Error("invalid attribute:" + qName);
    }
    this.attributeNames[qName] = this.length;
    this[this.length++] = { qName, value, offset };
  },
  length: 0,
  getLocalName: function(i) {
    return this[i].localName;
  },
  getLocator: function(i) {
    return this[i].locator;
  },
  getQName: function(i) {
    return this[i].qName;
  },
  getURI: function(i) {
    return this[i].uri;
  },
  getValue: function(i) {
    return this[i].value;
  }
};
function split(source, start) {
  var match;
  var buf = [];
  var reg = /'[^']+'|"[^"]+"|[^\s<>\/=]+=?|(\/?\s*>|<)/g;
  reg.lastIndex = start;
  reg.exec(source);
  while (match = reg.exec(source)) {
    buf.push(match);
    if (match[1])
      return buf;
  }
}
exports.XMLReader = XMLReader;
exports.ParseError = ParseError;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!**************************************!*\
  !*** ./DocxTemplatesCanvas/index.ts ***!
  \**************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DocxTemplatesCanvas": () => (/* binding */ DocxTemplatesCanvas)
/* harmony export */ });
/* harmony import */ var easy_template_x__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! easy-template-x */ "./node_modules/easy-template-x/dist/es/easy-template-x.js");
/* harmony import */ var base64_arraybuffer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! base64-arraybuffer */ "./node_modules/base64-arraybuffer/dist/base64-arraybuffer.es5.js");
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};


const BASE64_MARKER = ";base64,";
class DocxTemplatesCanvas {
  constructor() {
    this.convertStringToArray = (pdfString) => {
      const base64Index = pdfString.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
      const base64 = pdfString.substring(base64Index);
      return (0,base64_arraybuffer__WEBPACK_IMPORTED_MODULE_1__.decode)(base64);
    };
  }
  init(context, notifyOutputChanged, state, container) {
    context.mode.trackContainerResize(false);
    this._notifyOutputChanged = notifyOutputChanged;
  }
  updateView(context) {
    return __async(this, null, function* () {
      var _a;
      var params = context.parameters;
      if (!((_a = params.docxTemplate) == null ? void 0 : _a.raw) || !params.fillTemplate.raw)
        return;
      this._outputErrorMessage = "";
      try {
        this._output = `data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,${yield this.DocxTemplateFill(context)}`;
      } catch (e) {
        this._outputErrorMessage = `ERROR: The Docx template filler ran into an error.  MESSAGE: ${e instanceof Error ? e.message : String(e)}`;
        this._output = "";
      }
      this._notifyOutputChanged();
    });
  }
  getOutputs() {
    let output = {
      docxOutput: this._output || "",
      outputErrorMessage: this._outputErrorMessage,
      outputError: !!this._outputErrorMessage,
      fillTemplate: false
    };
    return output;
  }
  destroy() {
  }
  DocxTemplateFill(pcfContext) {
    return __async(this, null, function* () {
      var _a;
      var params = pcfContext.parameters;
      var dataSet = ((_a = pcfContext.parameters.templateData) == null ? void 0 : _a.raw) || "{}";
      var dataSetObject = JSON.parse(dataSet);
      yield this.updateImagesToArrayBuffer(dataSetObject);
      const handler = new easy_template_x__WEBPACK_IMPORTED_MODULE_0__.TemplateHandler();
      const docxFilled = yield handler.process(
        this.convertStringToArray(params.docxTemplate.raw),
        dataSetObject
      );
      return (0,base64_arraybuffer__WEBPACK_IMPORTED_MODULE_1__.encode)(docxFilled);
    });
  }
  updateImagesToArrayBuffer(target) {
    return __async(this, null, function* () {
      for (const key in target) {
        const value = target[key];
        if (key === "source" && value.includes(BASE64_MARKER)) {
          target[key] = this.convertStringToArray(value);
        } else if (typeof value === "object" && value) {
          yield this.updateImagesToArrayBuffer(value);
        }
      }
    });
  }
}

})();

pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ })()
;
//# sourceMappingURL=bundle.js.map
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('RAW.DocxTemplatesCanvas', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DocxTemplatesCanvas);
} else {
	var RAW = RAW || {};
	RAW.DocxTemplatesCanvas = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DocxTemplatesCanvas;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}